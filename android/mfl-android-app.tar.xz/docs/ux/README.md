# MFL Core Android — UX spec and mockups

SVG mockups for each main screen, 360 × 800 dp (common phone width). Each SVG imports into Figma as an editable vector frame (File → Import).

| # | File | Screen |
|---|------|--------|
| 01 | `01-login.svg` | Login (role, mobile, password, OTP) |
| 02 | `02-dashboard.svg` | Executive dashboard |
| 03 | `03-customers.svg` | Customers list |
| 04 | `04-addresses.svg` | Addresses list |
| 05 | `05-loans.svg` | Loans portfolio |
| 06 | `06-new-loan-form.svg` | New loan form |
| 07 | `07-loan-detail.svg` | Loan detail (all fields) |
| 08 | `08-kists.svg` | Kist ledger (installments) |
| 09 | `09-payments-receipts.svg` | Current payment — receipts |
| 10 | `10-payments-dues.svg` | Current payment — dues |
| 11 | `11-collect-payment-dialog.svg` | Collect payment dialog |
| 12 | `12-hisab-one-time.svg` | One-time hisab and settlement |
| 13 | `13-overdue-and-reports.svg` | Overdue compute and billing report |

The mockups are drawn with the same components the app uses, so they match the code. They are mockups, not pixel-exact screenshots.

## Global layout

- **Top bar** (56 dp): "MFL CORE", API health chip (green Online / red Offline), signed-in role, Logout.
- **Header row**: page title (20 sp) and one primary action on the right ("New loan", "Generate").
- **Bottom navigation** (64 dp, 5 sections): Home · Customers · Loans · Kists · Payments.
  - Customers has sub-tabs: Customers, Addresses.
  - Payments has sub-tabs: Today (receipts and dues), Hisab (one-time settlement), Overdue & reports.
- **Content**: 14 dp side margins. Cards are white, 1 dp border, 8–10 dp radius.

## Type scale

| Use | Size |
|---|---|
| Page title | 20 sp semibold |
| Card title | 15 sp semibold |
| Body, table cells, form input | 13–15 sp |
| Table headers, badges, captions | 11 sp |
| Buttons | 14 sp |

Minimum touch target: 40 dp high for buttons and 48 dp for table rows.

## Colour

Taken from the web app's Tailwind palette: ink `#0F172A`, muted `#64748B`, border `#E2E8F0`, accent (links, active) `#4F46E5`, danger `#DC2626`, page `#F8FAFC`. Table header is amber (`#FEF3C7` with `#451A03` text). Rows alternate white and `#F1F5F9`. Status badges: green for ACTIVE/SUCCESS/PAID, grey for OPEN, red for REVERSED/BOUNCED.

## List screen behaviour (the rules the mockups follow)

1. **The page fits the screen without scrolling.** The table takes the space left below the header and filters. Row height is fixed at 48 dp, so the page size is worked out from the available height. The server returns exactly that many rows. The list never scrolls vertically; the pager sits at the bottom.
2. **Filters in one row.** Each list has its filters on a single row, shared across the width. Dropdowns show their label until a value is picked, so the label stays readable.
3. **Columns.**
   - The first column (ID or name) is pinned on the left.
   - Columns stretch to fill the width when they fit.
   - When there are too many columns for the width, the rest scroll sideways under the pinned column.
   - Where a row has an action (Collect, Remarks), the action sits in a fixed column on the right.
4. **Links.** IDs in blue underline open the detail screen. Dashes (—) are not links.
5. **Pager.** Fixed footer: "‹ Prev", "Page x of y", "Next ›". Prev is disabled on page 1, Next on the last page.
6. **Loading and empty states.** Loading shows "Loading…" in place of the table. Empty shows a centred message such as "No loans match these filters."
7. **Error state.** Shows the backend's message in red with a Retry button.

## Per-screen notes

- **Login.** Role chips (Owner / Manager), 10-digit mobile, password, then a 6-digit OTP with a 60-second resend timer. Development stub: no real authentication.
- **Dashboard.** Four stat cards (AUM, capital deployed, collected this month, overdue & fines), the 12th and 25th cycle progress, owner vs manager, top villages, customers & KYC, today's receipts, and alerts that link to the next action.
- **Customers / Addresses.** Search or village/mohalla filters. "New" opens a create dialog.
- **Loans.** Account no, type and status filters. Loan ID opens the loan detail. Interest is shown for MI and OT only.
- **New loan.** Two cards: borrower and terms, then capital split. Manager + owner must equal principal, checked before the confirm dialog.
- **Loan detail.** Label/value list. Pencil icon on editable fields (status, purpose, rate, processing fee, manager/owner names).
- **Kists.** Filters: status, loan type, loan ID, installment date. Collect opens the payment dialog on rows with a balance.
- **Payments.** Receipts (status, mode filters, Remarks action) and Dues (status filter, Collect action).
- **Collect dialog.** Manager and owner amounts, payment mode, transaction reference (required for UPI, bank transfer, cheque), payer name. Confirm is blocked when the total is zero or exceeds the balance.
- **Hisab (one-time).** Hisab date, dry-run board of active OT loans, then single-loan settlement with preview before save.
- **Overdue & reports.** Run overdue compute (dry run first), then rebuild the billing report. Every write action previews first.

## Known gaps

- The Dashboard fails to load while the backend returns `kyc_pending` as a float (`14.0`). This is an open backend fix.
- Operations and Hisab screens keep the older scrolling layout, with 50-row pages. They have not been moved to the fit-to-screen table.
- The mockups have not been checked on a device for Customers, Addresses, Payments, and the dialogs. Only the Loans and Kists screens were checked on the emulator.
