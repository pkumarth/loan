# MFL Core Android App

Native Android (Kotlin + Jetpack Compose) version of the MFL Core Web UI in `../mfl-ui`.
It uses the same backend API (`/mfl-core/api/v1`) and mirrors the web screens, routes, table columns,
formatting, and edit rules.

> **Status:** this project has not been compiled or run yet. It was written without an Android SDK,
> Gradle, or a device available. Expect a first-build pass to fix small compile errors.

## Prerequisites

- JDK 25 (the project targets Java 25; Gradle 9.9.1 runs on it).
- Android Studio (Ladybug 2024.2 or newer), set to use the JDK 25 install for Gradle.
- Android SDK Platform 36.
- The MFL Core backend running (default `http://127.0.0.1:8000` on the dev machine).

## Open and run

1. Open the `mfl-android-app` folder in Android Studio (File → Open).
2. Let Gradle sync. The project pins Gradle 9.9.1 through the included Gradle wrapper (`gradlew`).
3. Pick an emulator or device and press Run.

## Configuration (`gradle.properties`)

| Property | Default | Purpose |
|---|---|---|
| `mflApiBaseUrl` | `http://10.0.2.2:8000` | Backend base URL. `10.0.2.2` is the host machine as seen from the Android emulator. For a physical phone on the same Wi-Fi, use the dev machine's LAN IP, e.g. `http://192.168.1.20:8000`. |
| `mflDevOtp` | `123456` | Stub OTP accepted on the login screen. Mirrors the web app's dev login. |

The values are compiled into `BuildConfig.API_BASE_URL` and `BuildConfig.DEV_OTP`.

## Notes

- **Cleartext HTTP is allowed** (`app/src/main/res/xml/network_security_config.xml`) so the dev backend
  works over `http://`. Restrict it to HTTPS, or to specific hosts, before any release build.
- **Login is a stub**, the same as the web app: role, mobile, password, then a fixed OTP. Nothing is
  verified against a server. The requests carry an `X-User-Id` header taken from the chosen role
  (Owner → praveen, Manager → bhikhari_yadav).
- Lists use the same page size as the web (50 rows). Name and address fields are joined on the client
  from `/customers`, `/addresses`, and `/payment-schedules`, cached for 60 seconds.

## Layout

```
app/src/main/java/com/mfl/core/
  MainActivity.kt          entry point
  data/                    API client, models, session stub, list/lookup repository
  util/Format.kt           INR-style whole numbers, dd MMM yyyy dates, interest, cycle rules
  ui/theme/                colours and typography (web table style)
  ui/components/           shared pieces: DataTable, ScheduleTable, CollectDialog, EntityDetail, forms
  ui/nav/AppNav.kt         routes, login gate, header, primary and sub tabs
  ui/screens/              one file per web area (Dashboard, Customers, Addresses, Loans, LoanForm,
                           Schedules, Generate, CurrentPayment, Onetime, Operations, Login)
```

## Known web-app issues carried over as-is

- The web detail pages format `rate_of_interest` as a money value, so 2.5% can show as "3". The
  Android app shows the rate as a plain number.
- The web "Guarantor relation" column on the customer list reads the guarantor customer's
  `guarantor_relation`. The Android column shows the row's own `guarantor_relation`.
