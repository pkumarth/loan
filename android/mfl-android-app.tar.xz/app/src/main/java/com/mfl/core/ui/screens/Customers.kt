package com.mfl.core.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.mfl.core.data.Address
import com.mfl.core.data.ApiClient
import com.mfl.core.data.Customer
import com.mfl.core.data.Lookups
import com.mfl.core.data.listPage
import com.mfl.core.data.userMessage
import com.mfl.core.ui.components.*
import com.mfl.core.util.fieldLabel
import com.mfl.core.util.formatWhole
import com.mfl.core.util.orNull
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

internal val CUSTOMER_RELATIONS = listOf("FATHER", "HUSBAND", "MOTHER", "OTHER")
internal val CUSTOMER_STATUSES = listOf("ACTIVE", "INACTIVE", "BLACKLISTED")
internal val KYC_STATUSES = listOf("NOT_UPLOADED", "UPLOADED", "PENDING", "VERIFIED", "REJECTED")

private class CustomersLookup(val customers: Map<Long, Customer>, val addresses: Map<Long, Address>)

/** Customer directory. Customer ID, guarantor and village/mohalla are links, as on the web. */
@Composable
fun CustomersScreen(onNavigate: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var creating by remember { mutableStateOf(false) }
    var reloadTick by remember { mutableIntStateOf(0) }

    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        PageHeader("Customers") {
            ActionButton("New customer", { creating = true }, primary = true)
        }
        FilterRow {
            FilterText("Search by name", name, { name = it }, Modifier.weight(1f))
        }
        PagedTable(
            filterKey = name,
            reloadKey = reloadTick,
            emptyText = "No customers found.",
            fetch = { p, size ->
                val list = listPage<Customer>("/customers", p, mapOf("customer_name" to name.orNull()), size)
                PageResult(list.rows, list.totalPages, CustomersLookup(Lookups.customers(), Lookups.addresses()))
            },
            columns = { lookup -> customerColumns(lookup, onNavigate) },
            modifier = Modifier.weight(1f),
        )
    }

    if (creating) {
        CustomerCreateDialog(
            onDismiss = { creating = false },
            onCreated = {
                creating = false
                reloadTick++
            },
        )
    }
}

private fun customerColumns(view: CustomersLookup, onNavigate: (String) -> Unit): List<DataColumn<Customer>> {
    fun guarantorOf(c: Customer): Customer? = c.guarantorId?.let { view.customers[it] }
    fun addressOf(c: Customer): Address? = view.addresses[c.addressId]

    return listOf(
        DataColumn<Customer>("Customer ID", 90.dp, onClick = { onNavigate("customers/${it.customerId}") }) { it.customerId.toString() },
        DataColumn<Customer>("Customer name", 150.dp) { it.customerName },
        DataColumn<Customer>("Guardian name", 130.dp) { it.guardianName },
        DataColumn<Customer>("Guardian relation", 120.dp) { it.guardianRelation },
        DataColumn<Customer>("Customer mobile", 120.dp) { it.customerMobile },
        DataColumn<Customer>(
            "Guarantor name", 140.dp,
            onClick = { c -> c.guarantorId?.let { onNavigate("customers/$it") } },
        ) { c -> guarantorOf(c)?.customerName ?: c.guarantorId?.let { "#$it" } ?: "—" },
        DataColumn<Customer>("Guarantor relation", 120.dp) { it.guarantorRelation ?: "—" },
        DataColumn<Customer>("Guarantor mobile", 120.dp) { c -> guarantorOf(c)?.customerMobile ?: "—" },
        DataColumn<Customer>(
            "Village", 110.dp,
            onClick = { c -> onNavigate("addresses/${c.addressId}") },
        ) { c -> addressOf(c)?.village ?: "—" },
        DataColumn<Customer>(
            "Mohalla", 110.dp,
            onClick = { c -> onNavigate("addresses/${c.addressId}") },
        ) { c -> addressOf(c)?.mohalla ?: "—" },
        DataColumn<Customer>("Customer status", 110.dp) { it.customerStatus ?: "—" },
        DataColumn<Customer>("Customer rating", 100.dp, right = true) { com.mfl.core.util.plainNumber(it.customerRating) },
        DataColumn<Customer>("Family income", 110.dp, right = true) { formatWhole(it.familyIncome) },
        DataColumn<Customer>("Family loan", 110.dp, right = true) { formatWhole(it.familyLoan) },
    )
}

/** One customer, every field. Pencil on the editable fields (PATCH /customers/{id}). */
@Composable
fun CustomerDetailScreen(id: String, onNavigate: (String) -> Unit, onBack: () -> Unit) {
    EntityDetailScreen(
        title = "Customer $id",
        path = "/customers/$id",
        editable = mapOf(
            "customer_name" to EditSpec(EditKind.TEXT),
            "guardian_name" to EditSpec(EditKind.TEXT),
            "guardian_relation" to EditSpec(EditKind.OPTIONS, CUSTOMER_RELATIONS),
            "guarantor_relation" to EditSpec(EditKind.OPTIONS, CUSTOMER_RELATIONS),
            "customer_mobile" to EditSpec(EditKind.MOBILE),
            "customer_email" to EditSpec(EditKind.TEXT),
            "customer_status" to EditSpec(EditKind.OPTIONS, CUSTOMER_STATUSES),
            "customer_rating" to EditSpec(EditKind.WHOLE),
            "family_income" to EditSpec(EditKind.MONEY),
            "family_loan" to EditSpec(EditKind.MONEY),
            "kyc_status" to EditSpec(EditKind.OPTIONS, KYC_STATUSES),
        ),
        linkRoutes = mapOf("guarantor_id" to "customers/{}", "address_id" to "addresses/{}"),
        onNavigate = onNavigate,
        onBack = onBack,
    )
}

/** New customer form (POST /customers). Same fields and checks as the web dialog. */
@Composable
private fun CustomerCreateDialog(onDismiss: () -> Unit, onCreated: () -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val form = remember {
        mutableStateMapOf(
            "customer_name" to "",
            "guardian_name" to "",
            "guardian_relation" to "FATHER",
            "guarantor_relation" to "FATHER",
            "customer_mobile" to "",
            "address_id" to "",
            "guarantor_id" to "",
            "guarantor_mobile" to "",
            "aadhaar_no" to "",
            "pan_no" to "",
        )
    }
    var error by remember { mutableStateOf<String?>(null) }
    var saving by remember { mutableStateOf(false) }

    FormDialog(
        title = "New customer",
        confirmText = "Save customer",
        saving = saving,
        error = error,
        onDismiss = onDismiss,
        onConfirm = {
            val mobile = form.getValue("customer_mobile").trim()
            val addressId = form.getValue("address_id").trim().toLongOrNull()
            when {
                !Regex("\\d{10}").matches(mobile) -> error = "Enter a 10-digit mobile number"
                addressId == null -> error = "Enter an address ID"
                else -> {
                    error = null
                    saving = true
                    scope.launch {
                        try {
                            val body = buildJsonObject {
                                for ((k, v) in form) {
                                    if (k != "address_id" && k != "guarantor_id" && v.isNotBlank()) put(k, v.trim())
                                }
                                put("address_id", addressId)
                                put("guarantor_id", form.getValue("guarantor_id").trim().toLongOrNull())
                            }
                            ApiClient.execute("/customers", "POST", body = body)
                            Lookups.invalidate()
                            toast(context, "Customer created")
                            onCreated()
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            error = e.userMessage()
                        } finally {
                            saving = false
                        }
                    }
                }
            }
        },
    ) {
        listOf(
            "customer_name", "guardian_name", "guardian_relation", "guarantor_relation", "customer_mobile",
            "address_id", "guarantor_id", "guarantor_mobile", "aadhaar_no", "pan_no",
        ).forEach { k ->
            if (k == "guardian_relation" || k == "guarantor_relation") {
                OptionPicker(
                    fieldLabel(k),
                    form.getValue(k),
                    CUSTOMER_RELATIONS.map { it to it },
                    onPick = { form[k] = it },
                )
            } else {
                FormField(
                    fieldLabel(k),
                    form.getValue(k),
                    onChange = { form[k] = it },
                    keyboard = if (k.endsWith("_id")) KeyboardType.Number else if (k.endsWith("mobile")) KeyboardType.Phone else KeyboardType.Text,
                )
            }
        }
    }
}
