package com.mfl.core.ui.components

import android.widget.Toast
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.sp
import com.mfl.core.data.ApiClient
import com.mfl.core.data.Lookups
import com.mfl.core.data.ScheduleRow
import com.mfl.core.data.userMessage
import com.mfl.core.ui.theme.MflColors
import com.mfl.core.util.formatDate
import com.mfl.core.util.formatWhole
import com.mfl.core.util.orNull
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import java.util.UUID
import kotlin.math.max

val PAYMENT_MODES: List<String> = listOf("CASH", "UPI", "BANK_TRANSFER", "CHEQUE")

/**
 * Collect a payment against one installment (POST /payments).
 * One idempotency key per dialog opening, so a retry cannot apply the same payment twice.
 * The total (manager + owner) must be > 0 and no more than the balance due.
 */
@Composable
fun CollectDialog(schedule: ScheduleRow, onDismiss: () -> Unit, onDone: () -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val idempotencyKey = remember { UUID.randomUUID().toString() }

    var manager by remember { mutableStateOf("") }
    var owner by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf("CASH") }
    var ref by remember { mutableStateOf("") }
    var payer by remember { mutableStateOf(schedule.payerName.orEmpty()) }
    var error by remember { mutableStateOf<String?>(null) }
    var saving by remember { mutableStateOf(false) }

    val m = manager.toDoubleOrNull() ?: 0.0
    val o = owner.toDoubleOrNull() ?: 0.0
    val total = m + o
    val balance = schedule.balanceDue
    val after = balance - total

    FormDialog(
        title = "Collect — Loan #${schedule.loanId}, kist ${schedule.currentKistNo}",
        confirmText = "Confirm & save receipt",
        saving = saving,
        error = error,
        onDismiss = onDismiss,
        onConfirm = {
            when {
                total <= 0 -> error = "Enter the amount received"
                total > balance -> error = "Total exceeds the balance due of ${formatWhole(balance)}"
                else -> {
                    error = null
                    saving = true
                    scope.launch {
                        try {
                            val body: JsonObject = buildJsonObject {
                                put("idempotency_key", idempotencyKey)
                                put("payment_schedule_id", schedule.paymentScheduleId)
                                put("manager_received_amount", m)
                                put("owner_received_amount", o)
                                put("payment_mode", mode)
                                put("transaction_ref", ref.orNull())
                                put("payer_name", payer.orNull())
                            }
                            ApiClient.execute("/payments", "POST", body = body)
                            Lookups.invalidate()
                            Toast.makeText(context, "Payment recorded", Toast.LENGTH_SHORT).show()
                            onDone()
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            error = e.userMessage()
                        } finally {
                            saving = false
                        }
                    }
                }
            }
        },
    ) {
        Text(
            "Borrower: ${schedule.customerName} · Installment ${formatDate(schedule.installmentDate)}",
            fontSize = 13.sp,
        )
        Text(
            "Balance due ${formatWhole(balance)} · After this payment ${formatWhole(max(after, 0.0))}",
            fontSize = 13.sp,
            color = if (after < 0) MflColors.Danger else MflColors.Ink,
        )
        FormField("Manager received (₹)", manager, onChange = { manager = it }, keyboard = KeyboardType.Decimal)
        FormField("Owner received (₹)", owner, onChange = { owner = it }, keyboard = KeyboardType.Decimal)
        OptionPicker("Payment mode", mode, PAYMENT_MODES.map { it to it }, onPick = { mode = it })
        FormField(
            "Transaction reference",
            ref,
            onChange = { ref = it },
            hint = "Required for UPI, bank transfer or cheque",
        )
        FormField("Payer name", payer, onChange = { payer = it })
        Text("Payment amount: ${formatWhole(total)}", fontSize = 14.sp)
    }
}
