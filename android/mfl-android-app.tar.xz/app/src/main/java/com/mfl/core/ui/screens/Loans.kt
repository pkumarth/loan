package com.mfl.core.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mfl.core.data.Address
import com.mfl.core.data.Customer
import com.mfl.core.data.Loan
import com.mfl.core.data.Lookups
import com.mfl.core.data.listPage
import com.mfl.core.ui.components.*
import com.mfl.core.util.LOAN_TYPE_LABEL
import com.mfl.core.util.accruedInterest
import com.mfl.core.util.formatDate
import com.mfl.core.util.formatWhole
import com.mfl.core.util.isoToday
import com.mfl.core.util.orNull
import com.mfl.core.util.plainNumber

internal val LOAN_STATUSES = listOf("DRAFT", "ACTIVE", "CLOSED", "RESTRUCTURED", "DEFAULTED")

private class LoansLookup(val customers: Map<Long, Customer>, val addresses: Map<Long, Address>)

/**
 * Loans portfolio. Loan ID opens the full field list for that loan.
 * Interest is computed for MI and OT loans only: principal × rate × days ÷ 3000.
 */
@Composable
fun LoansScreen(onNavigate: (String) -> Unit) {
    var account by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    val today = remember { isoToday() }

    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        PageHeader("Loans") {
            ActionButton("New loan", { onNavigate("loans/new") }, primary = true)
        }
        FilterRow {
            FilterText("Account no", account, { account = it }, Modifier.weight(1.4f))
            FilterPicker(
                "Type", type,
                listOf("" to "All types", "EMI" to "EMI", "MONTHLY_INTEREST" to "MI", "ONETIME" to "OT"),
                { type = it }, Modifier.weight(1f),
            )
            FilterPicker(
                "Status", status,
                listOf("" to "All statuses") + LOAN_STATUSES.map { it to it },
                { status = it }, Modifier.weight(1.2f),
            )
        }
        PagedTable(
            filterKey = listOf(account, type, status),
            reloadKey = 0,
            emptyText = "No loans match these filters.",
            fetch = { p, size ->
                val list = listPage<Loan>(
                    "/loans", p,
                    mapOf("loan_type" to type.orNull(), "loan_status" to status.orNull(), "loan_account_no" to account.orNull()),
                    size,
                )
                PageResult(list.rows, list.totalPages, LoansLookup(Lookups.customers(), Lookups.addresses()))
            },
            columns = { lookup -> loanColumns(lookup, today, onNavigate) },
            modifier = Modifier.weight(1f),
        )
    }
}

private fun loanColumns(view: LoansLookup, today: String, onNavigate: (String) -> Unit): List<DataColumn<Loan>> {
    fun customerOf(l: Loan): Customer? = view.customers[l.customerId]
    fun mohallaOf(l: Loan): String? = customerOf(l)?.let { view.addresses[it.addressId]?.mohalla }

    return listOf(
        DataColumn<Loan>("Loan ID", 80.dp, onClick = { onNavigate("loans/${it.loanId}/fields") }) { it.loanId.toString() },
        DataColumn<Loan>("Customer", 150.dp) { l -> customerOf(l)?.customerName ?: "#${l.customerId}" },
        DataColumn<Loan>("Guarantor", 140.dp) { l -> l.guarantorId?.let { view.customers[it]?.customerName ?: "#$it" } ?: "—" },
        DataColumn<Loan>("Mohalla", 110.dp) { l -> mohallaOf(l) ?: "—" },
        DataColumn<Loan>("Mobile", 120.dp) { l -> customerOf(l)?.customerMobile ?: "—" },
        DataColumn<Loan>("Principal", 110.dp, right = true) { formatWhole(it.remPrincipalAmt) },
        DataColumn<Loan>("Rate", 70.dp, right = true) { plainNumber(it.rateOfInterest) },
        DataColumn<Loan>("Borrowing date", 110.dp) { formatDate(it.modifiedBorrowingDate) },
        DataColumn<Loan>("Loan type", 80.dp) { LOAN_TYPE_LABEL[it.loanType] ?: it.loanType },
        DataColumn<Loan>("EMI start", 110.dp) { formatDate(it.emiStartDate) },
        DataColumn<Loan>("First installment", 110.dp) { formatDate(it.emiFirstInstallmentDate) },
        DataColumn<Loan>("Last installment", 110.dp) { formatDate(it.emiLastInstallmentDate) },
        DataColumn<Loan>("Kists", 70.dp, right = true) { it.totalNoOfKist.toString() },
        DataColumn<Loan>("Installment amt", 110.dp, right = true) { formatWhole(it.installmentAmount) },
        DataColumn<Loan>("Interest", 90.dp, right = true) { l ->
            if (l.loanType == "EMI") "—"
            else formatWhole(accruedInterest(l.remPrincipalAmt, l.rateOfInterest, l.modifiedBorrowingDate, today))
        },
        DataColumn<Loan>("Loan status", 100.dp, badge = true) { it.loanStatus },
        DataColumn<Loan>("Manager", 100.dp, right = true) { formatWhole(it.managerAmount) },
        DataColumn<Loan>("Owner", 100.dp, right = true) { formatWhole(it.ownerAmount) },
        DataColumn<Loan>("Processing fee", 100.dp, right = true) { formatWhole(it.processingFee) },
        DataColumn<Loan>("Purpose", 140.dp) { it.loanPurpose ?: "—" },
    )
}

/** Every field of one loan. Pencil on status, purpose, description, rate, processing fee and manager/owner names. */
@Composable
fun LoanFieldsScreen(id: String, onNavigate: (String) -> Unit, onBack: () -> Unit) {
    EntityDetailScreen(
        title = "Loan $id",
        path = "/loans/$id",
        editable = mapOf(
            "loan_status" to EditSpec(EditKind.OPTIONS, LOAN_STATUSES),
            "loan_purpose" to EditSpec(EditKind.TEXT),
            "description" to EditSpec(EditKind.TEXT),
            "rate_of_interest" to EditSpec(EditKind.DECIMAL),
            "processing_fee" to EditSpec(EditKind.MONEY),
            "manager_name" to EditSpec(EditKind.TEXT),
            "owner_name" to EditSpec(EditKind.TEXT),
        ),
        linkRoutes = mapOf("customer_id" to "customers/{}", "guarantor_id" to "customers/{}"),
        onNavigate = onNavigate,
        onBack = onBack,
    )
}
