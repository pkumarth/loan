package com.mfl.core.ui.screens
import androidx.compose.ui.unit.sp
import androidx.compose.ui.Alignment

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.mfl.core.data.ApiClient
import com.mfl.core.data.GenerateResult
import com.mfl.core.data.Lookups
import com.mfl.core.data.userMessage
import com.mfl.core.ui.components.*
import com.mfl.core.ui.theme.MflColors
import com.mfl.core.util.isoToday
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

/**
 * Generate next month's installments. A dry run must come first; Generate is enabled only for the
 * same year and month that was previewed.
 */
@Composable
fun GenerateMonthlyScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val today = remember { isoToday() }
    var year by remember { mutableStateOf(today.substring(0, 4)) }
    var month by remember { mutableStateOf(today.substring(5, 7).toInt().toString()) }
    var result by remember { mutableStateOf<GenerateResult?>(null) }
    var resultWasDry by remember { mutableStateOf(true) }
    var previewedKey by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val y = year.toIntOrNull()
    val m = month.toIntOrNull()?.takeIf { it in 1..12 }
    val key = if (y != null && m != null) "$y-$m" else null

    fun run(dry: Boolean) {
        if (y == null || m == null) {
            error = "Enter a valid year and month (1–12)"
            return
        }
        busy = true
        error = null
        scope.launch {
            try {
                val body = buildJsonObject {
                    put("billing_year", y)
                    put("billing_month", m)
                    put("dry_run", dry)
                }
                result = ApiClient.call<GenerateResult>("/payment-schedules/generate-monthly", "POST", body = body).data
                resultWasDry = dry
                if (dry) {
                    previewedKey = key
                } else {
                    previewedKey = null
                    Lookups.invalidate()
                    toast(context, "${result?.generatedCount ?: 0} installments generated")
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = e.userMessage()
            } finally {
                busy = false
            }
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        PageHeader("Generate monthly installments") {
            TextButton(onClick = onBack) { Text("Back", fontSize = 13.sp) }
        }

        MflCard(title = "Billing period") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FormField(
                    "Year", year, onChange = { year = it.filter(Char::isDigit).take(4) },
                    keyboard = KeyboardType.Number, modifier = Modifier.weight(1f),
                )
                FormField(
                    "Month (1–12)", month, onChange = { month = it.filter(Char::isDigit).take(2) },
                    keyboard = KeyboardType.Number, modifier = Modifier.weight(1f),
                )
            }
            error?.let { ErrorText(it) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionButton(text = "Dry run", onClick = { run(true) }, enabled = !busy, modifier = Modifier.weight(1f))
                ActionButton(
                    text = "Generate",
                    onClick = { run(false) },
                    primary = true,
                    enabled = !busy && key != null && previewedKey == key,
                    modifier = Modifier.weight(1f),
                )
            }
            if (!busy && key != null && previewedKey != key) {
                Text("Run a dry run for this period before generating.", fontSize = 11.sp, color = MflColors.Muted)
            }
        }

        result?.let { r ->
            MflCard(title = "Result for ${r.billingPeriod}") {
                if (resultWasDry) DryRunBanner()
                KeyValueRow("Generated", r.generatedCount.toString())
                KeyValueRow("Cycle 12th", r.cycle12Count.toString())
                KeyValueRow("Cycle 25th", r.cycle25Count.toString())
                KeyValueRow("Skipped: already generated", r.skippedAlreadyGenerated.toString())
                KeyValueRow("Skipped: kists completed", r.skippedKistsCompleted.toString())
                KeyValueRow("Skipped: not due yet", r.skippedNotDueYet.toString())
            }
        }
    }
}
