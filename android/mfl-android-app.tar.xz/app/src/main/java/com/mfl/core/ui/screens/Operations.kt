package com.mfl.core.ui.screens
import androidx.compose.ui.unit.sp
import androidx.compose.ui.Alignment

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.mfl.core.data.ApiClient
import com.mfl.core.data.Lookups
import com.mfl.core.data.OverdueResult
import com.mfl.core.data.ReportResult
import com.mfl.core.data.ScheduleRow
import com.mfl.core.data.listPage
import com.mfl.core.data.userMessage
import com.mfl.core.ui.components.*
import com.mfl.core.util.formatDate
import com.mfl.core.util.formatWhole
import com.mfl.core.util.isoToday
import com.mfl.core.util.orNull
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

/** Maintenance jobs and the billing report: overdue compute, report rebuild, and payment by loan ID. */
@Composable
fun OperationsScreen(onNavigate: (String) -> Unit) {
    var collecting by remember { mutableStateOf<ScheduleRow?>(null) }
    val today = remember { isoToday() }
    var year by remember { mutableStateOf(today.substring(0, 4)) }
    var month by remember { mutableStateOf(today.substring(5, 7).toInt().toString()) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        PageHeader("Operations")
        OverdueCard()
        ReportCard(year, month, onYear = { year = it }, onMonth = { month = it }, onCollect = { collecting = it })
        RecordPaymentCard(onCollect = { collecting = it })
    }

    collecting?.let { row ->
        CollectDialog(
            schedule = row,
            onDismiss = { collecting = null },
            onDone = { collecting = null },
        )
    }
}

@Composable
private fun OverdueCard() {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var runDate by remember { mutableStateOf(isoToday()) }
    var loanId by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<OverdueResult?>(null) }
    var resultWasDry by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun run(dry: Boolean) {
        busy = true
        error = null
        scope.launch {
            try {
                val body = buildJsonObject {
                    put("run_date", runDate)
                    put("loan_id", loanId.toLongOrNull())
                    put("dry_run", dry)
                }
                result = ApiClient.call<OverdueResult>("/payment-schedules/overdue-compute", "POST", body = body).data
                resultWasDry = dry
                if (!dry) {
                    Lookups.invalidate()
                    toast(context, "Overdue computed for ${result?.rowCount ?: 0} installments")
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = e.userMessage()
            } finally {
                busy = false
            }
        }
    }

    MflCard(title = "Overdue compute") {
        FormField("Run date (YYYY-MM-DD)", runDate, onChange = { runDate = it })
        FormField(
            "Loan ID (optional, blank = all)", loanId,
            onChange = { loanId = it.filter(Char::isDigit) }, keyboard = KeyboardType.Number,
        )
        error?.let { ErrorText(it) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ActionButton(text = "Dry run", onClick = { run(true) }, enabled = !busy, modifier = Modifier.weight(1f))
            ActionButton(text = "Run & save", onClick = { run(false) }, primary = true, enabled = !busy, modifier = Modifier.weight(1f))
        }
        result?.let { r ->
            if (resultWasDry) DryRunBanner()
            KeyValueRow("Run date", formatDate(r.runDate))
            KeyValueRow("Installments", r.rowCount.toString())
            KeyValueRow("Total due", formatWhole(r.totalDue))
        }
    }
}

@Composable
private fun ReportCard(
    year: String,
    month: String,
    onYear: (String) -> Unit,
    onMonth: (String) -> Unit,
    onCollect: (ScheduleRow) -> Unit,
) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var result by remember { mutableStateOf<ReportResult?>(null) }
    var resultWasDry by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var reportPage by remember { mutableIntStateOf(1) }
    var reloadTick by remember { mutableIntStateOf(0) }

    fun run(dry: Boolean) {
        val y = year.toIntOrNull()
        val m = month.toIntOrNull()
        if (y == null || m == null || m !in 1..12) {
            error = "Enter a valid year and month (1–12)"
            return
        }
        busy = true
        error = null
        scope.launch {
            try {
                val body = buildJsonObject {
                    put("billing_year", y)
                    put("billing_month", m)
                    put("dry_run", dry)
                }
                result = ApiClient.call<ReportResult>("/payment-schedules/report-generate", "POST", body = body).data
                resultWasDry = dry
                if (!dry) {
                    toast(context, "Report rebuilt: ${result?.rowCount ?: 0} rows")
                    reloadTick++
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = e.userMessage()
            } finally {
                busy = false
            }
        }
    }

    MflCard(title = "Billing report") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FormField("Year", year, onChange = { onYear(it.filter(Char::isDigit).take(4)) }, keyboard = KeyboardType.Number, modifier = Modifier.weight(1f))
            FormField("Month", month, onChange = { onMonth(it.filter(Char::isDigit).take(2)) }, keyboard = KeyboardType.Number, modifier = Modifier.weight(1f))
        }
        error?.let { ErrorText(it) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ActionButton(text = "Dry run", onClick = { run(true) }, enabled = !busy, modifier = Modifier.weight(1f))
            ActionButton(text = "Rebuild report", onClick = { run(false) }, primary = true, enabled = !busy, modifier = Modifier.weight(1f))
        }
        result?.let { r ->
            if (resultWasDry) DryRunBanner()
            KeyValueRow("Rows", r.rowCount.toString())
            KeyValueRow("Total overdue", formatWhole(r.totalOverdueAmount))
            r.statusCounts.forEach { (k, v) -> KeyValueRow(k, v.toString()) }
        }
    }

    ReportTable(
        year = year,
        month = month,
        page = reportPage,
        onPage = { reportPage = it },
        reloadKey = reloadTick,
        onCollect = onCollect,
    )
}

@Composable
private fun ReportTable(
    year: String,
    month: String,
    page: Int,
    onPage: (Int) -> Unit,
    reloadKey: Int,
    onCollect: (ScheduleRow) -> Unit,
) {
    val remote = rememberRemote(year, month, page, reloadKey) {
        listPage<ScheduleRow>(
            "/payment-schedules", page,
            mapOf(
                "billing_year" to year.toIntOrNull(),
                "billing_month" to month.toIntOrNull(),
            ),
        )
    }

    RemoteContent(remote) { list ->
        if (list.rows.isEmpty()) {
            EmptyText("No report rows for this period.")
        } else {
            DataTable(
                rows = list.rows,
                columns = listOf(
                    DataColumn<ScheduleRow>("Schedule ID", 90.dp) { it.paymentScheduleId.toString() },
                    DataColumn<ScheduleRow>("Loan ID", 80.dp) { it.loanId.toString() },
                    DataColumn<ScheduleRow>("Customer", 150.dp) { it.customerName },
                    DataColumn<ScheduleRow>("Kist", 70.dp, right = true) { it.currentKistNo.toString() },
                    DataColumn<ScheduleRow>("Installment date", 110.dp) { formatDate(it.installmentDate) },
                    DataColumn<ScheduleRow>("Installment amt", 110.dp, right = true) { formatWhole(it.installmentAmount) },
                    DataColumn<ScheduleRow>("Fine", 90.dp, right = true) { formatWhole(it.fineAmount) },
                    DataColumn<ScheduleRow>("Balance due", 110.dp, right = true) { formatWhole(it.balanceDue) },
                    DataColumn<ScheduleRow>("Status", 100.dp, badge = true) { it.status },
                ),
                rowAction = { row ->
                    if (row.balanceDue > 0) ActionButton(text = "Collect", onClick = { onCollect(row) })
                },
            )
        }
        PaginationBar(page, list.totalPages) { onPage(it) }
    }
}

@Composable
private fun RecordPaymentCard(onCollect: (ScheduleRow) -> Unit) {
    val scope = rememberCoroutineScope()
    var loanId by remember { mutableStateOf("") }
    var rows by remember { mutableStateOf<List<ScheduleRow>?>(null) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun load() {
        val id = loanId.toLongOrNull()
        if (id == null) {
            error = "Enter a loan ID"
            return
        }
        busy = true
        error = null
        scope.launch {
            try {
                rows = listPage<ScheduleRow>("/payment-schedules", 1, mapOf("loan_id" to id)).rows
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = e.userMessage()
            } finally {
                busy = false
            }
        }
    }

    MflCard(title = "Record payment by loan ID") {
        FormField("Loan ID", loanId, onChange = { loanId = it.filter(Char::isDigit) }, keyboard = KeyboardType.Number, error = error)
        ActionButton(text = "Load installments", onClick = { load() }, primary = true, enabled = !busy, modifier = Modifier.fillMaxWidth())
        rows?.let { list ->
            if (list.isEmpty()) {
                EmptyText("No installments for this loan.")
            } else {
                list.forEach { r ->
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.weight(1f)) {
                            Text("Kist #${r.currentKistNo} · ${formatDate(r.installmentDate)}", fontSize = 13.sp)
                            Text(
                                "Balance due ${formatWhole(r.balanceDue)} · ${r.status}",
                                fontSize = 11.sp,
                                color = com.mfl.core.ui.theme.MflColors.Muted,
                            )
                        }
                        if (r.balanceDue > 0) ActionButton(text = "Collect", onClick = { onCollect(r) })
                    }
                }
            }
        }
    }
}
