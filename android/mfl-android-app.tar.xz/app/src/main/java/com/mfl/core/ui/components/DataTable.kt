package com.mfl.core.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mfl.core.ui.theme.MflColors

/** Row height is fixed so the page size can be worked out from the screen height. */
val TABLE_ROW_HEIGHT = 48.dp
val TABLE_HEADER_HEIGHT = 40.dp

/**
 * One table column.
 * [width] is the natural width. When the table is narrower than the sum of widths, the columns are
 * stretched to fill the screen; when it is wider, the non-first columns scroll sideways.
 * [badge] draws the value as a status pill. [onClick] makes the cell a link (not for the "—" placeholder).
 */
data class DataColumn<T>(
    val header: String,
    val width: Dp = 110.dp,
    val right: Boolean = false,
    val badge: Boolean = false,
    val onClick: ((T) -> Unit)? = null,
    val text: (T) -> String,
)

private val ACTION_WIDTH = 120.dp

/**
 * Table in the web style (yellow header, alternating rows). It never scrolls vertically: the caller sizes
 * the page (see [PagedTable]). The first column is pinned on the left so the record stays identifiable
 * while the other columns scroll.
 */
@Composable
fun <T> DataTable(
    rows: List<T>,
    columns: List<DataColumn<T>>,
    modifier: Modifier = Modifier,
    rowAction: (@Composable (T) -> Unit)? = null,
) {
    if (columns.isEmpty()) return
    BoxWithConstraints(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .border(1.dp, MflColors.Border, RoundedCornerShape(8.dp))
            .background(Color.White),
    ) {
        val actionWidth = if (rowAction != null) ACTION_WIDTH else 0.dp
        val available = maxWidth - actionWidth
        val natural = columns.fold(0.dp) { acc, c -> acc + c.width }
        // Stretch to fill the screen when everything fits; otherwise keep natural widths and scroll.
        val scale = if (natural < available) available.value / natural.value else 1f
        val widths = columns.map { it.width * scale }
        val pinned = columns.first()
        val pinnedWidth = widths.first()
        val rest = columns.drop(1)
        val restWidths = widths.drop(1)
        val restTotal = restWidths.fold(0.dp) { acc, w -> acc + w }
        val scroll = rememberScrollState()

        Row(Modifier.fillMaxWidth()) {
            // Pinned first column.
            Column(Modifier.width(pinnedWidth)) {
                HeaderCell(pinned.header, pinnedWidth, pinned.right)
                rows.forEachIndexed { index, row ->
                    BodyCell(pinned, row, pinnedWidth, index)
                }
            }
            // Scrollable columns.
            Box(Modifier.weight(1f).horizontalScroll(scroll)) {
                Column(Modifier.width(restTotal)) {
                    Row(
                        Modifier.height(TABLE_HEADER_HEIGHT).fillMaxWidth().background(MflColors.HeaderBg),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        rest.forEachIndexed { i, c -> HeaderCell(c.header, restWidths[i], c.right) }
                    }
                    rows.forEachIndexed { index, row ->
                        Row(
                            Modifier.height(TABLE_ROW_HEIGHT).fillMaxWidth().background(rowColor(index)),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            rest.forEachIndexed { i, c -> CellContent(c, row, restWidths[i]) }
                        }
                    }
                }
            }
            // Fixed action column.
            if (rowAction != null) {
                Column(Modifier.width(ACTION_WIDTH)) {
                    Box(Modifier.height(TABLE_HEADER_HEIGHT).fillMaxWidth().background(MflColors.HeaderBg))
                    rows.forEachIndexed { index, row ->
                        Box(
                            Modifier.height(TABLE_ROW_HEIGHT).width(ACTION_WIDTH).background(rowColor(index)).padding(4.dp),
                            contentAlignment = Alignment.Center,
                        ) { rowAction(row) }
                    }
                }
            }
        }
    }
}

private fun rowColor(index: Int): Color = if (index % 2 == 0) MflColors.RowOdd else MflColors.RowEven

@Composable
private fun HeaderCell(text: String, width: Dp, right: Boolean) {
    Box(
        Modifier.width(width).height(TABLE_HEADER_HEIGHT).background(MflColors.HeaderBg).padding(horizontal = 6.dp),
        contentAlignment = if (right) Alignment.CenterEnd else Alignment.CenterStart,
    ) {
        Text(
            text,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = MflColors.HeaderText,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun <T> BodyCell(column: DataColumn<T>, row: T, width: Dp, index: Int) {
    Row(
        Modifier.height(TABLE_ROW_HEIGHT).width(width).background(rowColor(index)),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CellContent(column, row, width)
    }
}

@Composable
private fun <T> CellContent(column: DataColumn<T>, row: T, width: Dp) {
    val value = column.text(row)
    val click = column.onClick
    val linkable = click != null && value != "—"
    Box(
        Modifier.width(width).fillMaxHeight().padding(horizontal = 6.dp),
        contentAlignment = if (column.right) Alignment.CenterEnd else Alignment.CenterStart,
    ) {
        when {
            column.badge -> StatusBadge(value)
            linkable -> Text(
                value,
                fontSize = 13.sp,
                color = MflColors.Accent,
                textDecoration = TextDecoration.Underline,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.clickable { click?.invoke(row) },
            )
            else -> Text(value, fontSize = 13.sp, color = MflColors.Ink, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}
