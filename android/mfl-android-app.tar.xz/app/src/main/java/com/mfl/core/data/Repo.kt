package com.mfl.core.data

import kotlinx.serialization.json.JsonObject

/** One page of a list endpoint, with the total page count for the pager. */
data class ListPage<T>(val rows: List<T>, val totalPages: Int)

/**
 * Fetches one page of a list endpoint. Filters with null values are dropped by ApiClient.
 * [size] is chosen by the screen so one page exactly fills the visible table.
 */
suspend inline fun <reified T> listPage(
    path: String,
    page: Int,
    filters: Map<String, Any?> = emptyMap(),
    size: Int = 50,
): ListPage<T> {
    val res = ApiClient.call<List<T>>(path, query = filters + mapOf("page" to page, "size" to size))
    return ListPage(res.data, res.pagination?.totalPages ?: 1)
}

/** Loads every page of a list endpoint. Used for join lookups (the list endpoints do not carry names). */
suspend inline fun <reified T> fetchAll(path: String): List<T> {
    val out = mutableListOf<T>()
    var page = 1
    do {
        val res = ApiClient.call<List<T>>(path, query = mapOf("page" to page, "size" to 200))
        out += res.data
        page++
    } while (res.pagination?.hasNext == true)
    return out
}

/**
 * Client-side joins, same as src/lib/lookups.ts. The loans list only carries ids, so customer name,
 * mohalla and guarantor name come from the customer, address and schedule records.
 * Results are cached for 60 seconds; call invalidate() after any write.
 */
object Lookups {
    private const val TTL_MS = 60_000L

    private class Stamp<T>(val at: Long, val value: T)

    private var customerCache: Stamp<Map<Long, Customer>>? = null
    private var addressCache: Stamp<Map<Long, Address>>? = null
    private var scheduleCache: Stamp<Map<Long, ScheduleRow>>? = null

    private fun <T> fresh(s: Stamp<T>?): T? =
        s?.takeIf { System.currentTimeMillis() - it.at < TTL_MS }?.value

    suspend fun customers(): Map<Long, Customer> =
        fresh(customerCache) ?: fetchAll<Customer>("/customers")
            .associateBy { it.customerId }
            .also { customerCache = Stamp(System.currentTimeMillis(), it) }

    suspend fun addresses(): Map<Long, Address> =
        fresh(addressCache) ?: fetchAll<Address>("/addresses")
            .associateBy { it.addressId }
            .also { addressCache = Stamp(System.currentTimeMillis(), it) }

    suspend fun schedules(): Map<Long, ScheduleRow> =
        fresh(scheduleCache) ?: fetchAll<ScheduleRow>("/payment-schedules")
            .associateBy { it.paymentScheduleId }
            .also { scheduleCache = Stamp(System.currentTimeMillis(), it) }

    fun invalidate() {
        customerCache = null
        addressCache = null
        scheduleCache = null
    }
}

/** Shorthand used by detail screens that edit raw JSON objects. */
suspend fun rawObject(path: String): JsonObject =
    ApiClient.execute(path)["data"] as? JsonObject ?: JsonObject(emptyMap())
