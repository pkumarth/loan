package com.mfl.core.ui.screens
import com.mfl.core.ui.theme.MflColors
import androidx.compose.ui.unit.sp
import androidx.compose.ui.Alignment

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.mfl.core.data.ApiClient
import com.mfl.core.data.Loan
import com.mfl.core.data.Lookups
import com.mfl.core.data.userMessage
import com.mfl.core.ui.components.*
import com.mfl.core.util.LOAN_TYPE_LABEL
import com.mfl.core.util.addMonthsIso
import com.mfl.core.util.formatWhole
import com.mfl.core.util.isoToday
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlin.math.abs

/** Capital split rule from the web validator: manager + owner must equal principal. */
private fun splitProblem(principal: Double, manager: Double, owner: Double): String? = when {
    principal <= 0 -> "Principal must be greater than 0"
    manager < 0 || owner < 0 -> "Cannot be negative"
    abs(manager + owner - principal) >= 0.005 -> "Manager + owner must equal principal"
    else -> null
}

/** New loan (POST /loans). Same fields, defaults and checks as the web form. */
@Composable
fun LoanFormScreen(onNavigate: (String) -> Unit, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var loanType by remember { mutableStateOf("EMI") }
    val f = remember {
        mutableStateMapOf(
            "customer_id" to "",
            "principal_amt" to "",
            "rate_of_interest" to "2",
            "borrowing_date" to isoToday(),
            "installment_amount" to "",
            "total_no_of_kist" to "",
            "processing_fee" to "200",
            "loan_purpose" to "",
            "loan_parent_id" to "",
            "manager_name" to "",
            "manager_amount" to "0",
            "owner_name" to "",
            "owner_amount" to "0",
        )
    }
    var errors by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var confirming by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    var saveError by remember { mutableStateOf<String?>(null) }

    val isOnetime = loanType == "ONETIME"
    val principal = f.getValue("principal_amt").toDoubleOrNull() ?: 0.0
    val manager = f.getValue("manager_amount").toDoubleOrNull() ?: 0.0
    val owner = f.getValue("owner_amount").toDoubleOrNull() ?: 0.0
    val split = splitProblem(principal, manager, owner)
    val kists = f.getValue("total_no_of_kist").toIntOrNull()
    val maturity = kists?.takeIf { !isOnetime && it > 0 }?.let { addMonthsIso(f.getValue("borrowing_date"), it) }

    fun review() {
        val errs = mutableMapOf<String, String>()
        if (f.getValue("customer_id").toLongOrNull() == null) errs["customer_id"] = "Customer ID is required"
        if (principal <= 0) errs["principal_amt"] = "Principal must be greater than 0"
        if (!isOnetime && (f.getValue("installment_amount").isBlank() || kists == null)) {
            errs["installment_amount"] = "Installment and kist count are required"
        }
        split?.let { errs["owner_amount"] = it }
        errors = errs
        if (errs.isEmpty()) confirming = true
    }

    fun submit() {
        saving = true
        saveError = null
        scope.launch {
            try {
                val body = buildJsonObject {
                    put("customer_id", f.getValue("customer_id").toLong())
                    put("loan_type", loanType)
                    put("principal_amt", principal)
                    put("rate_of_interest", f.getValue("rate_of_interest").toDoubleOrNull())
                    put("borrowing_date", f.getValue("borrowing_date"))
                    put("installment_amount", if (isOnetime) 0.0 else f.getValue("installment_amount").toDoubleOrNull())
                    put("total_no_of_kist", if (isOnetime) null else kists)
                    put("manager_name", f.getValue("manager_name").ifBlank { null })
                    put("manager_amount", manager)
                    put("owner_name", f.getValue("owner_name").ifBlank { null })
                    put("owner_amount", owner)
                    put("processing_fee", f.getValue("processing_fee").toDoubleOrNull() ?: 0.0)
                    put("loan_purpose", f.getValue("loan_purpose").ifBlank { null })
                    put("loan_parent_id", f.getValue("loan_parent_id").toLongOrNull())
                }
                val loan = ApiClient.call<Loan>("/loans", "POST", body = body).data
                Lookups.invalidate()
                confirming = false
                toast(context, "Loan ${loan.loanAccountNo} created")
                onNavigate("loans/${loan.loanId}/fields")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                saveError = e.userMessage()
            } finally {
                saving = false
            }
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        PageHeader("New loan") {
            TextButton(onClick = onBack) { Text("Back", fontSize = 13.sp) }
        }

        MflCard(title = "Borrower & terms") {
            FormField(
                "Customer ID", f.getValue("customer_id"),
                onChange = { f["customer_id"] = it.filter(Char::isDigit) },
                error = errors["customer_id"], keyboard = KeyboardType.Number,
            )
            OptionPicker(
                "Loan type", loanType,
                listOf("EMI" to "EMI", "MONTHLY_INTEREST" to "MI", "ONETIME" to "OT"),
                onPick = { loanType = it },
            )
            FormField(
                "Principal (₹)", f.getValue("principal_amt"),
                onChange = { f["principal_amt"] = it },
                error = errors["principal_amt"], keyboard = KeyboardType.Decimal,
            )
            FormField(
                "Rate of interest (%)", f.getValue("rate_of_interest"),
                onChange = { f["rate_of_interest"] = it }, hint = "Default 2%", keyboard = KeyboardType.Decimal,
            )
            FormField(
                "Borrowing date (YYYY-MM-DD)", f.getValue("borrowing_date"),
                onChange = { f["borrowing_date"] = it },
            )
            FormField("Parent loan ID (optional)", f.getValue("loan_parent_id"), onChange = { f["loan_parent_id"] = it })
            if (!isOnetime) {
                FormField(
                    "Installment amount (₹)", f.getValue("installment_amount"),
                    onChange = { f["installment_amount"] = it },
                    error = errors["installment_amount"], keyboard = KeyboardType.Decimal,
                )
                FormField(
                    "Number of kists", f.getValue("total_no_of_kist"),
                    onChange = { f["total_no_of_kist"] = it.filter(Char::isDigit) }, keyboard = KeyboardType.Number,
                )
            }
            FormField(
                "Processing fee (₹)", f.getValue("processing_fee"),
                onChange = { f["processing_fee"] = it }, keyboard = KeyboardType.Decimal,
            )
            FormField("Purpose", f.getValue("loan_purpose"), onChange = { f["loan_purpose"] = it })
            maturity?.let { Text("Last installment (approx.): ${com.mfl.core.util.formatDate(it)}", fontSize = 13.sp) }
        }

        MflCard(title = "Capital split") {
            FormField("Manager name", f.getValue("manager_name"), onChange = { f["manager_name"] = it })
            FormField(
                "Manager amount (₹)", f.getValue("manager_amount"),
                onChange = { f["manager_amount"] = it }, keyboard = KeyboardType.Decimal,
            )
            FormField("Owner name", f.getValue("owner_name"), onChange = { f["owner_name"] = it })
            FormField(
                "Owner amount (₹)", f.getValue("owner_amount"),
                onChange = { f["owner_amount"] = it },
                error = errors["owner_amount"], keyboard = KeyboardType.Decimal,
            )
            Text(
                split ?: "Split balances: ${formatWhole(manager + owner)} of ${formatWhole(principal)}",
                fontSize = 13.sp,
                color = if (split != null) MflColors.Danger else MflColors.Muted,
            )
            ActionButton(text = "Review loan", onClick = { review() }, primary = true, modifier = Modifier.fillMaxWidth())
        }
    }

    if (confirming) {
        FormDialog(
            title = "Confirm loan",
            confirmText = "Confirm & save",
            saving = saving,
            error = saveError,
            onDismiss = { confirming = false },
            onConfirm = { submit() },
        ) {
            Text(
                "Create a ${LOAN_TYPE_LABEL[loanType] ?: loanType} loan of ${formatWhole(principal)} for customer " +
                    "#${f.getValue("customer_id")} at ${f.getValue("rate_of_interest")}% from ${f.getValue("borrowing_date")}?",
                fontSize = 15.sp,
            )
        }
    }
}
