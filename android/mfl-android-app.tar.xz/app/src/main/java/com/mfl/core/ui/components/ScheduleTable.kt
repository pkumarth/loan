package com.mfl.core.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import com.mfl.core.data.ScheduleRow
import com.mfl.core.util.LOAN_TYPE_LABEL
import com.mfl.core.util.formatDate
import com.mfl.core.util.formatWhole
import com.mfl.core.util.plainNumber

/**
 * Kist ledger columns, in the same order as the web Kist & Monthly Collections table.
 * Schedule ID opens the detail page. Loan ID calls [onLoanClick] (filters the list to that loan).
 */
fun scheduleColumns(
    onLoanClick: ((Long) -> Unit)?,
    onScheduleClick: (Long) -> Unit,
): List<DataColumn<ScheduleRow>> {
    val loanClick: ((ScheduleRow) -> Unit)? = onLoanClick?.let { f -> { r: ScheduleRow -> f(r.loanId) } }
    return listOf(
        DataColumn<ScheduleRow>("Schedule ID", 90.dp, onClick = { onScheduleClick(it.paymentScheduleId) }) { it.paymentScheduleId.toString() },
        DataColumn<ScheduleRow>("Loan ID", 80.dp, onClick = loanClick) { it.loanId.toString() },
        DataColumn<ScheduleRow>("Customer name", 150.dp) { it.customerName },
        DataColumn<ScheduleRow>("Guardian name", 130.dp) { it.guardianName },
        DataColumn<ScheduleRow>("Customer mobile", 120.dp) { it.customerMobile },
        DataColumn<ScheduleRow>("Mohalla", 110.dp) { it.mohalla ?: "—" },
        DataColumn<ScheduleRow>("Guarantor name", 130.dp) { it.guarantorName ?: "—" },
        DataColumn<ScheduleRow>("Principal", 110.dp, right = true) { formatWhole(it.remPrincipalAmt) },
        DataColumn<ScheduleRow>("Rate", 70.dp, right = true) { plainNumber(it.rateOfInterest) },
        DataColumn<ScheduleRow>("EMI start", 110.dp) { formatDate(it.emiStartDate) },
        DataColumn<ScheduleRow>("First installment", 110.dp) { formatDate(it.emiFirstInstallmentDate) },
        DataColumn<ScheduleRow>("Last installment", 110.dp) { formatDate(it.emiLastInstallmentDate) },
        DataColumn<ScheduleRow>("Loan type", 80.dp) { LOAN_TYPE_LABEL[it.loanType] ?: it.loanType },
        DataColumn<ScheduleRow>("Status", 100.dp, badge = true) { it.status },
        DataColumn<ScheduleRow>("Total kists", 80.dp, right = true) { it.totalNoOfKist.toString() },
        DataColumn<ScheduleRow>("Current kist", 80.dp, right = true) { it.currentKistNo.toString() },
        DataColumn<ScheduleRow>("Installment date", 110.dp) { formatDate(it.installmentDate) },
        DataColumn<ScheduleRow>("Installment amt", 110.dp, right = true) { formatWhole(it.installmentAmount) },
        DataColumn<ScheduleRow>("Fine", 80.dp, right = true) { formatWhole(it.fineAmount) },
        DataColumn<ScheduleRow>("Other", 80.dp, right = true) { formatWhole(it.otherAmount) },
        DataColumn<ScheduleRow>("Partial principal return", 130.dp, right = true) { formatWhole(it.partialPrincipalAmtReturn) },
        DataColumn<ScheduleRow>("Kist interest", 100.dp, right = true) { formatWhole(it.kistInterestAmount) },
        DataColumn<ScheduleRow>("Forgive", 80.dp, right = true) { formatWhole(it.forgiveAmount) },
        DataColumn<ScheduleRow>("Payment date", 110.dp) { formatDate(it.paymentDate) },
        DataColumn<ScheduleRow>("Amount paid", 100.dp, right = true) { formatWhole(it.amountPaid) },
        DataColumn<ScheduleRow>("Remaining principal", 130.dp, right = true) { formatWhole(it.remainingPrincipalAmt) },
        DataColumn<ScheduleRow>("Balance due", 100.dp, right = true) { formatWhole(it.balanceDue) },
        DataColumn<ScheduleRow>("Manager", 120.dp) { it.managerName ?: "—" },
        DataColumn<ScheduleRow>("Manager received", 120.dp, right = true) { formatWhole(it.managerReceivedAmount) },
        DataColumn<ScheduleRow>("Owner", 120.dp) { it.ownerName ?: "—" },
        DataColumn<ScheduleRow>("Owner received", 120.dp, right = true) { formatWhole(it.ownerReceivedAmount) },
        DataColumn<ScheduleRow>("Payer name", 120.dp) { it.payerName ?: "—" },
    )
}

@Composable
fun ScheduleTable(
    rows: List<ScheduleRow>,
    onScheduleClick: (Long) -> Unit,
    onLoanClick: ((Long) -> Unit)? = null,
    rowAction: (@Composable (ScheduleRow) -> Unit)? = null,
) {
    DataTable(rows, scheduleColumns(onLoanClick, onScheduleClick), rowAction = rowAction)
}
