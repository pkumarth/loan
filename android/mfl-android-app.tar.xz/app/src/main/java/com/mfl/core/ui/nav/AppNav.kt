package com.mfl.core.ui.nav

import androidx.compose.foundation.background
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBox
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavBackStackEntry
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.mfl.core.data.ApiClient
import com.mfl.core.data.AuthStore
import com.mfl.core.ui.components.ActionButton
import com.mfl.core.ui.components.toast
import com.mfl.core.ui.screens.AddressDetailScreen
import com.mfl.core.ui.screens.AddressesScreen
import com.mfl.core.ui.screens.CurrentPaymentScreen
import com.mfl.core.ui.screens.CustomerDetailScreen
import com.mfl.core.ui.screens.CustomersScreen
import com.mfl.core.ui.screens.DashboardScreen
import com.mfl.core.ui.screens.GenerateMonthlyScreen
import com.mfl.core.ui.screens.LoanFieldsScreen
import com.mfl.core.ui.screens.LoanFormScreen
import com.mfl.core.ui.screens.LoansScreen
import com.mfl.core.ui.screens.LoginScreen
import com.mfl.core.ui.screens.OnetimeScreen
import com.mfl.core.ui.screens.OperationsScreen
import com.mfl.core.ui.screens.ScheduleDetailScreen
import com.mfl.core.ui.screens.SchedulesScreen
import com.mfl.core.ui.theme.MflColors
import kotlinx.coroutines.delay

/** Route patterns. Keep the literal "schedules/generate" above "schedules/{id}" in the NavHost. */
object Routes {
    const val HOME = "home"
    const val CUSTOMERS = "customers"
    const val CUSTOMER = "customers/{id}"
    const val ADDRESSES = "addresses"
    const val ADDRESS = "addresses/{id}"
    const val LOANS = "loans"
    const val LOAN_NEW = "loans/new"
    const val LOAN_FIELDS = "loans/{id}/fields"
    const val SCHEDULES = "schedules"
    const val SCHEDULE_GENERATE = "schedules/generate"
    const val SCHEDULE = "schedules/{id}"
    const val CURRENT_PAYMENT = "current-payment"
    const val ONETIME = "onetime"
    const val OPERATIONS = "operations"
}

/**
 * Bottom-bar sections. Children are (label, route) pairs shown as sub-tabs under the top bar.
 * "Hisab & Ops" sits under Payments because one-time settlements and overdue runs are payment work.
 */
private class PrimaryTab(
    val label: String,
    val route: String,
    val icon: ImageVector,
    val children: List<Pair<String, String>> = emptyList(),
)

private val PRIMARY_TABS = listOf(
    PrimaryTab("Home", Routes.HOME, Icons.Filled.Home),
    PrimaryTab(
        "Customers", Routes.CUSTOMERS, Icons.Filled.Person,
        listOf("Customers" to Routes.CUSTOMERS, "Addresses" to Routes.ADDRESSES),
    ),
    PrimaryTab("Loans", Routes.LOANS, Icons.Filled.AccountBox),
    PrimaryTab("Kists", Routes.SCHEDULES, Icons.Filled.DateRange),
    PrimaryTab(
        "Payments", Routes.CURRENT_PAYMENT, Icons.Filled.Done,
        listOf(
            "Today" to Routes.CURRENT_PAYMENT,
            "Hisab" to Routes.ONETIME,
            "Overdue & reports" to Routes.OPERATIONS,
        ),
    ),
)

/** True when [route] is [href] or a page under it, e.g. "customers/{id}" under "customers". */
private fun matches(route: String, href: String): Boolean = route == href || route.startsWith("$href/")

fun NavBackStackEntry.arg(name: String): String = arguments?.getString(name).orEmpty()

/** Top-level switch: login until a session exists, then the app shell. */
@Composable
fun MflRoot() {
    var loggedIn by remember { mutableStateOf(AuthStore.current() != null) }
    if (loggedIn) {
        AppShell(onLogout = {
            AuthStore.clear()
            loggedIn = false
        })
    } else {
        LoginScreen(onLoggedIn = { loggedIn = true })
    }
}

@Composable
fun AppShell(onLogout: () -> Unit) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route.orEmpty()
    val current = PRIMARY_TABS.firstOrNull { t -> matches(route, t.route) || t.children.any { matches(route, it.second) } }
    val session = AuthStore.current()

    var online by remember { mutableStateOf<Boolean?>(null) }
    LaunchedEffect(Unit) {
        while (true) {
            online = ApiClient.health()
            delay(60_000)
        }
    }

    val go: (String) -> Unit = { target -> nav.navigate(target) }
    val back: () -> Unit = { nav.popBackStack() }

    Column(
        Modifier
            .fillMaxSize()
            .background(MflColors.Page)
            .statusBarsPadding(),
    ) {
        Row(
            Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("MFL CORE", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                HealthChip(online)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "${session?.role.orEmpty()}: ${session?.name.orEmpty()}",
                    fontSize = 13.sp,
                    color = MflColors.Muted,
                )
                TextButton(onClick = onLogout) { Text("Logout", fontSize = 13.sp) }
            }
        }

        current?.children?.takeIf { it.isNotEmpty() }?.let { subs ->
            Row(
                Modifier.fillMaxWidth().background(MflColors.Page).horizontalScroll(rememberScrollState()).padding(8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                subs.forEach { (label, target) ->
                    FilterChip(
                        selected = matches(route, target),
                        onClick = {
                            nav.navigate(target) {
                                popUpTo(nav.graph.startDestinationId) { saveState = false }
                                launchSingleTop = true
                            }
                        },
                        label = { Text(label, fontSize = 13.sp) },
                    )
                }
            }
        }

        NavHost(
            navController = nav,
            startDestination = Routes.HOME,
            modifier = Modifier.weight(1f).fillMaxWidth().padding(12.dp),
        ) {
            composable(Routes.HOME) { DashboardScreen(onNavigate = go) }

            composable(Routes.CUSTOMERS) { CustomersScreen(onNavigate = go) }
            composable(Routes.CUSTOMER, arguments = listOf(navArgument("id") { type = NavType.StringType })) { e ->
                CustomerDetailScreen(id = e.arg("id"), onNavigate = go, onBack = back)
            }

            composable(Routes.ADDRESSES) { AddressesScreen(onNavigate = go) }
            composable(Routes.ADDRESS, arguments = listOf(navArgument("id") { type = NavType.StringType })) { e ->
                AddressDetailScreen(id = e.arg("id"), onNavigate = go, onBack = back)
            }

            composable(Routes.LOANS) { LoansScreen(onNavigate = go) }
            composable(Routes.LOAN_NEW) { LoanFormScreen(onNavigate = go, onBack = back) }
            composable(Routes.LOAN_FIELDS, arguments = listOf(navArgument("id") { type = NavType.StringType })) { e ->
                LoanFieldsScreen(id = e.arg("id"), onNavigate = go, onBack = back)
            }

            composable(Routes.SCHEDULES) { SchedulesScreen(onNavigate = go) }
            composable(Routes.SCHEDULE_GENERATE) { GenerateMonthlyScreen(onBack = back) }
            composable(Routes.SCHEDULE, arguments = listOf(navArgument("id") { type = NavType.StringType })) { e ->
                ScheduleDetailScreen(id = e.arg("id"), onNavigate = go, onBack = back)
            }

            composable(Routes.CURRENT_PAYMENT) { CurrentPaymentScreen() }
            composable(Routes.ONETIME) { OnetimeScreen() }
            composable(Routes.OPERATIONS) { OperationsScreen(onNavigate = go) }
        }

        NavigationBar(containerColor = Color.White) {
            PRIMARY_TABS.forEach { t ->
                NavigationBarItem(
                    selected = current === t,
                    onClick = {
                        nav.navigate(t.route) {
                            popUpTo(nav.graph.startDestinationId) { saveState = false }
                            launchSingleTop = true
                        }
                    },
                    icon = { Icon(t.icon, contentDescription = t.label) },
                    label = { Text(t.label, fontSize = 11.sp, maxLines = 1) },
                )
            }
        }
    }
}

@Composable
private fun HealthChip(online: Boolean?) {
    val (label, bg, fg) = when (online) {
        null -> Triple("API checking…", Color(0xFFF1F5F9), Color(0xFF334155))
        true -> Triple("API Online", Color(0xFFD1FAE5), Color(0xFF065F46))
        false -> Triple("API Offline", Color(0xFFFEE2E2), Color(0xFF991B1B))
    }
    Surface(shape = RoundedCornerShape(50), color = bg) {
        Text(label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = fg, modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp))
    }
}
