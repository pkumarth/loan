package com.mfl.core.ui.screens
import androidx.compose.ui.unit.sp
import androidx.compose.ui.Alignment

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.mfl.core.data.ApiClient
import com.mfl.core.data.PaymentRecord
import com.mfl.core.data.ScheduleRow
import com.mfl.core.data.Lookups
import com.mfl.core.data.listPage
import com.mfl.core.data.userMessage
import com.mfl.core.ui.components.*
import com.mfl.core.ui.theme.MflColors
import com.mfl.core.util.formatDate
import com.mfl.core.util.formatWhole
import com.mfl.core.util.orNull
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

private val PAYMENT_STATUSES = listOf("SUCCESS", "REVERSED", "BOUNCED")
private val DUE_STATUSES = listOf("OPEN", "PARTIAL", "OVERDUE")

/** Today's payment ledger: receipts (payments) and the calculated dues still to collect. */
@Composable
fun CurrentPaymentScreen() {
    var tab by remember { mutableStateOf("receipts") }

    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        PageHeader("Current Payment")
        SegmentTabs(
            tabs = listOf("receipts" to "Receipts", "dues" to "Dues"),
            selected = tab,
            onSelect = { tab = it },
        )
        if (tab == "receipts") ReceiptsTab() else DuesTab()
    }
}

@Composable
private fun ColumnScope.ReceiptsTab() {
    var status by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<PaymentRecord?>(null) }
    var reloadTick by remember { mutableIntStateOf(0) }

    FilterRow {
        FilterPicker(
            "Status", status,
            listOf("" to "All statuses") + PAYMENT_STATUSES.map { it to it },
            { status = it }, Modifier.weight(1f),
        )
        FilterPicker(
            "Mode", mode,
            listOf("" to "All modes") + PAYMENT_MODES.map { it to it },
            { mode = it }, Modifier.weight(1f),
        )
    }
    PagedTable(
        filterKey = listOf(status, mode),
        reloadKey = reloadTick,
        emptyText = "No receipts found.",
        fetch = { p, size ->
            val list = listPage<PaymentRecord>(
                "/payments", p,
                mapOf("payment_status" to status.orNull(), "payment_mode" to mode.orNull()),
                size,
            )
            PageResult(list.rows, list.totalPages, Lookups.schedules())
        },
        columns = { schedules -> receiptColumns(schedules) },
        rowAction = { r -> ActionButton(text = "Remarks", onClick = { editing = r }) },
        modifier = Modifier.weight(1f),
    )

    editing?.let { r ->
        RemarksDialog(
            receipt = r,
            onDismiss = { editing = null },
            onSaved = {
                editing = null
                reloadTick++
            },
        )
    }
}

private fun receiptColumns(schedules: Map<Long, ScheduleRow>): List<DataColumn<PaymentRecord>> {
    fun sched(r: PaymentRecord): ScheduleRow? = r.paymentScheduleId?.let { schedules[it] }
    val dash = "—"

    return listOf(
        DataColumn<PaymentRecord>("Payment ID", 90.dp) { it.paymentId.toString() },
        DataColumn<PaymentRecord>("Schedule ID", 90.dp) { it.paymentScheduleId?.toString() ?: dash },
        DataColumn<PaymentRecord>("Loan ID", 80.dp) { it.loanId.toString() },
        DataColumn<PaymentRecord>("Customer name", 150.dp) { r -> r.customerName ?: sched(r)?.customerName ?: dash },
        DataColumn<PaymentRecord>("Mohalla", 110.dp) { r -> sched(r)?.mohalla ?: dash },
        DataColumn<PaymentRecord>("Current kist", 90.dp, right = true) { it.currentKistNo?.toString() ?: dash },
        DataColumn<PaymentRecord>("Installment date", 110.dp) { formatDate(it.installmentDate) },
        DataColumn<PaymentRecord>("Payment amount", 110.dp, right = true) { formatWhole(it.paymentAmount) },
        DataColumn<PaymentRecord>("Payment date", 110.dp) { formatDate(it.paymentDate) },
        DataColumn<PaymentRecord>("Payment mode", 110.dp) { it.paymentMode },
        DataColumn<PaymentRecord>("Payment status", 110.dp, badge = true) { it.paymentStatus },
        DataColumn<PaymentRecord>("Payer name", 130.dp) { it.payerName ?: dash },
        DataColumn<PaymentRecord>("Manager", 110.dp) { r -> sched(r)?.managerName ?: dash },
        DataColumn<PaymentRecord>("Manager received", 110.dp, right = true) { formatWhole(it.managerReceivedAmount) },
        DataColumn<PaymentRecord>("Owner", 110.dp) { r -> sched(r)?.ownerName ?: dash },
        DataColumn<PaymentRecord>("Owner received", 110.dp, right = true) { formatWhole(it.ownerReceivedAmount) },
        DataColumn<PaymentRecord>("Receipt no", 110.dp) { it.receiptNo },
        DataColumn<PaymentRecord>("Transaction ref", 130.dp) { it.transactionRef ?: dash },
        DataColumn<PaymentRecord>("Remarks", 160.dp) { it.remarks ?: dash },
    )
}

@Composable
private fun RemarksDialog(receipt: PaymentRecord, onDismiss: () -> Unit, onSaved: () -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var text by remember { mutableStateOf(receipt.remarks.orEmpty()) }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    FormDialog(
        title = "Remarks for ${receipt.receiptNo}",
        confirmText = "Save remarks",
        saving = saving,
        error = error,
        onDismiss = onDismiss,
        onConfirm = {
            saving = true
            error = null
            scope.launch {
                try {
                    // Only remarks can be edited on a receipt; amounts are fixed once recorded.
                    val body = buildJsonObject { put("remarks", text.trim().ifEmpty { null }) }
                    ApiClient.execute("/payments/${receipt.paymentId}", "PATCH", body = body)
                    toast(context, "Remarks saved")
                    onSaved()
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    error = e.userMessage()
                } finally {
                    saving = false
                }
            }
        },
    ) {
        FormField("Remarks", text, onChange = { text = it })
    }
}

@Composable
private fun ColumnScope.DuesTab() {
    var status by remember { mutableStateOf("OPEN") }
    var collecting by remember { mutableStateOf<ScheduleRow?>(null) }
    var reloadTick by remember { mutableIntStateOf(0) }

    FilterRow {
        FilterPicker("Due status", status, DUE_STATUSES.map { it to it }, { status = it }, Modifier.weight(1f))
    }
    PagedTable(
        filterKey = status,
        reloadKey = reloadTick,
        emptyText = "No $status installments.",
        fetch = { p, size ->
            val list = listPage<ScheduleRow>("/payment-schedules", p, mapOf("status" to status), size)
            PageResult(list.rows, list.totalPages, Unit)
        },
        columns = {
            listOf(
                DataColumn<ScheduleRow>("Schedule ID", 90.dp) { it.paymentScheduleId.toString() },
                DataColumn<ScheduleRow>("Loan ID", 80.dp) { it.loanId.toString() },
                DataColumn<ScheduleRow>("Customer name", 150.dp) { it.customerName },
                DataColumn<ScheduleRow>("Mohalla", 110.dp) { it.mohalla ?: "—" },
                DataColumn<ScheduleRow>("Current kist", 90.dp, right = true) { it.currentKistNo.toString() },
                DataColumn<ScheduleRow>("Installment date", 110.dp) { formatDate(it.installmentDate) },
                DataColumn<ScheduleRow>("Installment amt", 110.dp, right = true) { formatWhole(it.installmentAmount) },
                DataColumn<ScheduleRow>("Balance due", 110.dp, right = true) { formatWhole(it.balanceDue) },
                DataColumn<ScheduleRow>("Manager", 110.dp) { it.managerName ?: "—" },
                DataColumn<ScheduleRow>("Owner", 110.dp) { it.ownerName ?: "—" },
            )
        },
        rowAction = { row -> ActionButton(text = "Collect", onClick = { collecting = row }, primary = true) },
        modifier = Modifier.weight(1f),
    )

    collecting?.let { row ->
        CollectDialog(
            schedule = row,
            onDismiss = { collecting = null },
            onDone = {
                collecting = null
                reloadTick++
            },
        )
    }
}
