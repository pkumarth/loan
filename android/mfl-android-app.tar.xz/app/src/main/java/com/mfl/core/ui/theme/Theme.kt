package com.mfl.core.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/** Colours from the web app's Tailwind palette. */
object MflColors {
    val Ink = Color(0xFF0F172A)          // slate-900
    val Muted = Color(0xFF64748B)        // slate-500
    val Border = Color(0xFFE2E8F0)       // slate-200
    val Accent = Color(0xFF4F46E5)       // indigo-600 (links, active tab)
    val Danger = Color(0xFFDC2626)       // red-600
    val Page = Color(0xFFF8FAFC)         // slate-50
    val HeaderBg = Color(0xFFFEF3C7)     // amber-100: yellow table header
    val HeaderBorder = Color(0xFFFCD34D) // amber-300
    val HeaderText = Color(0xFF451A03)   // amber-950
    val RowOdd = Color(0xFFFFFFFF)       // alternating rows
    val RowEven = Color(0xFFF1F5F9)      // slate-100
}

// Sizes are tuned for phones: body 15, table cells 13, table headers and captions 11, titles 20.
private val MflTypography = Typography(
    bodyMedium = TextStyle(fontSize = 15.sp),
    bodySmall = TextStyle(fontSize = 13.sp),
    labelSmall = TextStyle(fontSize = 11.sp),
    titleLarge = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.SemiBold),
    titleSmall = TextStyle(fontSize = 15.sp, fontWeight = FontWeight.SemiBold),
)

private val MflScheme = lightColorScheme(
    primary = MflColors.Ink,
    onPrimary = Color.White,
    secondary = MflColors.Accent,
    background = MflColors.Page,
    onBackground = MflColors.Ink,
    surface = Color.White,
    onSurface = MflColors.Ink,
)

@Composable
fun MflTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = MflScheme, typography = MflTypography, content = content)
}
