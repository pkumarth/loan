package com.mfl.core.ui.components

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Create
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mfl.core.data.ApiClient
import com.mfl.core.data.Lookups
import com.mfl.core.data.rawObject
import com.mfl.core.data.userMessage
import com.mfl.core.ui.theme.MflColors
import com.mfl.core.util.LOAN_TYPE_LABEL
import com.mfl.core.util.fieldLabel
import com.mfl.core.util.formatDate
import com.mfl.core.util.formatWhole
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.put

enum class EditKind { TEXT, MOBILE, DECIMAL, WHOLE, MONEY, DATE, OPTIONS }

/** How one field is edited. [options] is used by OPTIONS fields. */
data class EditSpec(val kind: EditKind, val options: List<String> = emptyList())

private val DATE_RE = Regex("\\d{4}-\\d{2}-\\d{2}")
private val MONEY_KEY_RE = Regex("amount|principal|fine|interest|forgive|balance|return|paid|received|fee|income|loan$")

/**
 * Shows one API value the way the web detail pages do: dates as "14 Nov 2026", money as whole rupees
 * (rate_of_interest is a percentage and stays plain), loan types as EMI/MI/OT, null as a dash.
 */
fun displayValue(key: String, el: JsonElement?): String {
    if (el == null || el is JsonNull) return "—"
    val p = el as? JsonPrimitive ?: return el.toString()
    val text = p.content
    if (text.isEmpty()) return "—"
    if (key == "loan_type") return LOAN_TYPE_LABEL[text] ?: text
    if (p.isString) return if (DATE_RE.matches(text)) formatDate(text) else text
    val n = text.toDoubleOrNull() ?: return text
    return if (!key.startsWith("rate") && MONEY_KEY_RE.containsMatchIn(key)) formatWhole(n) else text
}

/** Raw value for the edit box: empty for null, the plain string otherwise. */
private fun editableText(el: JsonElement?): String {
    if (el == null || el is JsonNull) return ""
    return (el as? JsonPrimitive)?.contentOrNull ?: el.toString()
}

private fun keyboardFor(kind: EditKind): KeyboardType = when (kind) {
    EditKind.MOBILE -> KeyboardType.Phone
    EditKind.DECIMAL, EditKind.MONEY -> KeyboardType.Decimal
    EditKind.WHOLE -> KeyboardType.Number
    else -> KeyboardType.Text
}

private fun hintFor(kind: EditKind): String? = when (kind) {
    EditKind.DATE -> "Format YYYY-MM-DD"
    EditKind.MOBILE -> "10 digits"
    else -> null
}

/** Client-side checks that mirror the web forms. Empty input is allowed and sent as null. */
private fun validate(kind: EditKind, raw: String, extra: ((String) -> String?)?): String? {
    val v = raw.trim()
    extra?.invoke(v)?.let { return it }
    return when (kind) {
        EditKind.MOBILE -> if (v.isEmpty() || Regex("\\d{10}").matches(v)) null else "Enter a 10-digit mobile number"
        EditKind.DECIMAL, EditKind.MONEY, EditKind.WHOLE -> {
            val n = v.toDoubleOrNull()
            when {
                v.isEmpty() -> null
                n == null -> "Enter a number"
                n < 0 -> "Enter 0 or more"
                kind == EditKind.WHOLE && n % 1.0 != 0.0 -> "Enter a whole number"
                else -> null
            }
        }
        EditKind.DATE -> if (v.isEmpty() || DATE_RE.matches(v)) null else "Use the format YYYY-MM-DD"
        else -> null
    }
}

private fun toJson(kind: EditKind, raw: String): JsonElement {
    val v = raw.trim()
    if (v.isEmpty()) return JsonNull
    return when (kind) {
        EditKind.DECIMAL, EditKind.MONEY -> JsonPrimitive(v.toDouble())
        EditKind.WHOLE -> JsonPrimitive(v.toDouble().toLong())
        else -> JsonPrimitive(v)
    }
}

/**
 * Generic detail page: loads one record as raw JSON and lists every field, the same way the web
 * detail pages do. A pencil icon appears on editable fields and saves through PATCH.
 *
 * [linkRoutes] makes a field a link. The value is substituted for "{}", e.g. "customers/{}".
 * [validators] adds field-specific checks (for example the postal-code length).
 */
@Composable
fun EntityDetailScreen(
    title: String,
    path: String,
    editable: Map<String, EditSpec>,
    onNavigate: (String) -> Unit,
    onBack: () -> Unit,
    linkRoutes: Map<String, String> = emptyMap(),
    validators: Map<String, (String) -> String?> = emptyMap(),
) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val remote = rememberRemote(path) { rawObject(path) }

    var editing by remember { mutableStateOf<String?>(null) }
    var saving by remember { mutableStateOf(false) }
    var saveError by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        PageHeader(title, actions = { ActionButton("Back", onBack) })

        RemoteContent(remote) { obj: JsonObject ->
            MflCard(title = "Details") {
                obj.entries.forEach { (key, value) ->
                    val spec = editable[key]
                    val template = linkRoutes[key]
                    val text = displayValue(key, value)
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            fieldLabel(key),
                            fontSize = 13.sp,
                            color = MflColors.Muted,
                            modifier = Modifier.weight(0.42f),
                        )
                        if (template != null && text != "—") {
                            val target = template.replace("{}", (value as? JsonPrimitive)?.content.orEmpty())
                            Text(
                                text,
                                fontSize = 13.sp,
                                color = MflColors.Accent,
                                textDecoration = TextDecoration.Underline,
                                modifier = Modifier.weight(0.5f).clickable { onNavigate(target) },
                            )
                        } else {
                            Text(text, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(0.5f))
                        }
                        if (spec != null) {
                            IconButton(onClick = {
                                saveError = null
                                editing = key
                            }) {
                                Icon(Icons.Filled.Create, contentDescription = "Edit ${fieldLabel(key)}")
                            }
                        } else {
                            Spacer(Modifier.width(48.dp))
                        }
                    }
                    HorizontalDivider(color = MflColors.Border)
                }
            }

            val currentKey = editing
            val currentSpec = currentKey?.let { editable[it] }
            if (currentKey != null && currentSpec != null) {
                EditValueDialog(
                    title = "Edit ${fieldLabel(currentKey)}",
                    label = fieldLabel(currentKey),
                    initial = editableText(obj[currentKey]),
                    keyboard = keyboardFor(currentSpec.kind),
                    options = currentSpec.options,
                    hint = hintFor(currentSpec.kind),
                    saving = saving,
                    error = saveError,
                    onDismiss = {
                        editing = null
                        saveError = null
                    },
                    onSave = { raw ->
                        val problem = validate(currentSpec.kind, raw, validators[currentKey])
                        if (problem != null) {
                            saveError = problem
                        } else {
                            saving = true
                            saveError = null
                            scope.launch {
                                try {
                                    val body = buildJsonObject { put(currentKey, toJson(currentSpec.kind, raw)) }
                                    ApiClient.execute(path, "PATCH", body = body)
                                    Lookups.invalidate()
                                    editing = null
                                    remote.reload()
                                    Toast.makeText(context, "${fieldLabel(currentKey)} updated", Toast.LENGTH_SHORT).show()
                                } catch (e: CancellationException) {
                                    throw e
                                } catch (e: Exception) {
                                    saveError = e.userMessage()
                                } finally {
                                    saving = false
                                }
                            }
                        }
                    },
                )
            }
        }
    }
}
