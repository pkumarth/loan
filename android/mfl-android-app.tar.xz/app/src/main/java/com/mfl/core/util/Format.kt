package com.mfl.core.util

import java.math.RoundingMode
import java.text.NumberFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale

// Ports of src/lib/formatters.ts and src/lib/form-utils.ts.
// Rules: no "Rs." prefix, no decimal part on amounts, dates as "14 Nov 2026".

private val wholeFormat: NumberFormat = NumberFormat.getIntegerInstance(Locale.forLanguageTag("en-IN")).apply {
    roundingMode = RoundingMode.HALF_UP
}

private val dateFormat = DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.ENGLISH)

/** Indian digit grouping, no decimals: 120000 -> "1,20,000". */
fun formatWhole(value: Double?): String =
    if (value == null || value.isNaN()) "—" else wholeFormat.format(value)

/** "14 Nov 2026" from an ISO date (yyyy-MM-dd, or a longer ISO string whose first 10 chars are the date). */
fun formatDate(iso: String?): String {
    if (iso.isNullOrBlank()) return "—"
    return runCatching { LocalDate.parse(iso.take(10)).format(dateFormat) }.getOrDefault(iso)
}

/** A number without grouping or forced decimals: 2.0 -> "2", 2.5 -> "2.5". Used for rate and ratings. */
fun plainNumber(d: Double?): String = when {
    d == null -> "—"
    d % 1.0 == 0.0 -> d.toLong().toString()
    else -> d.toString()
}

/** Today as yyyy-MM-dd in the device time zone. */
fun isoToday(): String = LocalDate.now().toString()

fun addMonthsIso(iso: String, months: Int): String =
    LocalDate.parse(iso.take(10)).plusMonths(months.toLong()).toString()

/** Collection cycle: a day from 8 to 20 is the 12th cycle, otherwise the 25th. */
fun cycleFor(iso: String, start: Int = 8, cutoff: Int = 20): String {
    val day = LocalDate.parse(iso.take(10)).dayOfMonth
    return if (day in start..cutoff) "12th" else "25th"
}

/** Short labels for loan types. API values stay EMI, MONTHLY_INTEREST, ONETIME. */
val LOAN_TYPE_LABEL: Map<String, String> = mapOf(
    "EMI" to "EMI",
    "MONTHLY_INTEREST" to "MI",
    "ONETIME" to "OT",
)

/** Accrued interest = principal × rate × days ÷ 3000, rounded half up. Future borrowing dates give 0. */
fun accruedInterest(principal: Double, rate: Double, borrowingIso: String, today: String = isoToday()): Double {
    val start = LocalDate.parse(borrowingIso.take(10))
    val end = LocalDate.parse(today.take(10))
    val days = ChronoUnit.DAYS.between(start, end).coerceAtLeast(0)
    return Math.round(principal * rate * days / 3000.0).toDouble()
}

/** "borrowing_date" -> "Borrowing date". */
fun fieldLabel(key: String): String =
    key.replace('_', ' ').replaceFirstChar { it.uppercase() }

/** Blank input becomes null. Trims otherwise. */
fun String?.orNull(): String? = this?.trim()?.ifEmpty { null }
