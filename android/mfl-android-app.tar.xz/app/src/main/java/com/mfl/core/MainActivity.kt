package com.mfl.core

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.mfl.core.data.AuthStore
import com.mfl.core.ui.nav.MflRoot
import com.mfl.core.ui.theme.MflTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        AuthStore.init(applicationContext)
        setContent {
            MflTheme { MflRoot() }
        }
    }
}
