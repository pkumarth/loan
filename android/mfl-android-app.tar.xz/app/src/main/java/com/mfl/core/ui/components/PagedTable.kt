package com.mfl.core.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.ui.Alignment
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mfl.core.ui.theme.MflColors

/** A page of rows plus the lookup data the columns need (joined names, etc.). */
class PageResult<T, V>(val rows: List<T>, val totalPages: Int, val lookup: V)

/** Footer height: Prev / Page / Next. Reserved out of the table area before the page size is worked out. */
val PAGER_HEIGHT = 52.dp

/**
 * A list that fills the space it is given and never scrolls. The page size is worked out from that
 * space, so one page exactly fits the screen. Changing [filterKey] goes back to page 1.
 * Give it a `Modifier.weight(1f)` inside a Column so it takes the rest of the screen.
 */
@Composable
fun <T, V> PagedTable(
    filterKey: Any,
    reloadKey: Int,
    emptyText: String,
    fetch: suspend (page: Int, size: Int) -> PageResult<T, V>,
    columns: (V) -> List<DataColumn<T>>,
    modifier: Modifier = Modifier,
    rowAction: (@Composable (T) -> Unit)? = null,
) {
    BoxWithConstraints(modifier.fillMaxWidth()) {
        val perPage = ((maxHeight - PAGER_HEIGHT - TABLE_HEADER_HEIGHT) / TABLE_ROW_HEIGHT)
            .toInt()
            .coerceIn(3, 50)
        var page by remember(filterKey) { mutableIntStateOf(1) }
        val remote = rememberRemote(filterKey, reloadKey, page, perPage) { fetch(page, perPage) }

        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (val s = remote.state) {
                    is LoadState.Ok -> if (s.value.rows.isEmpty()) {
                        EmptyText(emptyText)
                    } else {
                        DataTable(s.value.rows, columns(s.value.lookup), rowAction = rowAction)
                    }
                    is LoadState.Failed -> Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        ErrorText(s.message)
                        TextButton(onClick = remote.reload) { Text("Retry") }
                    }
                    LoadState.Loading -> EmptyText("Loading…")
                }
            }
            val shown = (remote.state as? LoadState.Ok)?.value
            if (shown != null) {
                PaginationBar(page, shown.totalPages) { page = it }
            } else {
                Spacer(Modifier.height(PAGER_HEIGHT))
            }
        }
    }
}

/** One row of filters. Filters share the width equally so they stay on a single line. */
@Composable
fun FilterRow(content: @Composable RowScope.() -> Unit) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        content = content,
    )
}

/** Compact text filter. The label is the placeholder, so the row stays short. */
@Composable
fun FilterText(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    keyboard: KeyboardType = KeyboardType.Text,
    trailing: (@Composable () -> Unit)? = null,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        singleLine = true,
        placeholder = { Text(label, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        textStyle = TextStyle(fontSize = 14.sp),
        trailingIcon = trailing,
        keyboardOptions = KeyboardOptions(keyboardType = keyboard),
        modifier = modifier,
    )
}

/** Compact dropdown filter. Shows the label until a value is picked, then the chosen option. */
@Composable
fun FilterPicker(
    label: String,
    value: String,
    options: List<Pair<String, String>>,
    onPick: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    var open by remember { mutableStateOf(false) }
    val chosen = if (value.isEmpty()) null else options.firstOrNull { it.first == value }?.second
    Box(modifier) {
        OutlinedButton(
            onClick = { open = true },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            contentPadding = PaddingValues(horizontal = 10.dp),
        ) {
            Text(
                chosen ?: label,
                fontSize = 13.sp,
                color = if (chosen == null) MflColors.Muted else MflColors.Ink,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            Icon(Icons.Filled.ArrowDropDown, contentDescription = null, modifier = Modifier.size(20.dp))
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { (v, l) ->
                DropdownMenuItem(
                    text = { Text(l, fontSize = 14.sp) },
                    onClick = {
                        open = false
                        onPick(v)
                    },
                )
            }
        }
    }
}
