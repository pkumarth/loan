package com.mfl.core.data

import android.content.Context
import android.content.SharedPreferences
import com.mfl.core.BuildConfig

data class Session(val name: String, val role: String, val mobile: String)

/**
 * STUB AUTH, same as the web app: no credential is verified and no SMS is sent.
 * The session only sets X-User-Id. Replace with the real login flow before real use.
 */
object AuthStore {
    const val DEFAULT_USER = "praveen"
    const val OTP_RESEND_SECONDS = 60

    /** Registered admins per the UX spec. Mobile numbers are placeholders. */
    val ADMINS: Map<String, String> = mapOf("Owner" to "praveen", "Manager" to "bhikhari_yadav")

    val DEV_OTP: String get() = BuildConfig.DEV_OTP

    private var prefs: SharedPreferences? = null
    private var session: Session? = null

    fun init(context: Context) {
        val p = context.applicationContext.getSharedPreferences("mfl-session", Context.MODE_PRIVATE)
        prefs = p
        val name = p.getString("name", null)
        session = name?.let { Session(it, p.getString("role", "Owner") ?: "Owner", p.getString("mobile", "") ?: "") }
    }

    fun current(): Session? = session

    fun userName(): String = session?.name ?: DEFAULT_USER

    fun save(s: Session) {
        session = s
        prefs?.edit()
            ?.putString("name", s.name)
            ?.putString("role", s.role)
            ?.putString("mobile", s.mobile)
            ?.apply()
    }

    fun clear() {
        session = null
        prefs?.edit()?.clear()?.apply()
    }

    /** Stub check: 10-digit mobile, non-empty password. */
    fun validateCredentials(mobile: String, password: String): String? = when {
        !Regex("\\d{10}").matches(mobile) -> "Enter a 10-digit mobile number"
        password.isEmpty() -> "Enter your password"
        else -> null
    }

    fun verifyOtp(code: String): Boolean = code == DEV_OTP
}
