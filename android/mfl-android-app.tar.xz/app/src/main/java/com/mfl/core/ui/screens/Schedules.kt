package com.mfl.core.ui.screens
import androidx.compose.ui.unit.sp
import androidx.compose.ui.Alignment

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.material3.TextButton
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mfl.core.data.ScheduleRow
import com.mfl.core.data.listPage
import com.mfl.core.ui.components.*
import com.mfl.core.ui.nav.Routes
import com.mfl.core.ui.theme.MflColors
import com.mfl.core.util.formatWhole
import com.mfl.core.util.isoToday
import com.mfl.core.util.orNull

internal val SCHEDULE_STATUSES = listOf("OPEN", "PARTIAL", "OVERDUE", "PAID")
private val LOAN_TYPE_OPTIONS = listOf("" to "All types", "EMI" to "EMI", "MONTHLY_INTEREST" to "MI", "ONETIME" to "OT")

/** Kist ledger: one row per installment. Schedule ID and Loan ID are links; Collect opens the payment form. */
@Composable
fun SchedulesScreen(onNavigate: (String) -> Unit) {
    var status by remember { mutableStateOf("") }
    var loanType by remember { mutableStateOf("") }
    var installmentDate by remember { mutableStateOf("") }
    var loanId by remember { mutableStateOf("") }
    var collecting by remember { mutableStateOf<ScheduleRow?>(null) }
    var reloadTick by remember { mutableIntStateOf(0) }

    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        PageHeader("Kist Ledger") {
            ActionButton(text = "Generate", onClick = { onNavigate(Routes.SCHEDULE_GENERATE) })
        }
        FilterRow {
            FilterPicker(
                "Status", status,
                listOf("" to "All statuses") + SCHEDULE_STATUSES.map { it to it },
                { status = it }, Modifier.weight(1f),
            )
            FilterPicker("Loan type", loanType, LOAN_TYPE_OPTIONS, { loanType = it }, Modifier.weight(1f))
            FilterText(
                "Loan ID", loanId, { loanId = it.filter(Char::isDigit) }, Modifier.weight(0.8f),
                keyboard = KeyboardType.Number,
            )
            FilterText("Date", installmentDate, { installmentDate = it }, Modifier.weight(1.3f))
        }
        PagedTable(
            filterKey = listOf(status, loanType, installmentDate, loanId),
            reloadKey = reloadTick,
            emptyText = "No installments match these filters.",
            fetch = { p, size ->
                val list = listPage<ScheduleRow>(
                    "/payment-schedules", p,
                    mapOf(
                        "status" to status.orNull(),
                        "loan_type" to loanType.orNull(),
                        "installment_date" to installmentDate.orNull(),
                        "loan_id" to loanId.orNull(),
                    ),
                    size,
                )
                PageResult(list.rows, list.totalPages, Unit)
            },
            columns = {
                scheduleColumns(
                    onLoanClick = { onNavigate("loans/$it/fields") },
                    onScheduleClick = { onNavigate("schedules/$it") },
                )
            },
            rowAction = { row ->
                if (row.balanceDue > 0) ActionButton(text = "Collect", onClick = { collecting = row })
            },
            modifier = Modifier.weight(1f),
        )
    }

    collecting?.let { row ->
        CollectDialog(
            schedule = row,
            onDismiss = { collecting = null },
            onDone = {
                collecting = null
                reloadTick++
            },
        )
    }
}

/** One installment, every field. Pencil on payer, manager/owner names, date, amounts and forgiveness. */
@Composable
fun ScheduleDetailScreen(id: String, onNavigate: (String) -> Unit, onBack: () -> Unit) {
    EntityDetailScreen(
        title = "Schedule $id",
        path = "/payment-schedules/$id",
        editable = mapOf(
            "payer_name" to EditSpec(EditKind.TEXT),
            "manager_name" to EditSpec(EditKind.TEXT),
            "owner_name" to EditSpec(EditKind.TEXT),
            "installment_date" to EditSpec(EditKind.DATE),
            "installment_amount" to EditSpec(EditKind.MONEY),
            "fine_amount" to EditSpec(EditKind.MONEY),
            "other_amount" to EditSpec(EditKind.MONEY),
            "kist_interest_amount" to EditSpec(EditKind.MONEY),
            "forgive_amount" to EditSpec(EditKind.MONEY),
        ),
        linkRoutes = mapOf("loan_id" to "loans/{}/fields"),
        onNavigate = onNavigate,
        onBack = onBack,
    )
}
