package com.mfl.core.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mfl.core.BuildConfig
import com.mfl.core.data.ApiClient
import com.mfl.core.data.AuthStore
import com.mfl.core.data.Session
import com.mfl.core.ui.components.ActionButton
import com.mfl.core.ui.components.ErrorText
import com.mfl.core.ui.components.FormField
import com.mfl.core.ui.components.LoadState
import com.mfl.core.ui.components.MflCard
import com.mfl.core.ui.components.rememberRemote
import com.mfl.core.ui.theme.MflColors
import kotlinx.coroutines.delay

/** Stub login, same flow as the web app: role, mobile, password, then the OTP. Nothing is verified. */
@Composable
fun LoginScreen(onLoggedIn: () -> Unit) {
    var role by remember { mutableStateOf("Owner") }
    var mobile by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var otpSent by remember { mutableStateOf(false) }
    var otp by remember { mutableStateOf("") }
    var secondsLeft by remember { mutableIntStateOf(0) }
    var error by remember { mutableStateOf<String?>(null) }
    val health = rememberRemote { ApiClient.health() }

    LaunchedEffect(secondsLeft) {
        if (secondsLeft > 0) {
            delay(1000)
            secondsLeft--
        }
    }

    fun sendOtp() {
        val err = AuthStore.validateCredentials(mobile, password)
        error = err
        if (err == null) {
            // Stub: no SMS is sent. The code is AuthStore.DEV_OTP.
            otpSent = true
            secondsLeft = AuthStore.OTP_RESEND_SECONDS
        }
    }

    fun verify() {
        if (!AuthStore.verifyOtp(otp)) {
            error = "Incorrect OTP"
            return
        }
        val name = AuthStore.ADMINS[role] ?: AuthStore.DEFAULT_USER
        AuthStore.save(Session(name = name, role = role, mobile = mobile))
        onLoggedIn()
    }

    val backendText = when (val s = health.state) {
        LoadState.Loading -> "checking…"
        is LoadState.Ok -> if (s.value) "Online" else "Unreachable"
        is LoadState.Failed -> "Unreachable"
    }

    Box(
        Modifier.fillMaxSize().background(MflColors.Page).padding(20.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier.widthIn(max = 420.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            MflCard(title = "MFL Core Admin Portal") {
                Text("Restricted to Manager and Owner accounts.", fontSize = 11.sp, color = MflColors.Muted)

                Surface(shape = RoundedCornerShape(6.dp), color = Color(0xFFFFFBEB), border = null) {
                    Text(
                        "Development stub: no real authentication. Sending OTP does not send an SMS." +
                            if (BuildConfig.DEBUG) " Dev OTP: ${AuthStore.DEV_OTP}" else "",
                        fontSize = 11.sp,
                        color = Color(0xFF78350F),
                        modifier = Modifier.padding(8.dp),
                    )
                }

                Text("Admin role", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    AuthStore.ADMINS.keys.forEach { r ->
                        Row(
                            Modifier.clickable(enabled = !otpSent) { role = r },
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            RadioButton(selected = role == r, onClick = null, enabled = !otpSent)
                            Text("$r (${AuthStore.ADMINS[r]})", fontSize = 13.sp)
                        }
                    }
                }

                FormField(
                    "Mobile number",
                    mobile,
                    onChange = { mobile = it.filter(Char::isDigit).take(10) },
                    keyboard = KeyboardType.Phone,
                    enabled = !otpSent,
                )
                FormField("Password", password, onChange = { password = it }, password = true, enabled = !otpSent)

                if (otpSent) {
                    FormField(
                        "6-digit OTP",
                        otp,
                        onChange = { otp = it.filter(Char::isDigit).take(6) },
                        keyboard = KeyboardType.Number,
                        hint = "Stub code. Resend available in ${secondsLeft}s.",
                    )
                    TextButton(onClick = { sendOtp() }, enabled = secondsLeft == 0) {
                        Text("Resend OTP", fontSize = 13.sp)
                    }
                }

                error?.let { ErrorText(it) }

                ActionButton(
                    text = if (otpSent) "Verify OTP & enter workspace" else "Send OTP",
                    onClick = { if (otpSent) verify() else sendOtp() },
                    primary = true,
                    enabled = !otpSent || otp.length == 6,
                    modifier = Modifier.fillMaxWidth(),
                )

                Text("Backend: $backendText  (${ApiClient.baseUrl})", fontSize = 11.sp, color = MflColors.Muted)
            }
        }
    }
}
