package com.mfl.core.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mfl.core.data.ApiClient
import com.mfl.core.data.DashboardSummary
import com.mfl.core.ui.components.EmptyText
import com.mfl.core.ui.components.KeyValueRow
import com.mfl.core.ui.components.MflCard
import com.mfl.core.ui.components.PageHeader
import com.mfl.core.ui.components.RemoteContent
import com.mfl.core.ui.components.StatusBadge
import com.mfl.core.ui.components.rememberRemote
import com.mfl.core.ui.nav.Routes
import com.mfl.core.ui.theme.MflColors
import com.mfl.core.util.formatDate
import com.mfl.core.util.formatWhole
import com.mfl.core.util.plainNumber
import kotlinx.coroutines.delay

/** Executive dashboard, from GET /dashboard/summary. Refreshes every 60 seconds. */
@Composable
fun DashboardScreen(onNavigate: (String) -> Unit) {
    val remote = rememberRemote { ApiClient.call<DashboardSummary>("/dashboard/summary").data }

    LaunchedEffect(Unit) {
        while (true) {
            delay(60_000)
            remote.reload()
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        PageHeader("Executive Dashboard")
        RemoteContent(remote) { d -> DashboardContent(d, onNavigate) }
    }
}

@Composable
private fun DashboardContent(d: DashboardSummary, onNavigate: (String) -> Unit) {
    Text("As of ${formatDate(d.period.asOf)}", fontSize = 13.sp, color = MflColors.Muted)

    d.alerts.forEach { a ->
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(6.dp),
            color = Color(0xFFFFFBEB),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFCD34D)),
        ) {
            Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(a.message, fontSize = 13.sp, modifier = Modifier.weight(1f))
                when (a.type) {
                    "GENERATE_MONTHLY" -> TextButton(onClick = { onNavigate(Routes.SCHEDULE_GENERATE) }) {
                        Text("Preview dry run →", fontSize = 13.sp)
                    }
                    "OVERDUE" -> TextButton(onClick = { onNavigate(Routes.OPERATIONS) }) {
                        Text("Run overdue compute →", fontSize = 13.sp)
                    }
                    else -> Unit
                }
            }
        }
    }

    StatCard(
        title = "Total active AUM",
        value = formatWhole(d.portfolio.activeAum),
        lines = listOf(
            "${d.portfolio.activeLoans} active · ${d.portfolio.closedLoans} closed",
            "EMI ${d.portfolio.productMix["EMI"] ?: 0} · MI ${d.portfolio.productMix["MONTHLY_INTEREST"] ?: 0} · OT ${d.portfolio.productMix["ONETIME"] ?: 0}",
        ),
    )
    StatCard(
        title = "Capital deployed",
        value = formatWhole(d.capital.ownerDeployed + d.capital.managerDeployed),
        lines = listOf(
            "Owner ${formatWhole(d.capital.ownerDeployed)}",
            "Manager ${formatWhole(d.capital.managerDeployed)}",
        ),
    )
    StatCard(
        title = "Collected in ${d.period.billingMonth}/${d.period.billingYear}",
        value = formatWhole(d.capital.mtdCollected),
        lines = listOf(
            "Cash ${formatWhole(d.capital.mtdCash)} · UPI ${formatWhole(d.capital.mtdUpi)}",
            "${d.capital.mtdReceipts} receipts",
        ),
    )
    StatCard(
        title = "Overdue & fines",
        value = formatWhole(d.risk.overduePartialDue),
        lines = listOf(
            "${d.risk.overduePartialKists} kists · ${d.risk.overduePartialLoans} loans",
            "Fines & interest ${formatWhole(d.risk.finesAndInterest)}",
        ),
        danger = true,
    )

    MflCard(title = "12th & 25th cycle collection") {
        listOf("12th", "25th").forEach { k ->
            d.cycles[k]?.let { c ->
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    KeyValueRow("$k cycle", "${formatWhole(c.collected)} / ${formatWhole(c.expected)}")
                    LinearProgressIndicator(
                        progress = { (c.efficiencyPct / 100.0).coerceIn(0.0, 1.0).toFloat() },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Text(
                        "${plainNumber(c.efficiencyPct)}% collected · pending ${formatWhole(c.pending)} · ${c.openKists} open kists",
                        fontSize = 11.sp,
                        color = MflColors.Muted,
                    )
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(onClick = { onNavigate(Routes.CURRENT_PAYMENT) }) { Text("Open Current-Payment →", fontSize = 13.sp) }
            TextButton(onClick = { onNavigate(Routes.SCHEDULES) }) { Text("Open kist ledger →", fontSize = 13.sp) }
        }
    }

    MflCard(title = "Owner vs manager") {
        Row(Modifier.fillMaxWidth()) {
            Text("Metric", fontSize = 13.sp, color = MflColors.Muted, modifier = Modifier.weight(1.2f))
            Text("Owner", fontSize = 13.sp, color = MflColors.Muted, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
            Text("Manager", fontSize = 13.sp, color = MflColors.Muted, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth()) {
            Text("Deployed capital", fontSize = 13.sp, modifier = Modifier.weight(1.2f))
            Text(formatWhole(d.capital.ownerDeployed), fontSize = 13.sp, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
            Text(formatWhole(d.capital.managerDeployed), fontSize = 13.sp, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth()) {
            Text("Collected this month", fontSize = 13.sp, modifier = Modifier.weight(1.2f))
            Text(formatWhole(d.capital.mtdOwnerReceived), fontSize = 13.sp, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
            Text(formatWhole(d.capital.mtdManagerReceived), fontSize = 13.sp, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
        }
        KeyValueRow("Processing fees", formatWhole(d.capital.processingFees))
        KeyValueRow("Forgiven (all time)", formatWhole(d.capital.totalForgiven))
    }

    MflCard(title = "Top villages by pending due") {
        if (d.topVillages.isEmpty()) {
            EmptyText("No pending dues.")
        } else {
            d.topVillages.forEachIndexed { i, v ->
                KeyValueRow("${i + 1}. ${v.village} (${v.loans} loans)", formatWhole(v.due))
            }
        }
        TextButton(onClick = { onNavigate(Routes.ADDRESSES) }) { Text("Address Dashboard →", fontSize = 13.sp) }
    }

    MflCard(title = "Customers & KYC") {
        KeyValueRow("Total customers", d.customers.total.toString())
        KeyValueRow("Active borrowers", d.customers.activeBorrowers.toString())
        KeyValueRow("Guarantors", d.customers.guarantors.toString())
        KeyValueRow("KYC not verified", d.customers.kycPending.toString())
        KeyValueRow("Blacklisted", d.customers.blacklisted.toString())
        TextButton(onClick = { onNavigate(Routes.CUSTOMERS) }) { Text("Customer directory →", fontSize = 13.sp) }
    }

    MflCard(title = "Today's receipts") {
        if (d.todaysReceipts.isEmpty()) {
            EmptyText("No receipts logged today.")
        } else {
            d.todaysReceipts.forEach { r ->
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(r.receiptNo, fontSize = 11.sp, modifier = Modifier.weight(1f))
                        StatusBadge(r.paymentStatus)
                    }
                    Text(
                        "${r.customerName} · ${formatWhole(r.amount)} · ${r.paymentMode}" +
                            (r.currentKistNo?.let { " · Kist #$it" } ?: ""),
                        fontSize = 13.sp,
                        color = MflColors.Muted,
                    )
                }
            }
        }
        TextButton(onClick = { onNavigate(Routes.CURRENT_PAYMENT) }) { Text("Go to Current-Payment →", fontSize = 13.sp) }
    }
}

@Composable
private fun StatCard(title: String, value: String, lines: List<String>, danger: Boolean = false) {
    MflCard(title = title) {
        Text(
            value,
            fontSize = 20.sp,
            fontWeight = FontWeight.SemiBold,
            color = if (danger) MflColors.Danger else MflColors.Ink,
        )
        lines.forEach { Text(it, fontSize = 13.sp, color = MflColors.Muted) }
    }
}
