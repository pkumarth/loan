package com.mfl.core.data

import com.mfl.core.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonNamingStrategy
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.serializer
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * JSON settings for the MFL API. Kotlin camelCase properties map to the backend's snake_case keys
 * (loanId <-> loan_id). Unknown keys are ignored so new backend fields do not break the app.
 */
@OptIn(ExperimentalSerializationApi::class)
val MflJson: Json = Json {
    namingStrategy = JsonNamingStrategy.SnakeCase
    ignoreUnknownKeys = true
    explicitNulls = false
    coerceInputValues = true
}

@Serializable
data class Pagination(
    val page: Int = 1,
    val size: Int = 0,
    val totalElements: Long = 0,
    val totalPages: Int = 1,
    val hasNext: Boolean = false,
)

/** Decoded `data` of an envelope plus its pagination block, if any. */
data class Page<T>(val data: T, val pagination: Pagination?)

class ApiException(val httpStatus: Int, message: String) : Exception(message)

fun Throwable.userMessage(): String = message ?: "Something went wrong"

/**
 * HTTP entry point. Every backend response is the MFL envelope:
 * { status, status_code, display_msg, cause, data, pagination }.
 * Failures (non-2xx or status == "failure") throw ApiException with display_msg.
 */
object ApiClient {
    val baseUrl: String get() = BuildConfig.API_BASE_URL

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val jsonType = "application/json; charset=utf-8".toMediaType()

    /** Typed call: decodes `data` as T and keeps pagination. */
    suspend inline fun <reified T> call(
        path: String,
        method: String = "GET",
        query: Map<String, Any?> = emptyMap(),
        body: JsonObject? = null,
    ): Page<T> {
        val root = execute(path, method, query, body)
        val data: T = MflJson.decodeFromJsonElement(serializer<T>(), root["data"] ?: JsonNull)
        val pagination = (root["pagination"] as? JsonObject)
            ?.let { MflJson.decodeFromJsonElement(Pagination.serializer(), it) }
        return Page(data, pagination)
    }

    /** Raw envelope. Used for PATCH/POST calls where the response body is not needed. */
    suspend fun execute(
        path: String,
        method: String = "GET",
        query: Map<String, Any?> = emptyMap(),
        body: JsonObject? = null,
    ): JsonObject = withContext(Dispatchers.IO) {
        val qs = query
            .filterValues { it != null && it.toString().isNotEmpty() }
            .entries
            .joinToString("&") { (k, v) -> "${enc(k)}=${enc(v.toString())}" }
        val url = "$baseUrl/mfl-core/api/v1$path" + if (qs.isEmpty()) "" else "?$qs"

        val builder = Request.Builder()
            .url(url)
            .header("Accept", "application/json")
            .header("X-User-Id", AuthStore.userName())
        val request = if (method == "GET") {
            builder.get().build()
        } else {
            builder.method(method, (body?.toString() ?: "{}").toRequestBody(jsonType)).build()
        }

        val response = try {
            http.newCall(request).execute()
        } catch (e: IOException) {
            throw ApiException(0, "Cannot reach the backend at $baseUrl")
        }

        response.use { res ->
            val text = res.body?.string().orEmpty()
            val json = runCatching { MflJson.parseToJsonElement(text).jsonObject }.getOrNull()
            if (!res.isSuccessful || json == null || json["status"]?.jsonPrimitive?.contentOrNull == "failure") {
                val message = json?.get("display_msg")?.jsonPrimitive?.contentOrNull
                throw ApiException(res.code, message ?: "Request failed (${res.code})")
            }
            json
        }
    }

    /** Health check on the root path (not under /api/v1), as the web app does. */
    suspend fun health(): Boolean = withContext(Dispatchers.IO) {
        try {
            http.newCall(Request.Builder().url("$baseUrl/mfl-core/health").build()).execute().use { it.isSuccessful }
        } catch (e: IOException) {
            false
        }
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
}
