package com.mfl.core.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.mfl.core.data.Address
import com.mfl.core.data.ApiClient
import com.mfl.core.data.Lookups
import com.mfl.core.data.listPage
import com.mfl.core.data.userMessage
import com.mfl.core.ui.components.*
import com.mfl.core.util.fieldLabel
import com.mfl.core.util.orNull
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

/** Postal code is 4 to 12 characters when given, as on the web address form. */
internal val POSTAL_CODE_CHECK: (String) -> String? = { v ->
    if (v.isEmpty() || v.length in 4..12) null else "Postal code must be 4 to 12 characters"
}

/** Address directory with village and mohalla filters. */
@Composable
fun AddressesScreen(onNavigate: (String) -> Unit) {
    var village by remember { mutableStateOf("") }
    var mohalla by remember { mutableStateOf("") }
    var creating by remember { mutableStateOf(false) }
    var reloadTick by remember { mutableIntStateOf(0) }

    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        PageHeader("Addresses") {
            ActionButton("New address", { creating = true }, primary = true)
        }
        FilterRow {
            FilterText("Village", village, { village = it }, Modifier.weight(1f))
            FilterText("Mohalla", mohalla, { mohalla = it }, Modifier.weight(1f))
        }
        PagedTable(
            filterKey = listOf(village, mohalla),
            reloadKey = reloadTick,
            emptyText = "No addresses found.",
            fetch = { p, size ->
                val list = listPage<Address>(
                    "/addresses", p,
                    mapOf("village" to village.orNull(), "mohalla" to mohalla.orNull()),
                    size,
                )
                PageResult(list.rows, list.totalPages, Unit)
            },
            columns = {
                listOf(
                    DataColumn<Address>("ID", 80.dp, onClick = { onNavigate("addresses/${it.addressId}") }) { it.addressId.toString() },
                    DataColumn<Address>("Village", 130.dp) { it.village ?: "—" },
                    DataColumn<Address>("Mohalla", 130.dp) { it.mohalla ?: "—" },
                    DataColumn<Address>("Police station", 130.dp) { it.policeStation ?: "—" },
                    DataColumn<Address>("District", 110.dp) { it.district },
                    DataColumn<Address>("State", 110.dp) { it.state },
                    DataColumn<Address>("Postal code", 110.dp) { it.postalCode },
                )
            },
            modifier = Modifier.weight(1f),
        )
    }

    if (creating) {
        AddressCreateDialog(
            onDismiss = { creating = false },
            onCreated = {
                creating = false
                reloadTick++
            },
        )
    }
}

/** One address, every field. Pencil on village, mohalla, police station, ward, landmark and postal code. */
@Composable
fun AddressDetailScreen(id: String, onNavigate: (String) -> Unit, onBack: () -> Unit) {
    EntityDetailScreen(
        title = "Address $id",
        path = "/addresses/$id",
        editable = mapOf(
            "village" to EditSpec(EditKind.TEXT),
            "mohalla" to EditSpec(EditKind.TEXT),
            "police_station" to EditSpec(EditKind.TEXT),
            "ward_no" to EditSpec(EditKind.TEXT),
            "landmark" to EditSpec(EditKind.TEXT),
            "postal_code" to EditSpec(EditKind.TEXT),
        ),
        validators = mapOf("postal_code" to POSTAL_CODE_CHECK),
        onNavigate = onNavigate,
        onBack = onBack,
    )
}

@Composable
private fun AddressCreateDialog(onDismiss: () -> Unit, onCreated: () -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val form = remember {
        mutableStateMapOf(
            "country" to "India",
            "state" to "BIHAR",
            "district" to "MADHUBANI",
            "police_station" to "",
            "village" to "",
            "mohalla" to "",
            "ward_no" to "",
            "landmark" to "",
            "postal_code" to "",
        )
    }
    var error by remember { mutableStateOf<String?>(null) }
    var saving by remember { mutableStateOf(false) }

    FormDialog(
        title = "New address",
        confirmText = "Save address",
        saving = saving,
        error = error,
        onDismiss = onDismiss,
        onConfirm = {
            val postal = form.getValue("postal_code").trim()
            val problem = POSTAL_CODE_CHECK(postal).takeIf { postal.isNotEmpty() }
                ?: if (postal.isEmpty()) "Postal code is required" else null
            if (problem != null) {
                error = problem
            } else {
                error = null
                saving = true
                scope.launch {
                    try {
                        val body = buildJsonObject {
                            for ((k, v) in form) put(k, v.trim())
                        }
                        ApiClient.execute("/addresses", "POST", body = body)
                        Lookups.invalidate()
                        toast(context, "Address saved")
                        onCreated()
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        error = e.userMessage()
                    } finally {
                        saving = false
                    }
                }
            }
        },
    ) {
        form.keys.forEach { k ->
            FormField(fieldLabel(k), form.getValue(k), onChange = { form[k] = it })
        }
    }
}
