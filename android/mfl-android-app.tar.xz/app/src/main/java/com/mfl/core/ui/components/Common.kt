package com.mfl.core.ui.components

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mfl.core.data.userMessage
import com.mfl.core.ui.theme.MflColors
import kotlinx.coroutines.CancellationException

// ---- Async state ---------------------------------------------------------------------------------

sealed interface LoadState<out T> {
    data object Loading : LoadState<Nothing>
    data class Ok<T>(val value: T) : LoadState<T>
    data class Failed(val message: String) : LoadState<Nothing>
}

/** A remote read. `reload` runs the same load again (used after a save). */
class Remote<T>(val state: LoadState<T>, val reload: () -> Unit)

/**
 * Runs [load] whenever [keys] change and keeps the result in Compose state.
 * Pass every value the load reads as a key, otherwise the list will not refresh when it changes.
 */
@Composable
fun <T> rememberRemote(vararg keys: Any?, load: suspend () -> T): Remote<T> {
    var tick by remember { mutableIntStateOf(0) }
    val state by produceState<LoadState<T>>(LoadState.Loading, *keys, tick) {
        value = LoadState.Loading
        value = try {
            LoadState.Ok(load())
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            LoadState.Failed(e.userMessage())
        }
    }
    return Remote(state) { tick++ }
}

@Composable
fun <T> RemoteContent(remote: Remote<T>, content: @Composable (T) -> Unit) {
    when (val s = remote.state) {
        is LoadState.Ok -> content(s.value)
        is LoadState.Failed -> Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            ErrorText(s.message)
            TextButton(onClick = remote.reload) { Text("Retry") }
        }
        LoadState.Loading -> EmptyText("Loading…")
    }
}

// ---- Layout --------------------------------------------------------------------------------------

@Composable
fun PageHeader(title: String, actions: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
        actions()
    }
}

@Composable
fun MflCard(title: String? = null, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        color = Color.White,
        border = BorderStroke(1.dp, MflColors.Border),
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (title != null) {
                Text(title, style = MaterialTheme.typography.titleSmall, color = MflColors.Ink)
            }
            content()
        }
    }
}

/** Two-column label/value line used in summaries. */
@Composable
fun KeyValueRow(label: String, value: String, danger: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontSize = 13.sp, color = MflColors.Muted)
        Text(value, fontSize = 13.sp, color = if (danger) MflColors.Danger else MflColors.Ink, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun ActionButton(
    text: String,
    onClick: () -> Unit,
    primary: Boolean = false,
    enabled: Boolean = true,
    modifier: Modifier = Modifier,
) {
    if (primary) {
        Button(onClick = onClick, enabled = enabled, modifier = modifier) { Text(text, fontSize = 14.sp) }
    } else {
        OutlinedButton(onClick = onClick, enabled = enabled, modifier = modifier) { Text(text, fontSize = 14.sp) }
    }
}

@Composable
fun SegmentTabs(tabs: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        tabs.forEach { (key, label) ->
            val active = key == selected
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                TextButton(onClick = { onSelect(key) }) {
                    Text(
                        label,
                        fontSize = 14.sp,
                        fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal,
                        color = if (active) MflColors.Accent else MflColors.Muted,
                    )
                }
                HorizontalDivider(
                    color = if (active) MflColors.Accent else Color.Transparent,
                    thickness = 2.dp,
                    modifier = Modifier.width(120.dp),
                )
            }
        }
    }
}

/** Footer with fixed height (see [PAGER_HEIGHT]): big Prev / Next targets for thumbs. */
@Composable
fun PaginationBar(page: Int, totalPages: Int, onChange: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(PAGER_HEIGHT).padding(top = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        OutlinedButton(onClick = { onChange(page - 1) }, enabled = page > 1, modifier = Modifier.height(40.dp)) {
            Text("‹ Prev", fontSize = 14.sp)
        }
        Text("Page $page of ${maxOf(totalPages, 1)}", fontSize = 14.sp, color = MflColors.Muted)
        OutlinedButton(onClick = { onChange(page + 1) }, enabled = page < totalPages, modifier = Modifier.height(40.dp)) {
            Text("Next ›", fontSize = 14.sp)
        }
    }
}

@Composable
fun EmptyText(text: String) {
    Text(
        text,
        fontSize = 13.sp,
        color = MflColors.Muted,
        textAlign = TextAlign.Center,
        modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp),
    )
}

@Composable
fun ErrorText(text: String) {
    Text(text, fontSize = 13.sp, color = MflColors.Danger)
}

@Composable
fun DryRunBanner() {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(6.dp),
        color = Color(0xFFEEF2FF),
        border = BorderStroke(2.dp, Color(0xFF818CF8)),
    ) {
        Text(
            "DRY RUN PREVIEW — nothing is saved until you confirm.",
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = Color(0xFF3730A3),
            modifier = Modifier.padding(10.dp),
        )
    }
}

@Composable
fun StatusBadge(status: String, label: String = status) {
    val (bg, fg) = when (status) {
        "OPEN" -> Color(0xFFE2E8F0) to Color(0xFF1E293B)
        "PARTIAL" -> Color(0xFFFEF3C7) to Color(0xFF78350F)
        "OVERDUE", "DEFAULTED" -> Color(0xFFDC2626) to Color.White
        "CLOSED", "VERIFIED", "ACTIVE", "SUCCESS" -> Color(0xFFD1FAE5) to Color(0xFF065F46)
        "WAIVED" -> Color(0xFFF1F5F9) to Color(0xFF475569)
        "REVERSED", "BOUNCED" -> Color(0xFFFEE2E2) to Color(0xFF991B1B)
        else -> Color(0xFFF1F5F9) to Color(0xFF334155)
    }
    Surface(shape = RoundedCornerShape(50), color = bg) {
        Text(
            label,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = fg,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
        )
    }
}

// ---- Form inputs ---------------------------------------------------------------------------------

@Composable
fun FormField(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    error: String? = null,
    hint: String? = null,
    keyboard: KeyboardType = KeyboardType.Text,
    password: Boolean = false,
    enabled: Boolean = true,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label, fontSize = 13.sp) },
        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 15.sp),
        supportingText = {
            val msg = error ?: hint
            if (msg != null) {
                Text(msg, fontSize = 11.sp, color = if (error != null) MflColors.Danger else MflColors.Muted)
            }
        },
        isError = error != null,
        singleLine = true,
        enabled = enabled,
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = keyboard),
        modifier = modifier.fillMaxWidth(),
    )
}

/** Dropdown in the style of a <select>. `options` are (value, label) pairs. */
@Composable
fun OptionPicker(
    label: String,
    value: String,
    options: List<Pair<String, String>>,
    onPick: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    var open by remember { mutableStateOf(false) }
    val shown = options.firstOrNull { it.first == value }?.second ?: value.ifEmpty { "All" }
    Box(modifier.fillMaxWidth()) {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
            Text("$label: $shown", fontSize = 13.sp, maxLines = 1)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { (v, l) ->
                DropdownMenuItem(
                    text = { Text(l, fontSize = 14.sp) },
                    onClick = {
                        open = false
                        onPick(v)
                    },
                )
            }
        }
    }
}

// ---- Dialogs -------------------------------------------------------------------------------------

/** Single-field edit (the pencil icon). Options turn the field into a dropdown. */
@Composable
fun EditValueDialog(
    title: String,
    label: String,
    initial: String,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit,
    keyboard: KeyboardType = KeyboardType.Text,
    options: List<String> = emptyList(),
    hint: String? = null,
    saving: Boolean = false,
    error: String? = null,
) {
    var value by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (options.isNotEmpty()) {
                    OptionPicker(label, value, options.map { it to it }, onPick = { value = it })
                } else {
                    FormField(label, value, onChange = { value = it }, keyboard = keyboard, hint = hint)
                }
                if (error != null) ErrorText(error)
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(value) }, enabled = !saving) { Text("Save") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
    )
}

/** Multi-field form dialog (create customer, create address, collect payment). */
@Composable
fun FormDialog(
    title: String,
    confirmText: String,
    saving: Boolean,
    error: String?,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit,
    content: @Composable ColumnScope.() -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                content()
                if (error != null) ErrorText(error)
            }
        },
        confirmButton = {
            TextButton(onClick = onConfirm, enabled = !saving) { Text(confirmText) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
    )
}

fun toast(context: Context, message: String) {
    Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
}
