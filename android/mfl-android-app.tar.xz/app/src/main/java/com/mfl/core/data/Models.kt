package com.mfl.core.data

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

// Models mirror src/types/mfl-api.ts. Only fields the screens use are declared; the rest are ignored.
// Money fields arrive as JSON numbers. Enum-like fields stay String so new backend values do not break decoding.

@Serializable
data class Address(
    val addressId: Long = 0,
    val country: String = "",
    val state: String = "",
    val district: String = "",
    val policeStation: String? = null,
    val village: String? = null,
    val mohalla: String? = null,
    val postalCode: String = "",
)

@Serializable
data class Customer(
    val customerId: Long = 0,
    val customerName: String = "",
    val guardianName: String = "",
    val guardianRelation: String = "",
    val customerMobile: String = "",
    val addressId: Long = 0,
    val guarantorId: Long? = null,
    val guarantorRelation: String? = null,
    val customerStatus: String? = null,
    val customerRating: Double? = null,
    val familyIncome: Double? = null,
    val familyLoan: Double? = null,
)

@Serializable
data class Loan(
    val loanId: Long = 0,
    val loanAccountNo: String = "",
    val customerId: Long = 0,
    val guarantorId: Long? = null,
    val remPrincipalAmt: Double = 0.0,
    val rateOfInterest: Double = 0.0,
    val modifiedBorrowingDate: String = "",
    val emiStartDate: String? = null,
    val emiFirstInstallmentDate: String? = null,
    val emiLastInstallmentDate: String? = null,
    val loanType: String = "",
    val totalNoOfKist: Int = 0,
    val installmentAmount: Double = 0.0,
    val loanStatus: String = "",
    val managerAmount: Double = 0.0,
    val ownerAmount: Double = 0.0,
    val processingFee: Double = 0.0,
    val loanPurpose: String? = null,
)

@Serializable
data class ScheduleRow(
    val paymentScheduleId: Long = 0,
    val loanId: Long = 0,
    val loanType: String = "",
    val customerName: String = "",
    val customerMobile: String = "",
    val mohalla: String? = null,
    val guardianName: String = "",
    val guarantorName: String? = null,
    val currentKistNo: Int = 0,
    val totalNoOfKist: Int = 0,
    val remPrincipalAmt: Double = 0.0,
    val rateOfInterest: Double = 0.0,
    val emiStartDate: String? = null,
    val emiFirstInstallmentDate: String? = null,
    val emiLastInstallmentDate: String? = null,
    val installmentDate: String = "",
    val installmentAmount: Double = 0.0,
    val fineAmount: Double = 0.0,
    val otherAmount: Double = 0.0,
    val partialPrincipalAmtReturn: Double = 0.0,
    val kistInterestAmount: Double = 0.0,
    val forgiveAmount: Double = 0.0,
    val paymentDate: String? = null,
    val amountPaid: Double = 0.0,
    val remainingPrincipalAmt: Double = 0.0,
    val balanceDue: Double = 0.0,
    val managerName: String? = null,
    val managerReceivedAmount: Double = 0.0,
    val ownerName: String? = null,
    val ownerReceivedAmount: Double = 0.0,
    val payerName: String? = null,
    val status: String = "",
)

@Serializable
data class PaymentRecord(
    val paymentId: Long = 0,
    val receiptNo: String = "",
    val paymentScheduleId: Long? = null,
    val loanId: Long = 0,
    val currentKistNo: Int? = null,
    val installmentDate: String? = null,
    val paymentAmount: Double = 0.0,
    val managerReceivedAmount: Double = 0.0,
    val ownerReceivedAmount: Double = 0.0,
    val payerName: String? = null,
    val paymentDate: String = "",
    val paymentMode: String = "",
    val transactionRef: String? = null,
    val paymentStatus: String = "",
    val remarks: String? = null,
    val customerName: String? = null,
)

@Serializable
data class OverdueItem(
    val paymentScheduleId: Long = 0,
    val loanId: Long = 0,
    val currentKistNo: Int = 0,
    val installmentDate: String = "",
    val days: Int = 0,
    val fineAmount: Double = 0.0,
    val kistInterestAmount: Double = 0.0,
    val dueAmount: Double = 0.0,
    val status: String = "",
)

@Serializable
data class OverdueResult(
    val runDate: String = "",
    val dryRun: Boolean = true,
    val rowCount: Int = 0,
    val totalDue: Double = 0.0,
    val items: List<OverdueItem> = emptyList(),
)

@Serializable
data class ReportResult(
    val dryRun: Boolean = true,
    val rowCount: Int = 0,
    val statusCounts: Map<String, Int> = emptyMap(),
    val totalOverdueAmount: Double = 0.0,
    val filePath: String? = null,
)

@Serializable
data class OnetimeDryRunItem(
    val loanId: Long = 0,
    val loanAccountNo: String = "",
    val customerName: String = "",
    val guardianName: String = "",
    val remPrincipalAmt: Double = 0.0,
    val days: Int = 0,
    val perDayInterest: Double = 0.0,
    val interestAmount: Double = 0.0,
    val totalDue: Double = 0.0,
)

@Serializable
data class OnetimeSettlement(
    val dryRun: Boolean = true,
    val loanId: Long = 0,
    val guardianName: String = "",
    val hisabDate: String = "",
    val days: Int = 0,
    val perDayInterest: Double = 0.0,
    val interestAmount: Double = 0.0,
    val totalDue: Double = 0.0,
    val remPrincipalAmt: Double = 0.0,
    val amountPaid: Double? = null,
    val forgiveAmount: Double? = null,
    val shortfallAmount: Double? = null,
    val loanStatus: String? = null,
)

@Serializable
data class GenerateResult(
    val billingPeriod: String = "",
    val generatedCount: Int = 0,
    @SerialName("cycle_12_count") val cycle12Count: Int = 0,
    @SerialName("cycle_25_count") val cycle25Count: Int = 0,
    val skippedAlreadyGenerated: Int = 0,
    val skippedKistsCompleted: Int = 0,
    val skippedNotDueYet: Int = 0,
)

@Serializable
data class DashboardSummary(
    val period: Period = Period(),
    val portfolio: Portfolio = Portfolio(),
    val capital: Capital = Capital(),
    val cycles: Map<String, CycleStat> = emptyMap(),
    val risk: Risk = Risk(),
    val customers: CustomerStats = CustomerStats(),
    val topVillages: List<VillageDue> = emptyList(),
    val todaysReceipts: List<ReceiptToday> = emptyList(),
    val alerts: List<Alert> = emptyList(),
)

@Serializable
data class Period(val billingYear: Int = 0, val billingMonth: Int = 0, val asOf: String = "")

@Serializable
data class Portfolio(
    val activeAum: Double = 0.0,
    val activeLoans: Int = 0,
    val closedLoans: Int = 0,
    val productMix: Map<String, Int> = emptyMap(),
)

@Serializable
data class Capital(
    val ownerDeployed: Double = 0.0,
    val managerDeployed: Double = 0.0,
    val processingFees: Double = 0.0,
    val mtdCollected: Double = 0.0,
    val mtdOwnerReceived: Double = 0.0,
    val mtdManagerReceived: Double = 0.0,
    val mtdCash: Double = 0.0,
    val mtdUpi: Double = 0.0,
    val mtdReceipts: Int = 0,
    val totalForgiven: Double = 0.0,
)

@Serializable
data class CycleStat(
    val expected: Double = 0.0,
    val collected: Double = 0.0,
    val pending: Double = 0.0,
    val openKists: Int = 0,
    val efficiencyPct: Double = 0.0,
)

@Serializable
data class Risk(
    val overduePartialKists: Int = 0,
    val overduePartialLoans: Int = 0,
    val overduePartialDue: Double = 0.0,
    val finesAndInterest: Double = 0.0,
    val forgivenOnOverdue: Double = 0.0,
)

@Serializable
data class CustomerStats(
    val total: Int = 0,
    val activeBorrowers: Int = 0,
    val guarantors: Int = 0,
    val kycPending: Int = 0,
    val blacklisted: Int = 0,
)

@Serializable
data class VillageDue(val village: String = "", val loans: Int = 0, val due: Double = 0.0)

@Serializable
data class ReceiptToday(
    val receiptNo: String = "",
    val customerName: String = "",
    val loanId: Long = 0,
    val amount: Double = 0.0,
    val paymentMode: String = "",
    val currentKistNo: Int? = null,
    val paymentDate: String = "",
    val paymentStatus: String = "",
)

@Serializable
data class Alert(val type: String = "", val message: String = "")
