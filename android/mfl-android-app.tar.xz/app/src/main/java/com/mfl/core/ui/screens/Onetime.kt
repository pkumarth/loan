package com.mfl.core.ui.screens
import androidx.compose.ui.unit.sp
import androidx.compose.ui.Alignment

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.mfl.core.data.ApiClient
import com.mfl.core.data.Lookups
import com.mfl.core.data.OnetimeDryRunItem
import com.mfl.core.data.OnetimeSettlement
import com.mfl.core.data.Page
import com.mfl.core.data.userMessage
import com.mfl.core.ui.components.*
import com.mfl.core.ui.theme.MflColors
import com.mfl.core.util.formatDate
import com.mfl.core.util.formatWhole
import com.mfl.core.util.isoToday
import com.mfl.core.util.plainNumber
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

/**
 * One-time (OT) loans: a dry-run board for every active OT loan as of a hisab date,
 * plus settlement for one loan. Preview first, then confirm to save.
 */
@Composable
fun OnetimeScreen() {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var hisab by remember { mutableStateOf(isoToday()) }
    var board by remember { mutableStateOf<Page<List<OnetimeDryRunItem>>?>(null) }
    var boardPage by remember { mutableIntStateOf(1) }
    var boardBusy by remember { mutableStateOf(false) }
    var boardError by remember { mutableStateOf<String?>(null) }

    fun loadBoard(p: Int) {
        boardBusy = true
        boardError = null
        scope.launch {
            try {
                val body = buildJsonObject { put("hisab_date", hisab) }
                board = ApiClient.call<List<OnetimeDryRunItem>>(
                    "/payment-schedules/onetime-dry-run", "POST",
                    query = mapOf("page" to p, "size" to 50), body = body,
                )
                boardPage = p
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                boardError = e.userMessage()
            } finally {
                boardBusy = false
            }
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        PageHeader("One-time Hisab & Settlement")

        MflCard(title = "Hisab dry run") {
            FormField("Hisab date (YYYY-MM-DD)", hisab, onChange = { hisab = it })
            ActionButton(
                text = "Run dry run for all active OT loans",
                onClick = { loadBoard(1) },
                primary = true,
                enabled = !boardBusy,
                modifier = Modifier.fillMaxWidth(),
            )
            boardError?.let { ErrorText(it) }
            DryRunBanner()
        }

        board?.let { page ->
            val rows = page.data
            MflCard(title = "Dry-run board") {
                if (rows.isEmpty()) {
                    EmptyText("No active one-time loans.")
                } else {
                    DataTable(
                        rows,
                        listOf(
                            DataColumn<OnetimeDryRunItem>("Loan ID", 80.dp) { it.loanId.toString() },
                            DataColumn<OnetimeDryRunItem>("Account no", 120.dp) { it.loanAccountNo },
                            DataColumn<OnetimeDryRunItem>("Customer", 150.dp) { it.customerName },
                            DataColumn<OnetimeDryRunItem>("Guardian", 130.dp) { it.guardianName },
                            DataColumn<OnetimeDryRunItem>("Principal", 110.dp, right = true) { formatWhole(it.remPrincipalAmt) },
                            DataColumn<OnetimeDryRunItem>("Days", 70.dp, right = true) { it.days.toString() },
                            DataColumn<OnetimeDryRunItem>("Per day", 90.dp, right = true) { plainNumber(it.perDayInterest) },
                            DataColumn<OnetimeDryRunItem>("Interest", 100.dp, right = true) { formatWhole(it.interestAmount) },
                            DataColumn<OnetimeDryRunItem>("Total due", 110.dp, right = true) { formatWhole(it.totalDue) },
                        ),
                    )
                }
                PaginationBar(boardPage, page.pagination?.totalPages ?: 1) { loadBoard(it) }
            }
        }

        SettlementCard(
            hisab = hisab,
            onSaved = {
                Lookups.invalidate()
                loadBoard(boardPage)
            },
        )
    }
}

@Composable
private fun SettlementCard(hisab: String, onSaved: () -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var loanId by remember { mutableStateOf("") }
    var manager by remember { mutableStateOf("") }
    var owner by remember { mutableStateOf("") }
    var forgive by remember { mutableStateOf("") }
    var payer by remember { mutableStateOf("") }
    var preview by remember { mutableStateOf<OnetimeSettlement?>(null) }
    var saved by remember { mutableStateOf<OnetimeSettlement?>(null) }
    var confirming by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun settle(dry: Boolean, onDone: (OnetimeSettlement) -> Unit) {
        val id = loanId.toLongOrNull()
        if (id == null) {
            error = "Enter a loan ID"
            return
        }
        saving = true
        error = null
        scope.launch {
            try {
                val body = buildJsonObject {
                    put("loan_id", id)
                    put("hisab_date", hisab)
                    put("dry_run", dry)
                    put("manager_received_amount", manager.toDoubleOrNull() ?: 0.0)
                    put("owner_received_amount", owner.toDoubleOrNull() ?: 0.0)
                    put("forgive_amount", forgive.toDoubleOrNull() ?: 0.0)
                    put("payer_name", payer.ifBlank { null })
                }
                val res = ApiClient.call<OnetimeSettlement>("/payment-schedules/onetime-settlement", "POST", body = body).data
                onDone(res)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = e.userMessage()
            } finally {
                saving = false
            }
        }
    }

    MflCard(title = "Settle one loan") {
        FormField("Loan ID", loanId, onChange = { loanId = it.filter(Char::isDigit) }, keyboard = KeyboardType.Number)
        FormField("Manager received (₹)", manager, onChange = { manager = it }, keyboard = KeyboardType.Decimal)
        FormField("Owner received (₹)", owner, onChange = { owner = it }, keyboard = KeyboardType.Decimal)
        FormField("Forgive (₹)", forgive, onChange = { forgive = it }, keyboard = KeyboardType.Decimal)
        FormField("Payer name", payer, onChange = { payer = it })
        error?.let { ErrorText(it) }
        ActionButton(
            text = "Preview settlement",
            onClick = {
                settle(true) {
                    preview = it
                    saved = null
                }
            },
            enabled = !saving,
            modifier = Modifier.fillMaxWidth(),
        )

        preview?.let { p ->
            DryRunBanner()
            KeyValueRow("Days", p.days.toString())
            KeyValueRow("Interest", formatWhole(p.interestAmount))
            KeyValueRow("Total due", formatWhole(p.totalDue))
            KeyValueRow("Shortfall", formatWhole(p.shortfallAmount))
            ActionButton(
                text = "Confirm & save settlement",
                onClick = { confirming = true },
                primary = true,
                enabled = !saving,
                modifier = Modifier.fillMaxWidth(),
            )
        }

        saved?.let { s ->
            Text("Saved — loan status: ${s.loanStatus ?: "—"}", fontSize = 13.sp, color = MflColors.Ink)
        }
    }

    if (confirming) {
        FormDialog(
            title = "Save settlement",
            confirmText = "Save",
            saving = saving,
            error = error,
            onDismiss = { confirming = false },
            onConfirm = {
                settle(false) {
                    saved = it
                    preview = null
                    confirming = false
                    toast(context, "Settlement recorded")
                    onSaved()
                }
            },
        ) {
            Text("Record the settlement for loan ${loanId} as of ${formatDate(hisab)}?", fontSize = 15.sp)
        }
    }
}
