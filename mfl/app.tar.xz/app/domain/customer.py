from decimal import Decimal
from enum import Enum
from typing import Optional
from pydantic import AliasChoices, Field, model_validator
from app.domain.common import CleanBaseModel


class RelationEnum(str, Enum):
    FATHER = "FATHER"
    HUSBAND = "HUSBAND"
    MOTHER = "MOTHER"
    OTHER = "OTHER"


class KycStatusEnum(str, Enum):
    NOT_UPLOADED = "NOT_UPLOADED"
    UPLOADED = "UPLOADED"
    PENDING = "PENDING"
    VERIFIED = "VERIFIED"
    REJECTED = "REJECTED"


class CustomerStatusEnum(str, Enum):
    ACTIVE = "ACTIVE"
    INACTIVE = "INACTIVE"
    BLACKLISTED = "BLACKLISTED"


CUSTOMER_MUTABLE_COLUMNS: tuple[str, ...] = (
    "customer_code", "customer_name", "guardian_name", "guardian_relation",
    "guarantor_id", "guarantor_relation", "guarantor_mobile",
    "customer_mobile", "customer_email", "address_id",
    "aadhaar_no", "pan_no", "aadhaar_img_s3_key", "pan_img_s3_key", "kyc_status",
    "family_income", "family_loan", "customer_status", "customer_rating",
)

CUSTOMER_ALL_COLUMNS: tuple[str, ...] = (
    "customer_id", *CUSTOMER_MUTABLE_COLUMNS,
    "created_at", "updated_at", "created_by", "updated_by", "version",
)


class CustomerCreate(CleanBaseModel):
    customer_code: Optional[str] = Field(default=None, max_length=30)
    customer_name: str = Field(..., max_length=120)
    guardian_name: str = Field(..., max_length=120)
    guardian_relation: RelationEnum = RelationEnum.FATHER
    guarantor_id: Optional[int] = Field(
        default=None, gt=0, validation_alias=AliasChoices("guarantor_id", "guarantorId", "gurantorId")
    )
    guarantor_relation: RelationEnum = RelationEnum.FATHER
    guarantor_mobile: Optional[str] = Field(default=None, max_length=15)
    customer_mobile: str = Field(..., min_length=10, max_length=15)
    customer_email: Optional[str] = Field(default=None, max_length=120)
    address_id: int = Field(..., gt=0, validation_alias=AliasChoices("address_id", "addressId"))
    aadhaar_no: Optional[str] = Field(default=None, min_length=12, max_length=12)
    pan_no: Optional[str] = Field(default=None, min_length=10, max_length=10)
    aadhaar_img_s3_key: Optional[str] = Field(default=None, max_length=512)
    pan_img_s3_key: Optional[str] = Field(default=None, max_length=512)
    kyc_status: KycStatusEnum = KycStatusEnum.NOT_UPLOADED
    family_income: Decimal = Field(default=Decimal("0.00"), ge=0)
    family_loan: Decimal = Field(default=Decimal("0.00"), ge=0)
    customer_status: CustomerStatusEnum = CustomerStatusEnum.ACTIVE
    customer_rating: int = Field(default=8, ge=0)


class CustomerUpdate(CustomerCreate):
    version: Optional[int] = Field(default=None, ge=1)


class CustomerSingleFieldPatch(CleanBaseModel):
    customer_code: Optional[str] = Field(default=None, max_length=30)
    customer_name: Optional[str] = Field(default=None, max_length=120)
    guardian_name: Optional[str] = Field(default=None, max_length=120)
    guardian_relation: Optional[RelationEnum] = None
    guarantor_id: Optional[int] = Field(
        default=None, gt=0, validation_alias=AliasChoices("guarantor_id", "guarantorId", "gurantorId")
    )
    guarantor_relation: Optional[RelationEnum] = None
    guarantor_mobile: Optional[str] = Field(default=None, max_length=15)
    customer_mobile: Optional[str] = Field(default=None, min_length=10, max_length=15)
    customer_email: Optional[str] = Field(default=None, max_length=120)
    address_id: Optional[int] = Field(default=None, gt=0)
    aadhaar_no: Optional[str] = Field(default=None, min_length=12, max_length=12)
    pan_no: Optional[str] = Field(default=None, min_length=10, max_length=10)
    aadhaar_img_s3_key: Optional[str] = Field(default=None, max_length=512)
    pan_img_s3_key: Optional[str] = Field(default=None, max_length=512)
    kyc_status: Optional[KycStatusEnum] = None
    family_income: Optional[Decimal] = Field(default=None, ge=0)
    family_loan: Optional[Decimal] = Field(default=None, ge=0)
    customer_status: Optional[CustomerStatusEnum] = None
    customer_rating: Optional[int] = Field(default=None, ge=0)
    version: Optional[int] = Field(default=None, ge=1)

    @model_validator(mode="after")
    def validate_single_field_only(self):
        provided = self.model_fields_set - {"version"}
        if len(provided) != 1:
            raise ValueError(f"Exactly 1 customer field required; received {len(provided)}")
        field_name = next(iter(provided))
        non_nullable = {
            "customer_code", "customer_name", "guardian_name", "guardian_relation",
            "guarantor_relation", "customer_mobile", "address_id", "kyc_status",
            "family_income", "family_loan", "customer_status", "customer_rating",
        }
        if field_name in non_nullable and getattr(self, field_name) is None:
            raise ValueError(f"'{field_name}' cannot be null or empty")
        return self


class CustomerFilterParams(CleanBaseModel):
    customer_ids: Optional[str] = None
    customer_code: Optional[str] = None
    customer_name: Optional[str] = None
    customer_mobile: Optional[str] = None
    address_id: Optional[int] = None
    guarantor_id: Optional[int] = None
    aadhaar_no: Optional[str] = None
    pan_no: Optional[str] = None
    kyc_status: Optional[KycStatusEnum] = None
    customer_status: Optional[CustomerStatusEnum] = None

    def has_any_filter(self) -> bool:
        return any(getattr(self, f) is not None for f in self.__class__.model_fields)
