from datetime import date
from typing import Optional
from pydantic import Field
from app.domain.common import CleanBaseModel


class OverdueComputeRequest(CleanBaseModel):
    loan_id: Optional[int] = Field(default=None, gt=0)
    run_date: Optional[date] = None
    dry_run: bool = False
