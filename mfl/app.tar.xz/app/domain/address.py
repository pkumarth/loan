from typing import Optional
from pydantic import Field, model_validator
from app.domain.common import CleanBaseModel

ADDRESS_MUTABLE_COLUMNS: tuple[str, ...] = (
    "country", "state", "district", "police_station",
    "village", "mohalla", "ward_no", "landmark", "postal_code",
)

ADDRESS_ALL_COLUMNS: tuple[str, ...] = (
    "address_id", *ADDRESS_MUTABLE_COLUMNS,
    "created_at", "updated_at", "created_by", "updated_by", "version",
)


class AddressCreate(CleanBaseModel):
    country: Optional[str] = Field(default="India", max_length=60)
    state: Optional[str] = Field(default="BIHAR", max_length=80)
    district: Optional[str] = Field(default="MADHUBANI", max_length=80)
    police_station: Optional[str] = Field(default=None, max_length=100)
    village: Optional[str] = Field(default=None, max_length=100)
    mohalla: Optional[str] = Field(default=None, max_length=100)
    ward_no: Optional[str] = Field(default=None, max_length=30)
    landmark: Optional[str] = Field(default=None, max_length=150)
    postal_code: str = Field(..., min_length=4, max_length=12)

    @model_validator(mode="after")
    def apply_defaults(self):
        self.country = self.country or "India"
        self.state = self.state or "BIHAR"
        self.district = self.district or "MADHUBANI"
        return self


class AddressUpdate(AddressCreate):
    version: Optional[int] = Field(default=None, ge=1)


class AddressSingleFieldPatch(CleanBaseModel):
    country: Optional[str] = Field(default=None, max_length=60)
    state: Optional[str] = Field(default=None, max_length=80)
    district: Optional[str] = Field(default=None, max_length=80)
    police_station: Optional[str] = Field(default=None, max_length=100)
    village: Optional[str] = Field(default=None, max_length=100)
    mohalla: Optional[str] = Field(default=None, max_length=100)
    ward_no: Optional[str] = Field(default=None, max_length=30)
    landmark: Optional[str] = Field(default=None, max_length=150)
    postal_code: Optional[str] = Field(default=None, min_length=4, max_length=12)
    version: Optional[int] = Field(default=None, ge=1)

    @model_validator(mode="after")
    def validate_single_field_only(self):
        provided = self.model_fields_set - {"version"}
        if len(provided) != 1:
            raise ValueError(f"Exactly 1 address field required; received {len(provided)}")
        field_name = next(iter(provided))
        if field_name in ("country", "state", "district", "postal_code") and getattr(self, field_name) is None:
            raise ValueError(f"'{field_name}' cannot be null or empty")
        return self


class AddressFilterParams(CleanBaseModel):
    address_ids: Optional[str] = None
    country: Optional[str] = None
    state: Optional[str] = None
    district: Optional[str] = None
    police_station: Optional[str] = None
    village: Optional[str] = None
    mohalla: Optional[str] = None
    ward_no: Optional[str] = None
    postal_code: Optional[str] = None

    def has_any_filter(self) -> bool:
        return any(getattr(self, f) is not None for f in self.__class__.model_fields)
