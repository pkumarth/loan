import calendar
import re
from datetime import date, datetime
from decimal import Decimal
from enum import Enum
from typing import Optional, Union
from pydantic import AliasChoices, Field, model_validator
from app.domain.common import CleanBaseModel
from app.domain.loan import LoanTypeEnum

YEAR_MONTH_REGEX = re.compile(r"^(\d{4})-(0[1-9]|1[0-2])$")


class ScheduleStatusEnum(str, Enum):
    OPEN = "OPEN"
    PARTIAL = "PARTIAL"
    CLOSED = "CLOSED"
    OVERDUE = "OVERDUE"
    WAIVED = "WAIVED"


SCHEDULE_PATCH_COLUMNS: tuple[str, ...] = (
    "loan_id", "loan_parent_id", "current_kist_no", "installment_date",
    "installment_amount", "fine_amount", "other_amount",
    "partial_principal_amt_return", "kist_interest_amount", "forgive_amount",
    "manager_name", "manager_received_amount", "owner_name", "owner_received_amount", "payer_name",
    "amount_paid", "remaining_principal_amt", "status", "payment_date",
)

SCHEDULE_WRITE_COLUMNS: tuple[str, ...] = ("loan_type", *SCHEDULE_PATCH_COLUMNS)

SCHEDULE_ALL_COLUMNS: tuple[str, ...] = (
    "payment_schedule_id", "loan_id", "loan_parent_id", "loan_account_no",
    "customer_id", "customer_name", "customer_mobile", "mohalla", "village",
    "guardian_name", "guarantor_name", "guarantor_mobile",
    "rem_principal_amt", "rate_of_interest", "borrowing_date",
    "emi_start_date", "emi_first_installment_date", "emi_last_installment_date",
    "loan_type", "total_no_of_kist", "current_kist_no", "installment_date",
    "billing_year", "billing_month",
    "installment_amount", "fine_amount", "other_amount",
    "partial_principal_amt_return", "kist_interest_amount", "forgive_amount",
    "manager_name", "manager_received_amount", "owner_name", "owner_received_amount", "payer_name",
    "amount_paid", "remaining_principal_amt", "balance_due", "status", "payment_date",
    "created_at", "updated_at", "created_by", "updated_by", "version",
)

BALANCE_DUE_FORMULA_DEPS: tuple[str, ...] = (
    "installment_amount", "fine_amount", "other_amount",
    "kist_interest_amount", "forgive_amount", "amount_paid",
)


def _parse_year_month(year: Optional[int], month: Optional[Union[int, str]], default_today: bool):
    today = date.today()
    if month is None and year is None:
        return (today.year, today.month) if default_today else (None, None)
    if isinstance(month, str):
        m = YEAR_MONTH_REGEX.match(month)
        if m:
            py, pm = int(m.group(1)), int(m.group(2))
            if year is not None and year != py:
                raise ValueError(f"billing_year ({year}) conflicts with billing_month ('{month}')")
            return py, pm
        if month.isdigit():
            month = int(month)
        else:
            raise ValueError("billing_month must be 'YYYY-MM' or integer 1..12")
    if isinstance(month, int):
        if not (1 <= month <= 12):
            raise ValueError("billing_month must be between 1 and 12")
        return (year or (today.year if default_today else None)), month
    if default_today:
        raise ValueError("billing_month (1..12) is required when billing_year is provided")
    return year, None


class MonthlyScheduleGenerateRequest(CleanBaseModel):
    billing_year: Optional[int] = Field(default=None, ge=2000, le=2100)
    billing_month: Optional[Union[int, str]] = None
    cycle_12_start_day: int = Field(default=8, ge=1, le=28)
    cycle_12_cutoff_day: int = Field(default=20, ge=1, le=28)
    dry_run: bool = False

    @model_validator(mode="after")
    def validate_period(self):
        self.billing_year, self.billing_month = _parse_year_month(
            self.billing_year, self.billing_month, default_today=True
        )
        if self.cycle_12_start_day > self.cycle_12_cutoff_day:
            raise ValueError(
                f"cycle_12_start_day ({self.cycle_12_start_day}) must be <= cycle_12_cutoff_day ({self.cycle_12_cutoff_day})"
            )
        return self

    def month_bounds(self) -> tuple[int, int, date, date]:
        y, m = int(self.billing_year), int(self.billing_month)
        return y, m, date(y, m, 1), date(y, m, calendar.monthrange(y, m)[1])


class ScheduleCreate(CleanBaseModel):
    loan_id: int = Field(..., gt=0)
    loan_parent_id: Optional[int] = Field(default=None, gt=0, validation_alias=AliasChoices("loan_parent_id", "parent_loan_id"))
    current_kist_no: int = Field(..., gt=0, validation_alias=AliasChoices("current_kist_no", "kist_no"))
    installment_date: date
    installment_amount: Decimal = Field(..., ge=0)
    fine_amount: Decimal = Field(default=Decimal("0.00"), ge=0)
    other_amount: Decimal = Field(default=Decimal("0.00"), ge=0)
    partial_principal_amt_return: Decimal = Field(default=Decimal("0.00"), ge=0)
    kist_interest_amount: Decimal = Field(
        default=Decimal("0.00"), ge=0, validation_alias=AliasChoices("kist_interest_amount", "interest_amount")
    )
    forgive_amount: Decimal = Field(default=Decimal("0.00"), ge=0)
    manager_name: Optional[str] = Field(default=None, max_length=120)
    manager_received_amount: Decimal = Field(default=Decimal("0.00"), ge=0)
    owner_name: Optional[str] = Field(default=None, max_length=120)
    owner_received_amount: Decimal = Field(default=Decimal("0.00"), ge=0)
    payer_name: Optional[str] = Field(default=None, max_length=120)
    amount_paid: Decimal = Field(default=Decimal("0.00"), ge=0)
    remaining_principal_amt: Decimal = Field(default=Decimal("0.00"), ge=0)
    status: ScheduleStatusEnum = ScheduleStatusEnum.OPEN
    payment_date: Optional[datetime] = None

    @model_validator(mode="after")
    def validate_received_split(self):
        split_sum = self.manager_received_amount + self.owner_received_amount
        if split_sum != self.amount_paid + self.forgive_amount:
            raise ValueError(
                f"manager_received_amount ({self.manager_received_amount}) + "
                f"owner_received_amount ({self.owner_received_amount}) must equal "
                f"amount_paid ({self.amount_paid}) + forgive_amount ({self.forgive_amount}); got {split_sum}"
            )
        return self


class ScheduleUpdate(ScheduleCreate):
    version: Optional[int] = Field(default=None, ge=1)


class ScheduleSingleFieldPatch(CleanBaseModel):
    current_kist_no: Optional[int] = Field(default=None, gt=0, validation_alias=AliasChoices("current_kist_no", "kist_no"))
    installment_date: Optional[date] = None
    installment_amount: Optional[Decimal] = Field(default=None, ge=0)
    fine_amount: Optional[Decimal] = Field(default=None, ge=0)
    other_amount: Optional[Decimal] = Field(default=None, ge=0)
    partial_principal_amt_return: Optional[Decimal] = Field(default=None, ge=0)
    kist_interest_amount: Optional[Decimal] = Field(
        default=None, ge=0, validation_alias=AliasChoices("kist_interest_amount", "interest_amount")
    )
    forgive_amount: Optional[Decimal] = Field(default=None, ge=0)
    manager_name: Optional[str] = Field(default=None, max_length=120)
    manager_received_amount: Optional[Decimal] = Field(default=None, ge=0)
    owner_name: Optional[str] = Field(default=None, max_length=120)
    owner_received_amount: Optional[Decimal] = Field(default=None, ge=0)
    payer_name: Optional[str] = Field(default=None, max_length=120)
    amount_paid: Optional[Decimal] = Field(default=None, ge=0)
    remaining_principal_amt: Optional[Decimal] = Field(default=None, ge=0)
    status: Optional[ScheduleStatusEnum] = None
    payment_date: Optional[datetime] = None
    version: Optional[int] = Field(default=None, ge=1)

    @model_validator(mode="after")
    def validate_single_field_only(self):
        provided = self.model_fields_set - {"version"}
        if len(provided) != 1:
            raise ValueError(f"Exactly 1 schedule field required; received {len(provided)}")
        field_name = next(iter(provided))
        non_nullable = {
            "current_kist_no", "installment_date", "installment_amount", "fine_amount",
            "other_amount", "partial_principal_amt_return", "kist_interest_amount",
            "forgive_amount", "manager_received_amount", "owner_received_amount",
            "amount_paid", "remaining_principal_amt", "status",
        }
        if field_name in non_nullable and getattr(self, field_name) is None:
            raise ValueError(f"'{field_name}' cannot be null or empty")
        return self


class ScheduleFilterParams(CleanBaseModel):
    payment_schedule_ids: Optional[str] = None
    loan_id: Optional[int] = None
    loan_parent_id: Optional[int] = None
    customer_id: Optional[int] = None
    loan_type: Optional[LoanTypeEnum] = None
    current_kist_no: Optional[int] = Field(default=None, validation_alias=AliasChoices("current_kist_no", "kist_no"))
    installment_date: Optional[date] = None
    billing_year: Optional[int] = Field(default=None, ge=2000, le=2100)
    billing_month: Optional[Union[int, str]] = None
    status: Optional[ScheduleStatusEnum] = None

    @model_validator(mode="after")
    def normalize_period(self):
        self.billing_year, self.billing_month = _parse_year_month(
            self.billing_year, self.billing_month, default_today=False
        )
        return self

    def has_any_filter(self) -> bool:
        return any(getattr(self, f) is not None for f in self.__class__.model_fields)
