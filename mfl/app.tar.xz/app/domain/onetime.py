from datetime import date
from decimal import Decimal
from typing import Optional
from pydantic import Field
from app.domain.common import CleanBaseModel


class OnetimeDryRunRequest(CleanBaseModel):
    hisab_date: Optional[date] = None


class OnetimeSettlementRequest(CleanBaseModel):
    loan_id: int = Field(..., gt=0)
    hisab_date: Optional[date] = None
    dry_run: bool = False
    manager_received_amount: Decimal = Field(default=Decimal("0.00"), ge=0)
    owner_received_amount: Decimal = Field(default=Decimal("0.00"), ge=0)
    forgive_amount: Decimal = Field(default=Decimal("0.00"), ge=0)
    payer_name: Optional[str] = Field(default=None, max_length=120)
