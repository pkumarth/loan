from typing import Optional
from pydantic import Field
from app.domain.common import CleanBaseModel

REPORT_COLUMNS: tuple[str, ...] = (
    "loan_id", "report_billing_year", "report_billing_month", "report_run_date",
    "loan_parent_id", "loan_type", "report_status",
    "borrower_name", "guardian_name", "borrower_mobile", "guarantor_name", "guarantor_mobile", "mohalla", "village",
    "borrowing_date", "modified_borrowing_date", "emi_start_date", "emi_first_installment_date", "emi_last_installment_date",
    "total_no_of_kist", "manager_name", "owner_name", "rem_principal_amt",
    "current_payment_schedule_id", "current_kist_no", "installment_date", "billing_year", "billing_month", "installment_amount",
    "total_overdue_amount", "total_fine_amount", "total_interest_amount", "total_other_amount",
    "total_manager_paid_amount", "total_owner_paid_amount", "open_kist_count", "overdue_kist_count",
)


class ReportGenerateRequest(CleanBaseModel):
    billing_year: Optional[int] = Field(default=None, ge=2000, le=2100)
    billing_month: Optional[int] = Field(default=None, ge=1, le=12)
    dry_run: bool = False
