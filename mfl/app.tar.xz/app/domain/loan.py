import calendar
from datetime import date
from decimal import Decimal
from enum import Enum
from typing import Optional
from pydantic import AliasChoices, Field, model_validator
from app.domain.common import CleanBaseModel


def add_months(base_date: date, months: int) -> date:
    total_month = (base_date.month - 1) + months
    year = base_date.year + (total_month // 12)
    month = (total_month % 12) + 1
    max_day = calendar.monthrange(year, month)[1]
    return date(year, month, min(base_date.day, max_day))


class LoanTypeEnum(str, Enum):
    EMI = "EMI"
    MONTHLY_INTEREST = "MONTHLY_INTEREST"
    ONETIME = "ONETIME"


class RepaymentFreqEnum(str, Enum):
    MONTHLY = "MONTHLY"
    ONETIME = "ONETIME"


class LoanStatusEnum(str, Enum):
    DRAFT = "DRAFT"
    ACTIVE = "ACTIVE"
    CLOSED = "CLOSED"
    RESTRUCTURED = "RESTRUCTURED"
    DEFAULTED = "DEFAULTED"


LOAN_WRITE_COLUMNS: tuple[str, ...] = (
    "loan_account_no", "loan_parent_id", "customer_id", "guarantor_id",
    "rem_principal_amt", "original_principal_amt_k", "rate_of_interest",
    "borrowing_date", "modified_borrowing_date", "emi_start_date", "emi_first_installment_date", "emi_last_installment_date",
    "loan_type", "repayment_frequency", "total_no_of_kist", "installment_amount",
    "closed_date", "additional_interest", "loan_status",
    "manager_name", "manager_amount", "processing_fee", "owner_name", "owner_amount",
    "loan_purpose", "fine_rule", "description",
)

# Columns that may be changed after creation. Capital split, original principal and
# remaining principal are fixed or changed only by the ONETIME settlement algorithm.
LOAN_UPDATE_COLUMNS: tuple[str, ...] = (
    "loan_account_no", "loan_parent_id", "customer_id", "guarantor_id",
    "rate_of_interest", "borrowing_date", "emi_start_date", "emi_first_installment_date", "emi_last_installment_date",
    "loan_type", "repayment_frequency", "total_no_of_kist", "installment_amount",
    "closed_date", "additional_interest", "loan_status",
    "processing_fee", "manager_name", "owner_name",
    "loan_purpose", "fine_rule", "description",
)

# Fields a client may never change after creation (400 if a different value is sent).
# Names are DB columns; the payload name for rem_principal_amt is `principal_amt`.
LOAN_PROTECTED_COLUMNS: tuple[str, ...] = (
    "rem_principal_amt", "original_principal_amt_k", "modified_borrowing_date", "manager_amount", "owner_amount",
)

# Request payload field name -> DB column, for fields whose names differ.
LOAN_PAYLOAD_TO_COLUMN: dict[str, str] = {"principal_amt": "rem_principal_amt"}

LOAN_ALL_COLUMNS: tuple[str, ...] = (
    "loan_id", "loan_account_no", "loan_parent_id", "customer_id", "guarantor_id",
    "rem_principal_amt", "original_principal_amt_k", "rate_of_interest",
    "borrowing_date", "modified_borrowing_date", "emi_start_date", "emi_first_installment_date", "emi_last_installment_date",
    "loan_type", "repayment_frequency", "total_no_of_kist", "installment_amount",
    "closed_date", "additional_interest", "loan_status",
    "manager_name", "manager_amount", "processing_fee", "owner_name", "owner_amount",
    "loan_purpose", "fine_rule", "description",
    "created_at", "updated_at", "created_by", "updated_by", "version",
)


class LoanCreate(CleanBaseModel):
    customer_id: int = Field(..., gt=0, validation_alias=AliasChoices("customer_id", "customerId"))
    guarantor_id: Optional[int] = Field(
        default=None, gt=0, validation_alias=AliasChoices("guarantor_id", "guarantorId", "gurantorId")
    )
    loan_account_no: Optional[str] = Field(default=None, max_length=30)
    loan_parent_id: Optional[int] = Field(
        default=None, gt=0, validation_alias=AliasChoices("loan_parent_id", "parent_loan_id", "parentLoanId")
    )
    principal_amt: Decimal = Field(default=Decimal("50000.00"), gt=0)
    rate_of_interest: Optional[Decimal] = Field(default=None, ge=0)
    borrowing_date: date = Field(default_factory=date.today)
    emi_start_date: Optional[date] = None
    emi_first_installment_date: Optional[date] = None
    emi_last_installment_date: Optional[date] = None
    loan_type: LoanTypeEnum = LoanTypeEnum.EMI
    repayment_frequency: Optional[RepaymentFreqEnum] = None
    total_no_of_kist: Optional[int] = Field(default=None, gt=0)
    installment_amount: Decimal = Field(
        default=Decimal("6000.00"), ge=0,
        validation_alias=AliasChoices("installment_amount", "monthly_amount", "monthlyAmount"),
    )
    closed_date: Optional[date] = None
    additional_interest: Decimal = Field(default=Decimal("0.000"), ge=0)
    loan_status: LoanStatusEnum = LoanStatusEnum.ACTIVE
    manager_name: Optional[str] = Field(default=None, max_length=120)
    manager_amount: Decimal = Field(default=Decimal("0.00"), ge=0)
    processing_fee: Decimal = Field(default=Decimal("200.00"), ge=0)
    owner_name: Optional[str] = Field(default=None, max_length=120)
    owner_amount: Decimal = Field(default=Decimal("0.00"), ge=0)
    loan_purpose: Optional[str] = Field(default=None, max_length=150)
    fine_rule: Optional[str] = Field(default=None, max_length=255)
    description: Optional[str] = None

    @model_validator(mode="after")
    def apply_loan_rules(self):
        if self.rate_of_interest is None:
            self.rate_of_interest = Decimal("2.000")

        split_k = (self.manager_amount + self.owner_amount) / Decimal(1000)
        principal_k = self.principal_amt / Decimal(1000)
        if split_k != principal_k:
            raise ValueError(
                f"(manager_amount ({self.manager_amount}) + owner_amount ({self.owner_amount})) / 1000 "
                f"must equal original principal in k ({principal_k}); got {split_k}"
            )

        if self.loan_type == LoanTypeEnum.EMI:
            self.repayment_frequency = self.repayment_frequency or RepaymentFreqEnum.MONTHLY
            self.total_no_of_kist = self.total_no_of_kist or 12
            self.emi_start_date = self.emi_start_date or self.borrowing_date
            self.emi_first_installment_date = self.emi_first_installment_date or add_months(self.emi_start_date, 1)
            self.emi_last_installment_date = self.emi_last_installment_date or add_months(self.emi_start_date, self.total_no_of_kist)
        elif self.loan_type == LoanTypeEnum.MONTHLY_INTEREST:
            self.repayment_frequency = self.repayment_frequency or RepaymentFreqEnum.MONTHLY
            self.total_no_of_kist = self.total_no_of_kist or 12
            self.emi_start_date = self.emi_start_date or self.borrowing_date
            self.emi_first_installment_date = None
            self.emi_last_installment_date = None
        else:
            self.repayment_frequency = self.repayment_frequency or RepaymentFreqEnum.ONETIME
            self.total_no_of_kist = self.total_no_of_kist or 1
            self.emi_start_date = None
            self.emi_first_installment_date = None
            self.emi_last_installment_date = None
        return self


class LoanUpdate(LoanCreate):
    version: Optional[int] = Field(default=None, ge=1)


class LoanSingleFieldPatch(CleanBaseModel):
    loan_account_no: Optional[str] = Field(default=None, max_length=30)
    loan_parent_id: Optional[int] = Field(default=None, gt=0, validation_alias=AliasChoices("loan_parent_id", "parent_loan_id"))
    customer_id: Optional[int] = Field(default=None, gt=0, validation_alias=AliasChoices("customer_id", "customerId"))
    guarantor_id: Optional[int] = Field(default=None, gt=0, validation_alias=AliasChoices("guarantor_id", "guarantorId", "gurantorId"))
    principal_amt: Optional[Decimal] = Field(default=None, gt=0)
    rate_of_interest: Optional[Decimal] = Field(default=None, ge=0)
    borrowing_date: Optional[date] = None
    emi_start_date: Optional[date] = None
    emi_first_installment_date: Optional[date] = None
    emi_last_installment_date: Optional[date] = None
    loan_type: Optional[LoanTypeEnum] = None
    repayment_frequency: Optional[RepaymentFreqEnum] = None
    total_no_of_kist: Optional[int] = Field(default=None, gt=0)
    installment_amount: Optional[Decimal] = Field(
        default=None, ge=0, validation_alias=AliasChoices("installment_amount", "monthly_amount")
    )
    closed_date: Optional[date] = None
    additional_interest: Optional[Decimal] = Field(default=None, ge=0)
    loan_status: Optional[LoanStatusEnum] = None
    manager_name: Optional[str] = Field(default=None, max_length=120)
    manager_amount: Optional[Decimal] = Field(default=None, ge=0)
    processing_fee: Optional[Decimal] = Field(default=None, ge=0)
    owner_name: Optional[str] = Field(default=None, max_length=120)
    owner_amount: Optional[Decimal] = Field(default=None, ge=0)
    loan_purpose: Optional[str] = Field(default=None, max_length=150)
    fine_rule: Optional[str] = Field(default=None, max_length=255)
    description: Optional[str] = None
    version: Optional[int] = Field(default=None, ge=1)

    @model_validator(mode="after")
    def validate_single_field_only(self):
        provided = self.model_fields_set - {"version"}
        if len(provided) != 1:
            raise ValueError(f"Exactly 1 loan field required; received {len(provided)}")
        field_name = next(iter(provided))
        non_nullable = {
            "loan_account_no", "customer_id", "principal_amt", "rate_of_interest",
            "borrowing_date", "loan_type", "repayment_frequency",
            "total_no_of_kist", "installment_amount", "additional_interest",
            "loan_status", "manager_amount", "processing_fee", "owner_amount",
        }
        if field_name in non_nullable and getattr(self, field_name) is None:
            raise ValueError(f"'{field_name}' cannot be null or empty")
        return self


class LoanFilterParams(CleanBaseModel):
    loan_ids: Optional[str] = None
    loan_account_no: Optional[str] = None
    customer_id: Optional[int] = None
    guarantor_id: Optional[int] = None
    loan_parent_id: Optional[int] = None
    loan_type: Optional[LoanTypeEnum] = None
    loan_status: Optional[LoanStatusEnum] = None
    borrowing_date: Optional[date] = None
    manager_name: Optional[str] = None
    owner_name: Optional[str] = None

    def has_any_filter(self) -> bool:
        return any(getattr(self, f) is not None for f in self.__class__.model_fields)
