from fastapi import Depends, FastAPI, status
from fastapi.middleware.cors import CORSMiddleware
from app.api.v1.router import v1_router
from app.core.config import settings
from app.core.database import get_db
from app.core.exceptions import register_exception_handlers
from app.util.response import build_response

app = FastAPI(
    title=settings.APP_NAME,
    version="1.0.0",
    docs_url=f"{settings.APP_ROOT_PREFIX}/docs",
    redoc_url=f"{settings.APP_ROOT_PREFIX}/redoc",
    openapi_url=f"{settings.APP_ROOT_PREFIX}/openapi.json",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["Content-Type", "Authorization", "X-User-Id"],
)

register_exception_handlers(app)


@app.get(f"{settings.APP_ROOT_PREFIX}/health", tags=["0. Health"])
def health_check(conn=Depends(get_db)):
    with conn.cursor() as cur:
        cur.execute("SELECT 1 AS ok")
        cur.fetchone()
    return build_response(
        status_code=status.HTTP_200_OK,
        display_msg="MFL Core Service is healthy",
        data={"service": "mfl-core", "version": "v1"},
    )


app.include_router(v1_router, prefix=f"{settings.APP_ROOT_PREFIX}{settings.API_V1_PREFIX}")
