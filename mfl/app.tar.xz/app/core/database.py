import pymysql
from pymysql.cursors import DictCursor
from dbutils.pooled_db import PooledDB
from fastapi import Header
from app.core.config import settings

_pool = PooledDB(
    creator=pymysql,
    maxconnections=settings.DB_POOL_MAX,
    mincached=2,
    maxcached=5,
    blocking=True,
    ping=1,
    host=settings.DB_HOST,
    user=settings.DB_USER,
    password=settings.DB_PASSWORD,
    database=settings.DB_NAME,
    port=settings.DB_PORT,
    charset="utf8mb4",
    cursorclass=DictCursor,
    autocommit=False,
    connect_timeout=5,
)


def get_db():
    conn = _pool.connection()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def get_actor(x_user_id: str | None = Header(default=None, alias="X-User-Id")) -> str:
    return (x_user_id or "SYSTEM").strip() or "SYSTEM"
