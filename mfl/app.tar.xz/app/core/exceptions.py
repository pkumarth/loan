import pymysql
from fastapi import FastAPI, Request, status
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException
from app.util.response import ResponseStatus, build_response


class AppException(Exception):
    def __init__(
        self,
        status_code: int,
        display_msg: str,
        cause: str,
        resp_status: ResponseStatus = ResponseStatus.FAILURE,
        data=None,
    ):
        self.status_code = status_code
        self.display_msg = display_msg
        self.cause = cause
        self.resp_status = resp_status
        self.data = data


def register_exception_handlers(app: FastAPI) -> None:
    @app.exception_handler(AppException)
    async def app_exception_handler(request: Request, exc: AppException):
        return build_response(
            status_code=exc.status_code,
            display_msg=exc.display_msg,
            cause=exc.cause,
            resp_status=exc.resp_status,
            data=exc.data,
        )

    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(request: Request, exc: RequestValidationError):
        errors = [
            f"{'.'.join(str(loc) for loc in e['loc'] if loc != 'body')}: {e['msg']}"
            for e in exc.errors()
        ]
        return build_response(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            display_msg="Validation failed for request payload or parameters",
            cause="; ".join(errors),
            resp_status=ResponseStatus.FAILURE,
        )

    @app.exception_handler(StarletteHTTPException)
    async def http_exception_handler(request: Request, exc: StarletteHTTPException):
        return build_response(
            status_code=exc.status_code,
            display_msg=str(exc.detail),
            cause="HTTP_ERROR",
            resp_status=ResponseStatus.FAILURE,
        )

    @app.exception_handler(pymysql.err.IntegrityError)
    async def mysql_integrity_handler(request: Request, exc: pymysql.err.IntegrityError):
        err_code, err_msg = exc.args
        mapping = {
            1062: (status.HTTP_409_CONFLICT, "Duplicate record already exists"),
            1451: (status.HTTP_409_CONFLICT, "Cannot delete record because child records reference it"),
            1452: (status.HTTP_400_BAD_REQUEST, "Referenced parent record does not exist"),
        }
        code, msg = mapping.get(err_code, (status.HTTP_400_BAD_REQUEST, "Database integrity constraint violated"))
        return build_response(status_code=code, display_msg=msg, cause=err_msg, resp_status=ResponseStatus.FAILURE)

    @app.exception_handler(pymysql.err.DataError)
    async def mysql_data_handler(request: Request, exc: pymysql.err.DataError):
        return build_response(
            status_code=status.HTTP_400_BAD_REQUEST,
            display_msg="Numeric range or column length exceeded",
            cause=str(exc),
            resp_status=ResponseStatus.FAILURE,
        )

    @app.exception_handler(Exception)
    async def unhandled_exception_handler(request: Request, exc: Exception):
        return build_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            display_msg="Internal server error occurred",
            cause=str(exc),
            resp_status=ResponseStatus.FAILURE,
        )
