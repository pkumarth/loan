import os


class Settings:
    APP_NAME: str = "MFL Core Service"
    APP_ROOT_PREFIX: str = os.getenv("APP_ROOT_PREFIX", "/mfl-core")
    API_V1_PREFIX: str = os.getenv("API_V1_PREFIX", "/api/v1")

    DEFAULT_PAGE_SIZE: int = 30
    MAX_PAGE_SIZE: int = 200

    DB_HOST: str = os.getenv("DB_HOST", "127.0.0.1")
    DB_PORT: int = int(os.getenv("DB_PORT", 3306))
    DB_USER: str = os.getenv("DB_USER", "root")
    DB_PASSWORD: str = os.getenv("DB_PASSWORD", "")
    DB_NAME: str = os.getenv("DB_NAME", "mfl_db")
    DB_POOL_MAX: int = int(os.getenv("DB_POOL_MAX", 10))

    REPORT_DIR: str = os.getenv("REPORT_DIR", "reports")


settings = Settings()
