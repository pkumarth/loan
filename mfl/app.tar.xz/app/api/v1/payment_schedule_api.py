from datetime import date
from fastapi import APIRouter, Body, Depends, Query, status
from app.core.config import settings
from app.core.database import get_actor, get_db
from app.domain.loan import LoanTypeEnum
from app.domain.payment_schedule import (
    MonthlyScheduleGenerateRequest,
    ScheduleCreate,
    ScheduleFilterParams,
    ScheduleSingleFieldPatch,
    ScheduleStatusEnum,
    ScheduleUpdate,
)
from app.service.payment_schedule_service import payment_schedule_service
from app.util.response import build_response

router = APIRouter()


@router.post("/generate-monthly", status_code=status.HTTP_201_CREATED)
def generate_monthly_schedules(
    payload: MonthlyScheduleGenerateRequest | None = Body(default=None),
    conn=Depends(get_db),
    actor: str = Depends(get_actor),
):
    req = payload or MonthlyScheduleGenerateRequest()
    summary = payment_schedule_service.generate_monthly_schedule(conn, req, actor)
    period = summary["billing_period"]
    generated = summary["generated_count"]
    if req.dry_run:
        return build_response(status.HTTP_200_OK, f"Dry-run preview for {period}: {generated} entries would be generated", data=summary)
    if generated > 0:
        return build_response(status.HTTP_201_CREATED, f"Generated {generated} schedule entries for {period}", data=summary)
    reasons = []
    if summary["skipped_already_generated"]:
        reasons.append(f"{summary['skipped_already_generated']} already generated")
    if summary["skipped_kists_completed"]:
        reasons.append(f"{summary['skipped_kists_completed']} with all kists completed")
    if summary["skipped_not_due_yet"]:
        reasons.append(f"{summary['skipped_not_due_yet']} not due yet")
    detail = "; ".join(reasons) if reasons else "no active EMI or MONTHLY_INTEREST loans found"
    return build_response(status.HTTP_200_OK, f"No new schedule entries generated for {period} ({detail})", data=summary)


@router.post("", status_code=status.HTTP_201_CREATED)
def create_schedule(payload: ScheduleCreate, conn=Depends(get_db), actor: str = Depends(get_actor)):
    return build_response(status.HTTP_201_CREATED, "Payment schedule entry created successfully", data=payment_schedule_service.create_schedule(conn, payload, actor))


@router.get("")
def bulk_get_schedules(
    payment_schedule_ids: str | None = Query(default=None), loan_id: int | None = Query(default=None),
    loan_parent_id: int | None = Query(default=None), customer_id: int | None = Query(default=None),
    loan_type: LoanTypeEnum | None = Query(default=None),
    current_kist_no: int | None = Query(default=None), kist_no: int | None = Query(default=None),
    installment_date: date | None = Query(default=None),
    billing_year: int | None = Query(default=None, ge=2000, le=2100),
    billing_month: str | None = Query(default=None),
    sched_status: ScheduleStatusEnum | None = Query(default=None, alias="status"),
    include: str | None = Query(default=None), exclude: str | None = Query(default=None),
    page: int = Query(default=1, ge=1), size: int = Query(default=settings.DEFAULT_PAGE_SIZE, ge=1, le=settings.MAX_PAGE_SIZE),
    conn=Depends(get_db),
):
    filters = ScheduleFilterParams(
        payment_schedule_ids=payment_schedule_ids, loan_id=loan_id, loan_parent_id=loan_parent_id, customer_id=customer_id,
        loan_type=loan_type, current_kist_no=current_kist_no if current_kist_no is not None else kist_no,
        installment_date=installment_date, billing_year=billing_year, billing_month=billing_month, status=sched_status,
    )
    rows, pagination = payment_schedule_service.list_schedules(conn, filters, include, exclude, page, size)
    return build_response(status.HTTP_200_OK, "Payment schedule entries retrieved successfully", data=rows, pagination=pagination)


@router.get("/{schedule_id}")
def get_schedule_by_id(schedule_id: int, include: str | None = Query(default=None), exclude: str | None = Query(default=None), conn=Depends(get_db)):
    return build_response(status.HTTP_200_OK, "Payment schedule entry retrieved successfully", data=payment_schedule_service.get_schedule_by_id(conn, schedule_id, include, exclude))


@router.put("/{schedule_id}")
def update_schedule_by_id(schedule_id: int, payload: ScheduleUpdate, conn=Depends(get_db), actor: str = Depends(get_actor)):
    return build_response(status.HTTP_200_OK, "Payment schedule entry updated successfully", data=payment_schedule_service.update_schedule(conn, schedule_id, payload, actor))


@router.patch("/{schedule_id}")
def patch_schedule_field(schedule_id: int, payload: ScheduleSingleFieldPatch, conn=Depends(get_db), actor: str = Depends(get_actor)):
    field_name, record = payment_schedule_service.patch_single_field(conn, schedule_id, payload, actor)
    return build_response(status.HTTP_200_OK, f"Schedule field '{field_name}' updated successfully", data=record)


@router.delete("/{schedule_id}")
def delete_schedule_by_id(schedule_id: int, conn=Depends(get_db)):
    payment_schedule_service.delete_schedule(conn, schedule_id)
    return build_response(status.HTTP_200_OK, "Payment schedule entry deleted successfully", data={"payment_schedule_id": schedule_id})
