from fastapi import APIRouter, Depends, Query, status
from app.core.config import settings
from app.core.database import get_actor, get_db
from app.domain.address import AddressCreate, AddressFilterParams, AddressSingleFieldPatch, AddressUpdate
from app.service.address_service import address_service
from app.util.response import build_response

router = APIRouter(prefix="/addresses", tags=["1. Addresses"])


@router.post("", status_code=status.HTTP_201_CREATED)
def create_address(payload: AddressCreate, conn=Depends(get_db), actor: str = Depends(get_actor)):
    return build_response(status.HTTP_201_CREATED, "Address created successfully", data=address_service.create_address(conn, payload, actor))


@router.get("")
def bulk_get_addresses(
    address_ids: str | None = Query(default=None), country: str | None = Query(default=None),
    state: str | None = Query(default=None), district: str | None = Query(default=None),
    police_station: str | None = Query(default=None), village: str | None = Query(default=None),
    mohalla: str | None = Query(default=None), ward_no: str | None = Query(default=None),
    postal_code: str | None = Query(default=None),
    include: str | None = Query(default=None), exclude: str | None = Query(default=None),
    page: int = Query(default=1, ge=1), size: int = Query(default=settings.DEFAULT_PAGE_SIZE, ge=1, le=settings.MAX_PAGE_SIZE),
    conn=Depends(get_db),
):
    filters = AddressFilterParams(
        address_ids=address_ids, country=country, state=state, district=district,
        police_station=police_station, village=village, mohalla=mohalla, ward_no=ward_no, postal_code=postal_code,
    )
    rows, pagination = address_service.list_addresses(conn, filters, include, exclude, page, size)
    return build_response(status.HTTP_200_OK, "Addresses retrieved successfully", data=rows, pagination=pagination)


@router.get("/{address_id}")
def get_address_by_id(address_id: int, include: str | None = Query(default=None), exclude: str | None = Query(default=None), conn=Depends(get_db)):
    return build_response(status.HTTP_200_OK, "Address retrieved successfully", data=address_service.get_address_by_id(conn, address_id, include, exclude))


@router.put("/{address_id}")
def update_address_by_id(address_id: int, payload: AddressUpdate, conn=Depends(get_db), actor: str = Depends(get_actor)):
    return build_response(status.HTTP_200_OK, "Address updated successfully", data=address_service.update_address(conn, address_id, payload, actor))


@router.patch("/{address_id}")
def patch_address_field(address_id: int, payload: AddressSingleFieldPatch, conn=Depends(get_db), actor: str = Depends(get_actor)):
    field_name, record = address_service.patch_single_field(conn, address_id, payload, actor)
    return build_response(status.HTTP_200_OK, f"Address field '{field_name}' updated successfully", data=record)


@router.delete("/{address_id}")
def delete_address_by_id(address_id: int, conn=Depends(get_db)):
    address_service.delete_address(conn, address_id)
    return build_response(status.HTTP_200_OK, "Address deleted successfully", data={"address_id": address_id})
