from fastapi import APIRouter, Body, Depends, status
from app.core.database import get_actor, get_db
from app.domain.report import ReportGenerateRequest
from app.service.report_service import report_service
from app.util.response import build_response

router = APIRouter()


@router.post("/report-generate", status_code=status.HTTP_200_OK)
def generate_report(
    payload: ReportGenerateRequest | None = Body(default=None),
    conn=Depends(get_db),
    actor: str = Depends(get_actor),
):
    req = payload or ReportGenerateRequest()
    result = report_service.generate(conn, req, actor)
    period = f"{result['billing_month']:02d}_{result['billing_year']}"
    prefix = "Dry-run payment schedule report" if req.dry_run else "Payment schedule report generated"
    return build_response(status.HTTP_200_OK, f"{prefix} for {period}: {result['row_count']} loans", data=result)
