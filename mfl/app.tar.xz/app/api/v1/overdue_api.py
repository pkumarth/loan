from fastapi import APIRouter, Body, Depends, status
from app.core.database import get_actor, get_db
from app.domain.overdue import OverdueComputeRequest
from app.service.overdue_service import overdue_service
from app.util.response import build_response

router = APIRouter()


@router.post("/overdue-compute", status_code=status.HTTP_200_OK)
def compute_overdue(
    payload: OverdueComputeRequest | None = Body(default=None),
    conn=Depends(get_db),
    actor: str = Depends(get_actor),
):
    req = payload or OverdueComputeRequest()
    result = overdue_service.compute(conn, req, actor)
    prefix = "Dry-run overdue preview" if req.dry_run else "Overdue computed"
    return build_response(status.HTTP_200_OK, f"{prefix}: {result['row_count']} open schedule rows", data=result)
