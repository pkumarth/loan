from datetime import date
from fastapi import APIRouter, Depends, Query, status
from app.core.config import settings
from app.core.database import get_actor, get_db
from app.domain.loan import LoanCreate, LoanFilterParams, LoanSingleFieldPatch, LoanStatusEnum, LoanTypeEnum, LoanUpdate
from app.service.loan_service import loan_service
from app.util.response import build_response

router = APIRouter(prefix="/loans", tags=["3. Loans"])


@router.post("", status_code=status.HTTP_201_CREATED)
def create_loan(payload: LoanCreate, conn=Depends(get_db), actor: str = Depends(get_actor)):
    return build_response(status.HTTP_201_CREATED, "Loan created successfully", data=loan_service.create_loan(conn, payload, actor))


@router.get("")
def bulk_get_loans(
    loan_ids: str | None = Query(default=None), loan_account_no: str | None = Query(default=None),
    customer_id: int | None = Query(default=None), guarantor_id: int | None = Query(default=None),
    loan_parent_id: int | None = Query(default=None), loan_type: LoanTypeEnum | None = Query(default=None),
    loan_status: LoanStatusEnum | None = Query(default=None), borrowing_date: date | None = Query(default=None),
    manager_name: str | None = Query(default=None), owner_name: str | None = Query(default=None),
    include: str | None = Query(default=None), exclude: str | None = Query(default=None),
    page: int = Query(default=1, ge=1), size: int = Query(default=settings.DEFAULT_PAGE_SIZE, ge=1, le=settings.MAX_PAGE_SIZE),
    conn=Depends(get_db),
):
    filters = LoanFilterParams(
        loan_ids=loan_ids, loan_account_no=loan_account_no, customer_id=customer_id,
        guarantor_id=guarantor_id, loan_parent_id=loan_parent_id, loan_type=loan_type,
        loan_status=loan_status, borrowing_date=borrowing_date, manager_name=manager_name, owner_name=owner_name,
    )
    rows, pagination = loan_service.list_loans(conn, filters, include, exclude, page, size)
    return build_response(status.HTTP_200_OK, "Loans retrieved successfully", data=rows, pagination=pagination)


@router.get("/{loan_id}")
def get_loan_by_id(loan_id: int, include: str | None = Query(default=None), exclude: str | None = Query(default=None), conn=Depends(get_db)):
    return build_response(status.HTTP_200_OK, "Loan retrieved successfully", data=loan_service.get_loan_by_id(conn, loan_id, include, exclude))


@router.put("/{loan_id}")
def update_loan_by_id(loan_id: int, payload: LoanUpdate, conn=Depends(get_db), actor: str = Depends(get_actor)):
    return build_response(status.HTTP_200_OK, "Loan updated successfully", data=loan_service.update_loan(conn, loan_id, payload, actor))


@router.patch("/{loan_id}")
def patch_loan_field(loan_id: int, payload: LoanSingleFieldPatch, conn=Depends(get_db), actor: str = Depends(get_actor)):
    field_name, record = loan_service.patch_single_field(conn, loan_id, payload, actor)
    return build_response(status.HTTP_200_OK, f"Loan field '{field_name}' updated successfully", data=record)


@router.delete("/{loan_id}")
def delete_loan_by_id(loan_id: int, conn=Depends(get_db)):
    loan_service.delete_loan(conn, loan_id)
    return build_response(status.HTTP_200_OK, "Loan deleted successfully", data={"loan_id": loan_id})
