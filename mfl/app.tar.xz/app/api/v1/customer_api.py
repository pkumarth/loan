from fastapi import APIRouter, Depends, Query, status
from app.core.config import settings
from app.core.database import get_actor, get_db
from app.domain.customer import CustomerCreate, CustomerFilterParams, CustomerSingleFieldPatch, CustomerStatusEnum, CustomerUpdate, KycStatusEnum
from app.service.customer_service import customer_service
from app.util.response import build_response

router = APIRouter(prefix="/customers", tags=["2. Customers"])


@router.post("", status_code=status.HTTP_201_CREATED)
def create_customer(payload: CustomerCreate, conn=Depends(get_db), actor: str = Depends(get_actor)):
    return build_response(status.HTTP_201_CREATED, "Customer created successfully", data=customer_service.create_customer(conn, payload, actor))


@router.get("")
def bulk_get_customers(
    customer_ids: str | None = Query(default=None), customer_code: str | None = Query(default=None),
    customer_name: str | None = Query(default=None), customer_mobile: str | None = Query(default=None),
    address_id: int | None = Query(default=None), guarantor_id: int | None = Query(default=None),
    aadhaar_no: str | None = Query(default=None), pan_no: str | None = Query(default=None),
    kyc_status: KycStatusEnum | None = Query(default=None), customer_status: CustomerStatusEnum | None = Query(default=None),
    include: str | None = Query(default=None), exclude: str | None = Query(default=None),
    page: int = Query(default=1, ge=1), size: int = Query(default=settings.DEFAULT_PAGE_SIZE, ge=1, le=settings.MAX_PAGE_SIZE),
    conn=Depends(get_db),
):
    filters = CustomerFilterParams(
        customer_ids=customer_ids, customer_code=customer_code, customer_name=customer_name,
        customer_mobile=customer_mobile, address_id=address_id, guarantor_id=guarantor_id,
        aadhaar_no=aadhaar_no, pan_no=pan_no, kyc_status=kyc_status, customer_status=customer_status,
    )
    rows, pagination = customer_service.list_customers(conn, filters, include, exclude, page, size)
    return build_response(status.HTTP_200_OK, "Customers retrieved successfully", data=rows, pagination=pagination)


@router.get("/{customer_id}")
def get_customer_by_id(customer_id: int, include: str | None = Query(default=None), exclude: str | None = Query(default=None), conn=Depends(get_db)):
    return build_response(status.HTTP_200_OK, "Customer retrieved successfully", data=customer_service.get_customer_by_id(conn, customer_id, include, exclude))


@router.put("/{customer_id}")
def update_customer_by_id(customer_id: int, payload: CustomerUpdate, conn=Depends(get_db), actor: str = Depends(get_actor)):
    return build_response(status.HTTP_200_OK, "Customer updated successfully", data=customer_service.update_customer(conn, customer_id, payload, actor))


@router.patch("/{customer_id}")
def patch_customer_field(customer_id: int, payload: CustomerSingleFieldPatch, conn=Depends(get_db), actor: str = Depends(get_actor)):
    field_name, record = customer_service.patch_single_field(conn, customer_id, payload, actor)
    return build_response(status.HTTP_200_OK, f"Customer field '{field_name}' updated successfully", data=record)


@router.delete("/{customer_id}")
def delete_customer_by_id(customer_id: int, conn=Depends(get_db)):
    customer_service.delete_customer(conn, customer_id)
    return build_response(status.HTTP_200_OK, "Customer deleted successfully", data={"customer_id": customer_id})
