from fastapi import APIRouter, Body, Depends, Query, status
from app.core.config import settings
from app.core.database import get_actor, get_db
from app.domain.onetime import OnetimeDryRunRequest, OnetimeSettlementRequest
from app.service.onetime_service import onetime_service
from app.util.response import build_response

router = APIRouter()


@router.post("/onetime-dry-run", status_code=status.HTTP_200_OK)
def onetime_dry_run_all(
    payload: OnetimeDryRunRequest | None = Body(default=None),
    page: int = Query(default=1, ge=1),
    size: int = Query(default=settings.DEFAULT_PAGE_SIZE, ge=1, le=settings.MAX_PAGE_SIZE),
    conn=Depends(get_db),
):
    hisab = payload.hisab_date if payload else None
    items, pagination, used = onetime_service.dry_run_all(conn, hisab, page, size)
    return build_response(
        status.HTTP_200_OK,
        f"ONETIME dry-run computed for {len(items)} active loans as of {used.isoformat()}",
        data=items,
        pagination=pagination,
    )


@router.post("/onetime-settlement", status_code=status.HTTP_201_CREATED)
def onetime_settlement(
    payload: OnetimeSettlementRequest,
    conn=Depends(get_db),
    actor: str = Depends(get_actor),
):
    result = onetime_service.settle(conn, payload, actor)
    if result["dry_run"]:
        return build_response(
            status.HTTP_200_OK,
            f"ONETIME dry-run for loan {payload.loan_id} as of {result['hisab_date'].isoformat()}",
            data=result,
        )
    return build_response(
        status.HTTP_201_CREATED,
        f"ONETIME settlement recorded for loan {payload.loan_id} (kist {result['current_kist_no']})",
        data=result,
    )
