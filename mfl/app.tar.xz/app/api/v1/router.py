from fastapi import APIRouter
from app.api.v1.address_api import router as address_router
from app.api.v1.customer_api import router as customer_router
from app.api.v1.loan_api import router as loan_router
from app.api.v1.onetime_api import router as onetime_router
from app.api.v1.payment_schedule_api import router as schedule_router
from app.api.v1.overdue_api import router as overdue_router
from app.api.v1.report_api import router as report_router

v1_router = APIRouter()
v1_router.include_router(address_router)
v1_router.include_router(customer_router)
v1_router.include_router(loan_router)
v1_router.include_router(schedule_router, prefix="/payment-schedules", tags=["4. Payment Schedule"])
v1_router.include_router(onetime_router, prefix="/payment-schedules", tags=["4. Payment Schedule"])
v1_router.include_router(overdue_router, prefix="/payment-schedules", tags=["4. Payment Schedule"])
v1_router.include_router(report_router, prefix="/payment-schedules", tags=["4. Payment Schedule"])
