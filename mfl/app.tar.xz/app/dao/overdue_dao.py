class OverdueDAO:
    def loan_exists(self, conn, loan_id: int) -> bool:
        with conn.cursor() as cur:
            cur.execute("SELECT 1 AS found FROM loans WHERE loan_id = %s", (loan_id,))
            return cur.fetchone() is not None

    def fetch_open_rows(self, conn, loan_id: int | None) -> list[dict]:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT ps.payment_schedule_id, ps.loan_id, ps.loan_type, ps.current_kist_no, ps.installment_date,
                       ps.installment_amount, ps.fine_amount, ps.other_amount, ps.kist_interest_amount,
                       ps.amount_paid, ps.status, l.rem_principal_amt AS loan_rem_principal_amt
                FROM payment_schedule ps
                INNER JOIN loans l ON l.loan_id = ps.loan_id
                WHERE ps.loan_type IN ('EMI', 'MONTHLY_INTEREST')
                  AND ps.status <> 'CLOSED'
                  AND l.loan_status = 'ACTIVE'
                  AND (%s IS NULL OR ps.loan_id = %s)
                ORDER BY ps.loan_id, ps.current_kist_no
                """,
                (loan_id, loan_id),
            )
            return cur.fetchall()

    def update_row(self, conn, schedule_id: int, fine, interest, status: str, actor: str) -> None:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE payment_schedule
                SET fine_amount = %s, kist_interest_amount = %s, status = %s, updated_by = %s, version = version + 1
                WHERE payment_schedule_id = %s
                """,
                (fine, interest, status, actor, schedule_id),
            )


overdue_dao = OverdueDAO()
