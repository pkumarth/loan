from enum import Enum
from typing import Any
from app.dao.base_dao import BaseDAO
from app.domain.loan import LOAN_ALL_COLUMNS, LOAN_UPDATE_COLUMNS, LOAN_WRITE_COLUMNS, LoanFilterParams


class LoanDAO(BaseDAO):
    table_name = "loans"
    pk_column = "loan_id"
    allowed_columns = LOAN_ALL_COLUMNS
    write_columns = LOAN_WRITE_COLUMNS
    update_columns = LOAN_UPDATE_COLUMNS
    patch_columns = LOAN_UPDATE_COLUMNS

    def set_parent_to_self(self, conn, loan_id: int) -> None:
        with conn.cursor() as cur:
            cur.execute("UPDATE loans SET loan_parent_id = loan_id WHERE loan_id = %s", (loan_id,))

    def clear_self_parent(self, conn, loan_id: int) -> None:
        """Root loans point to themselves; clear that so the row can be deleted (other children still block it)."""
        with conn.cursor() as cur:
            cur.execute("UPDATE loans SET loan_parent_id = NULL WHERE loan_id = %s AND loan_parent_id = loan_id", (loan_id,))

    def build_filter_query(self, filters: LoanFilterParams) -> tuple[list[str], list[Any]]:
        clauses, params = [], []
        if filters.loan_ids:
            ids = [int(x.strip()) for x in filters.loan_ids.split(",") if x.strip().isdigit()]
            if ids:
                clauses.append(f"`loan_id` IN ({', '.join(['%s'] * len(ids))})")
                params.extend(ids)
        for col in ("loan_account_no", "customer_id", "guarantor_id", "loan_parent_id", "loan_type", "loan_status", "borrowing_date", "manager_name", "owner_name"):
            val = getattr(filters, col)
            if val is not None:
                clauses.append(f"`{col}` = %s")
                params.append(val.value if isinstance(val, Enum) else val)
        return clauses, params


loan_dao = LoanDAO()
