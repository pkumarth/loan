from datetime import date
from app.domain.report import REPORT_COLUMNS


class ReportDAO:
    def fetch_scope_loans(self, conn, onetime_cutoff: date) -> list[dict]:
        """EMI / MONTHLY_INTEREST ACTIVE loans, plus ACTIVE ONETIME loans older than the cutoff (modified_borrowing_date)."""
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT l.loan_id, l.loan_parent_id, l.loan_type, l.borrowing_date, l.modified_borrowing_date,
                       l.emi_start_date, l.emi_first_installment_date, l.emi_last_installment_date,
                       l.total_no_of_kist, l.rem_principal_amt, l.manager_name, l.owner_name,
                       c.customer_name AS borrower_name, c.guardian_name, c.customer_mobile AS borrower_mobile,
                       g.customer_name AS guarantor_name,
                       COALESCE(g.customer_mobile, c.guarantor_mobile) AS guarantor_mobile,
                       a.mohalla, a.village
                FROM loans l
                INNER JOIN customers c ON c.customer_id = l.customer_id
                LEFT JOIN addresses a ON a.address_id = c.address_id
                LEFT JOIN customers g ON g.customer_id = COALESCE(l.guarantor_id, c.guarantor_id)
                WHERE l.loan_status = 'ACTIVE'
                  AND (l.loan_type IN ('EMI', 'MONTHLY_INTEREST')
                       OR (l.loan_type = 'ONETIME' AND l.modified_borrowing_date < %s))
                ORDER BY l.loan_id
                """,
                (onetime_cutoff,),
            )
            return cur.fetchall()

    def fetch_schedule_rows(self, conn, loan_ids: list[int]) -> list[dict]:
        if not loan_ids:
            return []
        placeholders = ", ".join(["%s"] * len(loan_ids))
        with conn.cursor() as cur:
            cur.execute(
                f"""
                SELECT ps.payment_schedule_id, ps.loan_id, ps.status, ps.installment_date, ps.current_kist_no,
                       ps.installment_amount, ps.fine_amount, ps.other_amount, ps.kist_interest_amount,
                       ps.amount_paid, ps.manager_received_amount, ps.owner_received_amount
                FROM payment_schedule ps
                WHERE ps.loan_id IN ({placeholders})
                """,
                tuple(loan_ids),
            )
            return cur.fetchall()

    def replace_all(self, conn, rows: list[dict]) -> None:
        """Purge the whole report table and insert the rebuilt rows, inside the caller's transaction."""
        cols = ", ".join(REPORT_COLUMNS)
        placeholders = ", ".join(["%s"] * len(REPORT_COLUMNS))
        with conn.cursor() as cur:
            cur.execute("DELETE FROM payment_schedule_report")
            if rows:
                cur.executemany(
                    f"INSERT INTO payment_schedule_report ({cols}) VALUES ({placeholders})",
                    [tuple(r[c] for c in REPORT_COLUMNS) for r in rows],
                )


report_dao = ReportDAO()
