import math
from enum import Enum
from typing import Any


def _db_val(val: Any) -> Any:
    return val.value if isinstance(val, Enum) else val


class BaseDAO:
    table_name: str = ""
    pk_column: str = "id"
    allowed_columns: tuple[str, ...] = ()
    write_columns: tuple[str, ...] = ()
    update_columns: tuple[str, ...] = ()
    patch_columns: tuple[str, ...] = ()

    def _safe_select_clause(self, columns: list[str]) -> str:
        allowed = set(self.allowed_columns)
        safe_cols = [f"`{c}`" for c in columns if c in allowed]
        if not safe_cols:
            raise ValueError("No valid columns selected")
        return ", ".join(safe_cols)

    def fetch_by_id(self, conn, record_id: int, columns: list[str]) -> dict | None:
        sql = f"SELECT {self._safe_select_clause(columns)} FROM `{self.table_name}` WHERE `{self.pk_column}` = %s"
        with conn.cursor() as cur:
            cur.execute(sql, (record_id,))
            return cur.fetchone()

    def fetch_paginated(
        self, conn, columns: list[str], where_clauses: list[str], params: list[Any], page: int, size: int
    ) -> tuple[list[dict], dict]:
        where_sql = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ""
        count_sql = f"SELECT COUNT(*) AS total FROM `{self.table_name}` {where_sql}"
        offset = (page - 1) * size
        data_sql = (
            f"SELECT {self._safe_select_clause(columns)} FROM `{self.table_name}` {where_sql} "
            f"ORDER BY `{self.pk_column}` DESC LIMIT %s OFFSET %s"
        )
        with conn.cursor() as cur:
            cur.execute(count_sql, tuple(params))
            total_elements = cur.fetchone()["total"]
            cur.execute(data_sql, (*params, size, offset))
            rows = cur.fetchall()

        total_pages = math.ceil(total_elements / size) if total_elements > 0 else 0
        return rows, {
            "page": page,
            "size": size,
            "total_elements": total_elements,
            "total_pages": total_pages,
            "has_next": page < total_pages,
        }

    def insert_row(self, conn, data: dict[str, Any], actor: str) -> int:
        cols = [c for c in self.write_columns if c in data]
        col_sql = ", ".join([*(f"`{c}`" for c in cols), "`created_by`", "`updated_by`", "`version`"])
        val_sql = ", ".join([*(["%s"] * len(cols)), "%s", "%s", "1"])
        sql = f"INSERT INTO `{self.table_name}` ({col_sql}) VALUES ({val_sql})"
        params = [*(_db_val(data[c]) for c in cols), actor, actor]
        with conn.cursor() as cur:
            cur.execute(sql, tuple(params))
            return cur.lastrowid

    def update_row(self, conn, record_id: int, data: dict[str, Any], actor: str, version: int | None = None) -> int:
        cols = [c for c in (self.update_columns or self.write_columns) if c in data]
        set_sql = ", ".join([*(f"`{c}` = %s" for c in cols), "`updated_by` = %s", "`version` = `version` + 1"])
        ver_sql = " AND `version` = %s" if version is not None else ""
        sql = f"UPDATE `{self.table_name}` SET {set_sql} WHERE `{self.pk_column}` = %s{ver_sql}"
        params: list[Any] = [*(_db_val(data[c]) for c in cols), actor, record_id]
        if version is not None:
            params.append(version)
        with conn.cursor() as cur:
            cur.execute(sql, tuple(params))
            return cur.rowcount

    def update_single_field(
        self, conn, record_id: int, field_name: str, field_value: Any, actor: str, version: int | None = None
    ) -> int:
        allowed_patch = self.patch_columns or self.write_columns
        if field_name not in allowed_patch:
            raise ValueError(f"Field '{field_name}' is not updatable")
        ver_sql = " AND `version` = %s" if version is not None else ""
        sql = (
            f"UPDATE `{self.table_name}` "
            f"SET `{field_name}` = %s, `updated_by` = %s, `version` = `version` + 1 "
            f"WHERE `{self.pk_column}` = %s{ver_sql}"
        )
        params: list[Any] = [_db_val(field_value), actor, record_id]
        if version is not None:
            params.append(version)
        with conn.cursor() as cur:
            cur.execute(sql, tuple(params))
            return cur.rowcount

    def delete_by_id(self, conn, record_id: int) -> int:
        sql = f"DELETE FROM `{self.table_name}` WHERE `{self.pk_column}` = %s"
        with conn.cursor() as cur:
            cur.execute(sql, (record_id,))
            return cur.rowcount
