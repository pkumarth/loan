from typing import Any
from app.dao.base_dao import BaseDAO
from app.domain.address import ADDRESS_ALL_COLUMNS, ADDRESS_MUTABLE_COLUMNS, AddressFilterParams


class AddressDAO(BaseDAO):
    table_name = "addresses"
    pk_column = "address_id"
    allowed_columns = ADDRESS_ALL_COLUMNS
    write_columns = ADDRESS_MUTABLE_COLUMNS

    def build_filter_query(self, filters: AddressFilterParams) -> tuple[list[str], list[Any]]:
        clauses, params = [], []
        if filters.address_ids:
            ids = [int(x.strip()) for x in filters.address_ids.split(",") if x.strip().isdigit()]
            if ids:
                clauses.append(f"`address_id` IN ({', '.join(['%s'] * len(ids))})")
                params.extend(ids)
        for col in ("country", "state", "district", "police_station", "village", "mohalla", "ward_no", "postal_code"):
            val = getattr(filters, col)
            if val is not None:
                clauses.append(f"`{col}` = %s")
                params.append(val)
        return clauses, params


address_dao = AddressDAO()
