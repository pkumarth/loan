import math
from datetime import date
from enum import Enum
from typing import Any
from app.dao.base_dao import BaseDAO
from app.domain.payment_schedule import (
    BALANCE_DUE_FORMULA_DEPS,
    SCHEDULE_ALL_COLUMNS,
    SCHEDULE_PATCH_COLUMNS,
    SCHEDULE_WRITE_COLUMNS,
    ScheduleFilterParams,
)

ENRICHED_SQL_MAP: dict[str, str] = {
    "payment_schedule_id": "ps.payment_schedule_id AS payment_schedule_id",
    "loan_id": "ps.loan_id AS loan_id",
    "loan_parent_id": "ps.loan_parent_id AS loan_parent_id",
    "loan_account_no": "l.loan_account_no AS loan_account_no",
    "customer_id": "l.customer_id AS customer_id",
    "customer_name": "c.customer_name AS customer_name",
    "customer_mobile": "c.customer_mobile AS customer_mobile",
    "mohalla": "a.mohalla AS mohalla",
    "village": "a.village AS village",
    "guardian_name": "c.guardian_name AS guardian_name",
    "guarantor_name": "g.customer_name AS guarantor_name",
    "guarantor_mobile": "COALESCE(g.customer_mobile, c.guarantor_mobile) AS guarantor_mobile",
    "rem_principal_amt": "l.rem_principal_amt AS rem_principal_amt",
    "rate_of_interest": "l.rate_of_interest AS rate_of_interest",
    "borrowing_date": "l.borrowing_date AS borrowing_date",
    "emi_start_date": "COALESCE(l.emi_start_date, l.borrowing_date) AS emi_start_date",
    "emi_first_installment_date": "l.emi_first_installment_date AS emi_first_installment_date",
    "emi_last_installment_date": "l.emi_last_installment_date AS emi_last_installment_date",
    "loan_type": "ps.loan_type AS loan_type",
    "total_no_of_kist": "l.total_no_of_kist AS total_no_of_kist",
    "current_kist_no": "ps.current_kist_no AS current_kist_no",
    "installment_date": "ps.installment_date AS installment_date",
    "billing_year": "ps.billing_year AS billing_year",
    "billing_month": "ps.billing_month AS billing_month",
    "installment_amount": "ps.installment_amount AS installment_amount",
    "fine_amount": "ps.fine_amount AS fine_amount",
    "other_amount": "ps.other_amount AS other_amount",
    "partial_principal_amt_return": "ps.partial_principal_amt_return AS partial_principal_amt_return",
    "kist_interest_amount": "ps.kist_interest_amount AS kist_interest_amount",
    "forgive_amount": "ps.forgive_amount AS forgive_amount",
    "manager_name": "ps.manager_name AS manager_name",
    "manager_received_amount": "ps.manager_received_amount AS manager_received_amount",
    "owner_name": "ps.owner_name AS owner_name",
    "owner_received_amount": "ps.owner_received_amount AS owner_received_amount",
    "payer_name": "ps.payer_name AS payer_name",
    "amount_paid": "ps.amount_paid AS amount_paid",
    "remaining_principal_amt": "ps.remaining_principal_amt AS remaining_principal_amt",
    "status": "ps.status AS status",
    "payment_date": "ps.payment_date AS payment_date",
    "created_at": "ps.created_at AS created_at",
    "updated_at": "ps.updated_at AS updated_at",
    "created_by": "ps.created_by AS created_by",
    "updated_by": "ps.updated_by AS updated_by",
    "version": "ps.version AS version",
}

ENRICHED_JOIN_SQL = """
    FROM payment_schedule ps
    INNER JOIN loans l ON l.loan_id = ps.loan_id
    INNER JOIN customers c ON c.customer_id = l.customer_id
    LEFT JOIN addresses a ON a.address_id = c.address_id
    LEFT JOIN customers g ON g.customer_id = COALESCE(l.guarantor_id, c.guarantor_id)
"""


class PaymentScheduleDAO(BaseDAO):
    table_name = "payment_schedule"
    pk_column = "payment_schedule_id"
    allowed_columns = SCHEDULE_ALL_COLUMNS
    write_columns = SCHEDULE_WRITE_COLUMNS
    patch_columns = SCHEDULE_PATCH_COLUMNS

    def _enriched_select(self, requested_cols: list[str]) -> str:
        db_cols = [c for c in requested_cols if c != "balance_due"]
        if "balance_due" in requested_cols:
            for dep in BALANCE_DUE_FORMULA_DEPS:
                if dep not in db_cols:
                    db_cols.append(dep)
        if not db_cols:
            db_cols = ["payment_schedule_id"]
        return ", ".join(ENRICHED_SQL_MAP[c] for c in db_cols if c in ENRICHED_SQL_MAP)

    def fetch_raw_by_id(self, conn, payment_schedule_id: int, columns: list[str]) -> dict | None:
        cols_sql = ", ".join(f"`{c}`" for c in columns)
        with conn.cursor() as cur:
            cur.execute(f"SELECT {cols_sql} FROM `payment_schedule` WHERE `payment_schedule_id` = %s", (payment_schedule_id,))
            return cur.fetchone()

    def fetch_enriched_by_id(self, conn, payment_schedule_id: int, requested_cols: list[str]) -> dict | None:
        sql = f"SELECT {self._enriched_select(requested_cols)} {ENRICHED_JOIN_SQL} WHERE ps.payment_schedule_id = %s"
        with conn.cursor() as cur:
            cur.execute(sql, (payment_schedule_id,))
            return cur.fetchone()

    def fetch_enriched_paginated(
        self, conn, requested_cols: list[str], where_clauses: list[str], params: list[Any], page: int, size: int
    ) -> tuple[list[dict], dict]:
        where_sql = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ""
        offset = (page - 1) * size
        count_sql = f"SELECT COUNT(*) AS total {ENRICHED_JOIN_SQL} {where_sql}"
        data_sql = (
            f"SELECT {self._enriched_select(requested_cols)} {ENRICHED_JOIN_SQL} {where_sql} "
            f"ORDER BY ps.installment_date DESC, ps.payment_schedule_id DESC LIMIT %s OFFSET %s"
        )
        with conn.cursor() as cur:
            cur.execute(count_sql, tuple(params))
            total_elements = cur.fetchone()["total"]
            cur.execute(data_sql, (*params, size, offset))
            rows = cur.fetchall()

        total_pages = math.ceil(total_elements / size) if total_elements > 0 else 0
        return rows, {
            "page": page, "size": size, "total_elements": total_elements,
            "total_pages": total_pages, "has_next": page < total_pages,
        }

    def exists_for_loan_and_year_month(
        self, conn, loan_id: int, billing_year: int, billing_month: int, exclude_payment_schedule_id: int | None = None
    ) -> bool:
        sql = "SELECT 1 FROM payment_schedule WHERE loan_id = %s AND billing_year = %s AND billing_month = %s"
        params: list[Any] = [loan_id, billing_year, billing_month]
        if exclude_payment_schedule_id is not None:
            sql += " AND payment_schedule_id <> %s"
            params.append(exclude_payment_schedule_id)
        with conn.cursor() as cur:
            cur.execute(sql + " LIMIT 1", tuple(params))
            return cur.fetchone() is not None

    def fetch_candidate_loans_for_billing(self, conn, billing_year: int, billing_month: int, month_start: date) -> list[dict]:
        sql = """
            SELECT
                l.loan_id, l.loan_parent_id, l.loan_account_no, l.customer_id,
                c.customer_name, a.mohalla, a.village, c.guardian_name,
                g.customer_name AS guarantor_name, c.customer_mobile,
                COALESCE(g.customer_mobile, c.guarantor_mobile) AS guarantor_mobile,
                l.rem_principal_amt, l.borrowing_date, l.rate_of_interest,
                COALESCE(l.emi_start_date, l.borrowing_date) AS effective_start_date,
                l.emi_first_installment_date, l.emi_last_installment_date,
                l.loan_type, l.total_no_of_kist, l.installment_amount,
                l.manager_name, l.owner_name,
                COALESCE(ps_agg.generated_kists, 0) AS generated_kists,
                ps_agg.existing_kist_nos,
                COALESCE(ps_agg.month_exists, 0) AS month_exists
            FROM loans l
            INNER JOIN customers c ON c.customer_id = l.customer_id
            LEFT JOIN addresses a ON a.address_id = c.address_id
            LEFT JOIN customers g ON g.customer_id = COALESCE(l.guarantor_id, c.guarantor_id)
            LEFT JOIN (
                SELECT
                    loan_id,
                    COUNT(payment_schedule_id) AS generated_kists,
                    GROUP_CONCAT(current_kist_no) AS existing_kist_nos,
                    SUM(CASE WHEN billing_year = %s AND billing_month = %s THEN 1 ELSE 0 END) AS month_exists
                FROM payment_schedule
                GROUP BY loan_id
            ) ps_agg ON ps_agg.loan_id = l.loan_id
            WHERE l.loan_type IN ('EMI', 'MONTHLY_INTEREST')
              AND l.loan_status = 'ACTIVE'
              AND COALESCE(l.emi_start_date, l.borrowing_date) < %s
            ORDER BY l.loan_id ASC
        """
        with conn.cursor() as cur:
            cur.execute(sql, (billing_year, billing_month, month_start))
            return cur.fetchall()

    def insert_batch_generated(self, conn, rows_to_insert: list[tuple]) -> int:
        if not rows_to_insert:
            return 0
        sql = """
            INSERT IGNORE INTO payment_schedule (
                loan_id, loan_parent_id, loan_type, current_kist_no, installment_date,
                installment_amount, fine_amount, other_amount,
                partial_principal_amt_return, kist_interest_amount, forgive_amount,
                manager_name, manager_received_amount, owner_name, owner_received_amount,
                amount_paid, remaining_principal_amt,
                status, created_by, updated_by, version
            ) VALUES (
                %s, %s, %s, %s, %s,
                %s, 0.00, 0.00,
                0.00, 0.00, 0.00,
                %s, 0.00, %s, 0.00,
                0.00, 0.00,
                'OPEN', %s, %s, 1
            )
        """
        with conn.cursor() as cur:
            cur.executemany(sql, rows_to_insert)
            return cur.rowcount

    def build_filter_query(self, filters: ScheduleFilterParams) -> tuple[list[str], list[Any]]:
        clauses, params = [], []
        if filters.payment_schedule_ids:
            ids = [int(x.strip()) for x in filters.payment_schedule_ids.split(",") if x.strip().isdigit()]
            if ids:
                clauses.append(f"ps.payment_schedule_id IN ({', '.join(['%s'] * len(ids))})")
                params.extend(ids)
        if filters.customer_id is not None:
            clauses.append("l.customer_id = %s")
            params.append(filters.customer_id)
        for col in ("loan_id", "loan_parent_id", "loan_type", "current_kist_no", "installment_date", "billing_year", "billing_month", "status"):
            val = getattr(filters, col)
            if val is not None:
                clauses.append(f"ps.`{col}` = %s")
                params.append(val.value if isinstance(val, Enum) else val)
        return clauses, params


payment_schedule_dao = PaymentScheduleDAO()
