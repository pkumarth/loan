from datetime import date, datetime
from typing import Any


class OnetimeDAO:
    def fetch_active_page(self, conn, page: int, size: int) -> tuple[list[dict], dict]:
        where = "l.loan_type = 'ONETIME' AND l.loan_status = 'ACTIVE'"
        offset = (page - 1) * size
        with conn.cursor() as cur:
            cur.execute(f"SELECT COUNT(*) AS total FROM loans l WHERE {where}")
            total = cur.fetchone()["total"]
            cur.execute(
                f"""
                SELECT l.loan_id, l.loan_parent_id, l.loan_account_no, l.customer_id, c.customer_name, c.guardian_name,
                       l.rem_principal_amt, l.rate_of_interest, l.borrowing_date, l.modified_borrowing_date
                FROM loans l
                INNER JOIN customers c ON c.customer_id = l.customer_id
                WHERE {where}
                ORDER BY l.loan_id DESC LIMIT %s OFFSET %s
                """,
                (size, offset),
            )
            rows = cur.fetchall()
        total_pages = -(-total // size) if total > 0 else 0
        return rows, {
            "page": page, "size": size, "total_elements": total,
            "total_pages": total_pages, "has_next": page < total_pages,
        }

    def fetch_loan_for_update(self, conn, loan_id: int) -> dict | None:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT l.loan_id, l.loan_parent_id, l.loan_account_no, l.customer_id, l.loan_type, l.loan_status,
                       l.rem_principal_amt, l.rate_of_interest, l.borrowing_date, l.modified_borrowing_date,
                       l.manager_name, l.owner_name,
                       (SELECT c.customer_name FROM customers c WHERE c.customer_id = l.customer_id) AS borrower_name,
                       (SELECT c.guardian_name FROM customers c WHERE c.customer_id = l.customer_id) AS guardian_name
                FROM loans l WHERE l.loan_id = %s FOR UPDATE
                """,
                (loan_id,),
            )
            return cur.fetchone()

    def count_schedule_rows(self, conn, loan_id: int) -> int:
        with conn.cursor() as cur:
            cur.execute("SELECT COUNT(*) AS n FROM payment_schedule WHERE loan_id = %s", (loan_id,))
            return int(cur.fetchone()["n"])

    def insert_settlement_row(self, conn, row: dict[str, Any], actor: str) -> int:
        cols = list(row.keys())
        sql = (
            f"INSERT INTO payment_schedule ({', '.join(cols)}, created_by, updated_by, version) "
            f"VALUES ({', '.join(['%s'] * len(cols))}, %s, %s, 1)"
        )
        with conn.cursor() as cur:
            cur.execute(sql, (*row.values(), actor, actor))
            return cur.lastrowid

    def update_loan_after_settlement(
        self, conn, loan_id: int, rem_principal_amt, settlement_date: date, closed: bool, actor: str
    ) -> None:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE loans
                SET rem_principal_amt = %s, modified_borrowing_date = %s, loan_status = %s,
                    closed_date = %s, updated_by = %s, version = version + 1
                WHERE loan_id = %s
                """,
                (
                    rem_principal_amt, settlement_date, "CLOSED" if closed else "ACTIVE",
                    settlement_date if closed else None, actor, loan_id,
                ),
            )


onetime_dao = OnetimeDAO()


def to_datetime(d: date) -> datetime:
    return datetime(d.year, d.month, d.day)
