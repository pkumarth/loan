from enum import Enum
from typing import Any
from app.dao.base_dao import BaseDAO
from app.domain.customer import CUSTOMER_ALL_COLUMNS, CUSTOMER_MUTABLE_COLUMNS, CustomerFilterParams


class CustomerDAO(BaseDAO):
    table_name = "customers"
    pk_column = "customer_id"
    allowed_columns = CUSTOMER_ALL_COLUMNS
    write_columns = CUSTOMER_MUTABLE_COLUMNS

    def build_filter_query(self, filters: CustomerFilterParams) -> tuple[list[str], list[Any]]:
        clauses, params = [], []
        if filters.customer_ids:
            ids = [int(x.strip()) for x in filters.customer_ids.split(",") if x.strip().isdigit()]
            if ids:
                clauses.append(f"`customer_id` IN ({', '.join(['%s'] * len(ids))})")
                params.extend(ids)
        if filters.customer_name is not None:
            clauses.append("`customer_name` LIKE %s")
            params.append(f"%{filters.customer_name}%")
        for col in ("customer_code", "customer_mobile", "address_id", "guarantor_id", "aadhaar_no", "pan_no", "kyc_status", "customer_status"):
            val = getattr(filters, col)
            if val is not None:
                clauses.append(f"`{col}` = %s")
                params.append(val.value if isinstance(val, Enum) else val)
        return clauses, params


customer_dao = CustomerDAO()
