from datetime import date
from decimal import ROUND_HALF_UP, Decimal
from fastapi import status
from app.core.exceptions import AppException
from app.dao.overdue_dao import overdue_dao
from app.domain.overdue import OverdueComputeRequest

_ZERO = Decimal("0.00")
_WHOLE = Decimal("1")
_FINE_RATE = Decimal("0.01")
_INTEREST_RATE = Decimal("2.5")
_DAILY_DIVISOR = Decimal("3000")


def _money(value) -> Decimal:
    return Decimal(str(value))


def compute_row(row: dict, loan_rem: Decimal, run_date: date) -> dict:
    """Overdue figures for one open EMI / MONTHLY_INTEREST schedule row.

    EMI only: fine (1% of loan principal, applied once) and interest (days x unpaid x 2.5 / 3000) while the
    installment is unpaid after its installment date. MONTHLY_INTEREST gets neither.
    due = installment + fine + other + interest - amount_paid (forgive is already netted in amount_paid).
    """
    installment = _money(row["installment_amount"])
    paid = _money(row["amount_paid"])
    other = _money(row["other_amount"])
    fine = _money(row["fine_amount"])
    interest = _money(row["kist_interest_amount"])
    days = max(0, (run_date - row["installment_date"]).days)
    unpaid = max(_ZERO, installment - paid)

    if row["loan_type"] == "EMI":
        if unpaid > 0 and days > 0:
            if fine == _ZERO:
                fine = (loan_rem * _FINE_RATE).quantize(_WHOLE, rounding=ROUND_HALF_UP)
            interest = (Decimal(days) * unpaid * _INTEREST_RATE / _DAILY_DIVISOR).quantize(_WHOLE, rounding=ROUND_HALF_UP)
        else:
            interest = _ZERO

    due = installment + fine + other + interest - paid
    if due <= _ZERO:
        new_status = "CLOSED"
    elif days > 0:
        new_status = "OVERDUE"
    else:
        new_status = "OPEN"

    return {
        "payment_schedule_id": row["payment_schedule_id"],
        "loan_id": row["loan_id"],
        "loan_type": row["loan_type"],
        "current_kist_no": row["current_kist_no"],
        "installment_date": row["installment_date"],
        "days": days,
        "installment_amount": installment,
        "amount_paid": paid,
        "other_amount": other,
        "fine_amount": fine,
        "kist_interest_amount": interest,
        "due_amount": due,
        "previous_status": row["status"],
        "status": new_status,
    }


class OverdueService:
    def compute(self, conn, req: OverdueComputeRequest, actor: str) -> dict:
        run_date = req.run_date or date.today()
        if req.loan_id is not None and not overdue_dao.loan_exists(conn, req.loan_id):
            raise AppException(status.HTTP_404_NOT_FOUND, f"Loan with ID {req.loan_id} not found", "LOAN_NOT_FOUND")

        items = []
        for row in overdue_dao.fetch_open_rows(conn, req.loan_id):
            res = compute_row(row, _money(row["loan_rem_principal_amt"]), run_date)
            changed = (
                res["fine_amount"] != _money(row["fine_amount"])
                or res["kist_interest_amount"] != _money(row["kist_interest_amount"])
                or res["status"] != row["status"]
            )
            if changed and not req.dry_run:
                overdue_dao.update_row(
                    conn, res["payment_schedule_id"], res["fine_amount"], res["kist_interest_amount"], res["status"], actor
                )
            items.append(res)

        per_loan: dict[int, dict] = {}
        for item in items:
            if item["status"] == "CLOSED":
                continue
            entry = per_loan.setdefault(item["loan_id"], {"loan_id": item["loan_id"], "row_count": 0, "total_due": _ZERO})
            entry["row_count"] += 1
            entry["total_due"] += item["due_amount"]

        return {
            "run_date": run_date,
            "dry_run": req.dry_run,
            "loan_id": req.loan_id,
            "row_count": len(items),
            "total_due": sum((e["total_due"] for e in per_loan.values()), _ZERO),
            "loans": list(per_loan.values()),
            "items": items,
        }


overdue_service = OverdueService()
