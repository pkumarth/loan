import uuid
from datetime import datetime, timezone
from fastapi import status
from app.core.exceptions import AppException
from app.dao.customer_dao import customer_dao
from app.domain.customer import CUSTOMER_ALL_COLUMNS, CustomerCreate, CustomerFilterParams, CustomerSingleFieldPatch, CustomerUpdate
from app.util.projection import resolve_projection


def _gen_customer_code() -> str:
    return f"CUST-{datetime.now(timezone.utc).strftime('%Y%m%d')}-{uuid.uuid4().hex[:6].upper()}"


class CustomerService:
    def create_customer(self, conn, payload: CustomerCreate, actor: str) -> dict:
        data = payload.model_dump()
        data["customer_code"] = payload.customer_code or _gen_customer_code()
        new_id = customer_dao.insert_row(conn, data, actor)
        return customer_dao.fetch_by_id(conn, new_id, list(CUSTOMER_ALL_COLUMNS))

    def get_customer_by_id(self, conn, customer_id: int, include: str | None, exclude: str | None) -> dict:
        cols = resolve_projection(CUSTOMER_ALL_COLUMNS, include=include, exclude=exclude)
        record = customer_dao.fetch_by_id(conn, customer_id, cols)
        if not record:
            raise AppException(status.HTTP_404_NOT_FOUND, f"Customer with ID {customer_id} not found", "CUSTOMER_NOT_FOUND")
        return record

    def list_customers(self, conn, filters: CustomerFilterParams, include: str | None, exclude: str | None, page: int, size: int):
        cols = resolve_projection(CUSTOMER_ALL_COLUMNS, include=include, exclude=exclude)
        where_clauses, params = customer_dao.build_filter_query(filters)
        if filters.has_any_filter() and not where_clauses:
            raise AppException(status.HTTP_400_BAD_REQUEST, "Invalid filter values provided", "INVALID_FILTER_VALUE")
        return customer_dao.fetch_paginated(conn, cols, where_clauses, params, page, size)

    def update_customer(self, conn, customer_id: int, payload: CustomerUpdate, actor: str) -> dict:
        existing = customer_dao.fetch_by_id(conn, customer_id, ["customer_id", "customer_code"])
        if not existing:
            raise AppException(status.HTTP_404_NOT_FOUND, f"Customer with ID {customer_id} not found", "CUSTOMER_NOT_FOUND")
        data = payload.model_dump(exclude={"version"})
        data["customer_code"] = payload.customer_code or existing["customer_code"]
        if customer_dao.update_row(conn, customer_id, data, actor, payload.version) == 0:
            raise AppException(status.HTTP_409_CONFLICT, "Customer update failed due to version mismatch", "OPTIMISTIC_LOCK_CONFLICT")
        return customer_dao.fetch_by_id(conn, customer_id, list(CUSTOMER_ALL_COLUMNS))

    def patch_single_field(self, conn, customer_id: int, payload: CustomerSingleFieldPatch, actor: str) -> tuple[str, dict]:
        if not customer_dao.fetch_by_id(conn, customer_id, ["customer_id"]):
            raise AppException(status.HTTP_404_NOT_FOUND, f"Customer with ID {customer_id} not found", "CUSTOMER_NOT_FOUND")
        field_name = next(iter(payload.model_fields_set - {"version"}))
        if customer_dao.update_single_field(conn, customer_id, field_name, getattr(payload, field_name), actor, payload.version) == 0:
            raise AppException(status.HTTP_409_CONFLICT, "Single-field update failed due to version mismatch", "OPTIMISTIC_LOCK_CONFLICT")
        return field_name, customer_dao.fetch_by_id(conn, customer_id, list(CUSTOMER_ALL_COLUMNS))

    def delete_customer(self, conn, customer_id: int) -> None:
        if customer_dao.delete_by_id(conn, customer_id) == 0:
            raise AppException(status.HTTP_404_NOT_FOUND, f"Customer with ID {customer_id} not found", "CUSTOMER_NOT_FOUND")


customer_service = CustomerService()
