from datetime import date
from decimal import ROUND_HALF_UP, Decimal
from fastapi import status
from app.core.exceptions import AppException
from app.dao.onetime_dao import onetime_dao, to_datetime
from app.dao.payment_schedule_dao import payment_schedule_dao
from app.domain.payment_schedule import SCHEDULE_ALL_COLUMNS
from app.service.payment_schedule_service import _project_row

_DAILY_DIVISOR = Decimal("3000")
_ZERO = Decimal("0.00")
_PER_DAY_QUANT = Decimal("0.01")


def _figures(loan: dict, hisab_date: date) -> dict:
    """Interest = days x principal x rate / 3000 (rate is monthly %), whole rupees, half up."""
    start = loan["modified_borrowing_date"]
    if hisab_date < start:
        raise AppException(
            status.HTTP_400_BAD_REQUEST,
            f"hisab_date {hisab_date} is before modified_borrowing_date {start} for loan {loan['loan_id']}",
            "HISAB_DATE_BEFORE_INTEREST_START",
        )
    days = (hisab_date - start).days
    rem = Decimal(str(loan["rem_principal_amt"]))
    rate = Decimal(str(loan["rate_of_interest"]))
    per_day = rem * rate / _DAILY_DIVISOR
    interest = (Decimal(days) * per_day).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    return {
        "loan_id": loan["loan_id"],
        "hisab_date": hisab_date,
        "modified_borrowing_date": start,
        "days": days,
        "per_day_interest": per_day.quantize(_PER_DAY_QUANT, rounding=ROUND_HALF_UP),
        "rate_of_interest": rate,
        "rem_principal_amt": rem,
        "interest_amount": interest,
        "total_due": rem + interest,
    }


def _load_onetime_loan(conn, loan_id: int, must_be_active: bool = True) -> dict:
    loan = onetime_dao.fetch_loan_for_update(conn, loan_id)
    if not loan:
        raise AppException(status.HTTP_404_NOT_FOUND, f"Loan with ID {loan_id} not found", "LOAN_NOT_FOUND")
    if loan["loan_type"] != "ONETIME":
        raise AppException(status.HTTP_400_BAD_REQUEST, f"Loan {loan_id} is not a ONETIME loan", "NOT_ONETIME_LOAN")
    if must_be_active and loan["loan_status"] != "ACTIVE":
        raise AppException(status.HTTP_400_BAD_REQUEST, f"Loan {loan_id} is {loan['loan_status']}, not ACTIVE", "LOAN_NOT_ACTIVE")
    return loan


class OnetimeService:
    def dry_run_all(self, conn, hisab_date: date | None, page: int, size: int) -> tuple[list[dict], dict, date]:
        hisab = hisab_date or date.today()
        loans, pagination = onetime_dao.fetch_active_page(conn, page, size)
        items = []
        for loan in loans:
            fig = _figures(loan, hisab)
            fig["loan_account_no"] = loan["loan_account_no"]
            fig["customer_id"] = loan["customer_id"]
            fig["customer_name"] = loan["customer_name"]
            fig["guardian_name"] = loan["guardian_name"]
            items.append(fig)
        return items, pagination, hisab

    def dry_run_one(self, conn, loan_id: int, hisab_date: date | None) -> dict:
        hisab = hisab_date or date.today()
        loan = _load_onetime_loan(conn, loan_id)
        fig = _figures(loan, hisab)
        fig["guardian_name"] = loan["guardian_name"]
        fig["next_current_kist_no"] = onetime_dao.count_schedule_rows(conn, loan_id) + 1
        return fig

    def settle(self, conn, payload, actor: str) -> dict:
        hisab = payload.hisab_date or date.today()
        loan = _load_onetime_loan(conn, payload.loan_id)
        fig = _figures(loan, hisab)
        kist_no = onetime_dao.count_schedule_rows(conn, payload.loan_id) + 1

        if payload.dry_run:
            fig["guardian_name"] = loan["guardian_name"]
            fig["next_current_kist_no"] = kist_no
            return {"dry_run": True, **fig}

        interest = fig["interest_amount"]
        rem = fig["rem_principal_amt"]
        forgive = payload.forgive_amount
        amount_paid = payload.manager_received_amount + payload.owner_received_amount - forgive
        if amount_paid < 0:
            raise AppException(
                status.HTTP_400_BAD_REQUEST,
                "amount paid (manager + owner - forgive) cannot be negative",
                "AMOUNT_PAID_NEGATIVE",
            )
        partial = max(_ZERO, amount_paid - interest)
        shortfall = max(_ZERO, interest - amount_paid)
        if partial > rem:
            raise AppException(
                status.HTTP_400_BAD_REQUEST,
                f"partial principal return {partial} exceeds rem_principal_amt {rem}",
                "PARTIAL_EXCEEDS_PRINCIPAL",
            )
        if payment_schedule_dao.exists_for_loan_and_year_month(conn, payload.loan_id, hisab.year, hisab.month):
            raise AppException(
                status.HTTP_409_CONFLICT,
                f"A schedule entry already exists for loan {payload.loan_id} in {hisab.year:04d}-{hisab.month:02d}",
                "DUPLICATE_MONTHLY_SCHEDULE",
            )

        new_rem = rem - partial + shortfall
        closed = new_rem == 0
        row = {
            "loan_id": payload.loan_id,
            "loan_parent_id": loan["loan_parent_id"],
            "loan_type": "ONETIME",
            "current_kist_no": kist_no,
            "installment_date": hisab,
            "installment_amount": interest,
            "fine_amount": _ZERO,
            "other_amount": _ZERO,
            "partial_principal_amt_return": partial,
            "kist_interest_amount": _ZERO,
            "forgive_amount": forgive,
            "manager_name": loan["manager_name"],
            "manager_received_amount": payload.manager_received_amount,
            "owner_name": loan["owner_name"],
            "owner_received_amount": payload.owner_received_amount,
            "payer_name": payload.payer_name or loan["borrower_name"],
            "amount_paid": amount_paid,
            "remaining_principal_amt": new_rem,
            "status": "CLOSED",
            "payment_date": to_datetime(hisab),
        }
        new_id = onetime_dao.insert_settlement_row(conn, row, actor)
        onetime_dao.update_loan_after_settlement(conn, payload.loan_id, new_rem, hisab, closed, actor)

        all_cols = list(SCHEDULE_ALL_COLUMNS)
        schedule = _project_row(payment_schedule_dao.fetch_enriched_by_id(conn, new_id, all_cols), all_cols)
        return {
            "dry_run": False,
            "loan_id": payload.loan_id,
            "guardian_name": loan["guardian_name"],
            "payment_schedule_id": new_id,
            "current_kist_no": kist_no,
            "hisab_date": hisab,
            "days": fig["days"],
            "per_day_interest": fig["per_day_interest"],
            "interest_amount": interest,
            "amount_paid": amount_paid,
            "forgive_amount": forgive,
            "partial_principal_amt_return": partial,
            "shortfall_amount": shortfall,
            "previous_rem_principal_amt": rem,
            "rem_principal_amt": new_rem,
            "modified_borrowing_date": hisab,
            "loan_status": "CLOSED" if closed else "ACTIVE",
            "schedule": schedule,
        }


onetime_service = OnetimeService()
