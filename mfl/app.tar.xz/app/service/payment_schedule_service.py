import re
from datetime import date
from decimal import Decimal, ROUND_HALF_UP
from fastapi import status
from app.core.exceptions import AppException
from app.dao.loan_dao import loan_dao
from app.dao.payment_schedule_dao import payment_schedule_dao
from app.domain.payment_schedule import (
    SCHEDULE_ALL_COLUMNS,
    MonthlyScheduleGenerateRequest,
    ScheduleCreate,
    ScheduleFilterParams,
    ScheduleSingleFieldPatch,
    ScheduleUpdate,
)
from app.util.projection import resolve_projection

AVG_DAYS_PER_MONTH = Decimal("30.4375")


def _calc_kist_no(due_date: date, start_date: date) -> int:
    days_diff = (due_date - start_date).days
    if days_diff <= 0:
        return 0
    return int((Decimal(days_diff) / AVG_DAYS_PER_MONTH).quantize(Decimal("1"), rounding=ROUND_HALF_UP))


def _norm_sched_proj(expr: str | None) -> str | None:
    if not expr:
        return expr
    out = re.sub(r"\bkist_no\b", "current_kist_no", expr)
    out = re.sub(r"\binterest_amount\b", "kist_interest_amount", out)
    return re.sub(r"\bparent_loan_id\b", "loan_parent_id", out)


def _runtime_balance_due(row: dict) -> Decimal:
    return (
        Decimal(str(row.get("installment_amount") or "0.00"))
        + Decimal(str(row.get("fine_amount") or "0.00"))
        + Decimal(str(row.get("other_amount") or "0.00"))
        + Decimal(str(row.get("kist_interest_amount") or "0.00"))
        - Decimal(str(row.get("amount_paid") or "0.00"))
    ).quantize(Decimal("0.01"))


def _project_row(raw: dict, cols: list[str]) -> dict:
    if "balance_due" in cols:
        raw["balance_due"] = _runtime_balance_due(raw)
    return {c: raw.get(c) for c in cols}


class PaymentScheduleService:
    def _resolve_loan(self, conn, loan_id: int) -> dict:
        loan = loan_dao.fetch_by_id(conn, loan_id, ["loan_id", "loan_type", "loan_parent_id", "manager_name", "owner_name"])
        if not loan:
            raise AppException(status.HTTP_400_BAD_REQUEST, f"Referenced loan_id {loan_id} does not exist", "LOAN_NOT_FOUND")
        return loan

    def _check_remaining_principal(self, loan_type: str, val: Decimal) -> None:
        if loan_type == "EMI" and val > Decimal("0.00"):
            raise AppException(
                status.HTTP_400_BAD_REQUEST,
                "remaining_principal_amt is allowed only for MONTHLY_INTEREST or ONETIME loans",
                "INVALID_REMAINING_PRINCIPAL_FOR_EMI",
            )

    def generate_monthly_schedule(self, conn, payload: MonthlyScheduleGenerateRequest, actor: str) -> dict:
        year, month, month_start, _ = payload.month_bounds()
        period_label = f"{year:04d}-{month:02d}"
        candidates = payment_schedule_dao.fetch_candidate_loans_for_billing(conn, year, month, month_start)

        rows_to_insert, preview_items = [], []
        skipped_existing = skipped_completed = skipped_not_due = c12 = c25 = 0

        for loan in candidates:
            if int(loan["month_exists"]) > 0:
                skipped_existing += 1
                continue

            eff_start: date = loan["effective_start_date"]
            in_12_cycle = payload.cycle_12_start_day <= eff_start.day <= payload.cycle_12_cutoff_day
            due_date = date(year, month, 12) if in_12_cycle else date(year, month, 25)
            kist_no = _calc_kist_no(due_date, eff_start)
            if kist_no < 1:
                skipped_not_due += 1
                continue

            existing_kists = {int(k) for k in (loan.get("existing_kist_nos") or "").split(",") if k.strip().isdigit()}
            if loan["loan_type"] == "EMI":
                if int(loan["generated_kists"]) >= int(loan["total_no_of_kist"]) or kist_no > int(loan["total_no_of_kist"]):
                    skipped_completed += 1
                    continue
            if kist_no in existing_kists:
                skipped_existing += 1
                continue

            inst_amt: Decimal = loan["installment_amount"]
            if due_date.day == 12:
                c12 += 1
            else:
                c25 += 1

            rows_to_insert.append((
                loan["loan_id"], loan["loan_parent_id"], loan["loan_type"], kist_no, due_date,
                inst_amt, loan["manager_name"], loan["owner_name"], actor, actor,
            ))

            item = {
                "payment_schedule_id": None, "loan_id": loan["loan_id"], "loan_parent_id": loan["loan_parent_id"],
                "loan_account_no": loan["loan_account_no"], "customer_id": loan["customer_id"],
                "customer_name": loan["customer_name"], "customer_mobile": loan["customer_mobile"],
                "mohalla": loan["mohalla"], "village": loan["village"],
                "guardian_name": loan["guardian_name"], "guarantor_name": loan["guarantor_name"],
                "guarantor_mobile": loan["guarantor_mobile"], "rem_principal_amt": loan["rem_principal_amt"],
                "rate_of_interest": loan["rate_of_interest"], "borrowing_date": loan["borrowing_date"],
                "emi_start_date": eff_start, "emi_first_installment_date": loan["emi_first_installment_date"],
                "emi_last_installment_date": loan["emi_last_installment_date"],
                "loan_type": loan["loan_type"], "total_no_of_kist": loan["total_no_of_kist"],
                "current_kist_no": kist_no, "installment_date": due_date,
                "billing_year": year, "billing_month": month,
                "installment_amount": inst_amt, "fine_amount": Decimal("0.00"), "other_amount": Decimal("0.00"),
                "partial_principal_amt_return": Decimal("0.00"), "kist_interest_amount": Decimal("0.00"),
                "forgive_amount": Decimal("0.00"), "manager_name": loan["manager_name"],
                "manager_received_amount": Decimal("0.00"), "owner_name": loan["owner_name"],
                "owner_received_amount": Decimal("0.00"), "amount_paid": Decimal("0.00"),
                "remaining_principal_amt": Decimal("0.00"), "status": "OPEN", "payment_date": None,
            }
            item["balance_due"] = _runtime_balance_due(item)
            preview_items.append(item)

        inserted = payment_schedule_dao.insert_batch_generated(conn, rows_to_insert) if (not payload.dry_run and rows_to_insert) else 0
        return {
            "billing_period": period_label, "billing_year": year, "billing_month": month,
            "dry_run": payload.dry_run, "cycle_12_start_day": payload.cycle_12_start_day,
            "cycle_12_cutoff_day": payload.cycle_12_cutoff_day,
            "total_active_candidates_scanned": len(candidates),
            "generated_count": len(preview_items) if payload.dry_run else inserted,
            "cycle_12_count": c12, "cycle_25_count": c25,
            "skipped_already_generated": skipped_existing,
            "skipped_kists_completed": skipped_completed,
            "skipped_not_due_yet": skipped_not_due,
            "items": preview_items,
        }

    def create_schedule(self, conn, payload: ScheduleCreate, actor: str) -> dict:
        parent = self._resolve_loan(conn, payload.loan_id)
        self._check_remaining_principal(parent["loan_type"], payload.remaining_principal_amt)
        ty, tm = payload.installment_date.year, payload.installment_date.month
        if payment_schedule_dao.exists_for_loan_and_year_month(conn, payload.loan_id, ty, tm):
            raise AppException(status.HTTP_409_CONFLICT, f"Schedule entry already exists for loan {payload.loan_id} in {ty:04d}-{tm:02d}", "DUPLICATE_MONTHLY_SCHEDULE")

        data = payload.model_dump()
        data["loan_type"] = parent["loan_type"]
        data["loan_parent_id"] = payload.loan_parent_id if payload.loan_parent_id is not None else parent["loan_parent_id"]
        data["manager_name"] = payload.manager_name if payload.manager_name is not None else parent["manager_name"]
        data["owner_name"] = payload.owner_name if payload.owner_name is not None else parent["owner_name"]

        new_id = payment_schedule_dao.insert_row(conn, data, actor)
        all_cols = list(SCHEDULE_ALL_COLUMNS)
        return _project_row(payment_schedule_dao.fetch_enriched_by_id(conn, new_id, all_cols), all_cols)

    def get_schedule_by_id(self, conn, payment_schedule_id: int, include: str | None, exclude: str | None) -> dict:
        cols = resolve_projection(SCHEDULE_ALL_COLUMNS, include=_norm_sched_proj(include), exclude=_norm_sched_proj(exclude))
        raw = payment_schedule_dao.fetch_enriched_by_id(conn, payment_schedule_id, cols)
        if not raw:
            raise AppException(status.HTTP_404_NOT_FOUND, f"Schedule record with ID {payment_schedule_id} not found", "SCHEDULE_NOT_FOUND")
        return _project_row(raw, cols)

    def list_schedules(self, conn, filters: ScheduleFilterParams, include: str | None, exclude: str | None, page: int, size: int):
        cols = resolve_projection(SCHEDULE_ALL_COLUMNS, include=_norm_sched_proj(include), exclude=_norm_sched_proj(exclude))
        where_clauses, params = payment_schedule_dao.build_filter_query(filters)
        if filters.has_any_filter() and not where_clauses:
            raise AppException(status.HTTP_400_BAD_REQUEST, "Invalid filter values provided", "INVALID_FILTER_VALUE")
        raw_rows, pagination = payment_schedule_dao.fetch_enriched_paginated(conn, cols, where_clauses, params, page, size)
        return [_project_row(r, cols) for r in raw_rows], pagination

    def update_schedule(self, conn, payment_schedule_id: int, payload: ScheduleUpdate, actor: str) -> dict:
        if not payment_schedule_dao.fetch_raw_by_id(conn, payment_schedule_id, ["payment_schedule_id"]):
            raise AppException(status.HTTP_404_NOT_FOUND, f"Schedule record with ID {payment_schedule_id} not found", "SCHEDULE_NOT_FOUND")
        parent = self._resolve_loan(conn, payload.loan_id)
        self._check_remaining_principal(parent["loan_type"], payload.remaining_principal_amt)
        ty, tm = payload.installment_date.year, payload.installment_date.month
        if payment_schedule_dao.exists_for_loan_and_year_month(conn, payload.loan_id, ty, tm, exclude_payment_schedule_id=payment_schedule_id):
            raise AppException(status.HTTP_409_CONFLICT, f"Another schedule entry exists for loan {payload.loan_id} in {ty:04d}-{tm:02d}", "DUPLICATE_MONTHLY_SCHEDULE")

        data = payload.model_dump(exclude={"version"})
        data["loan_type"] = parent["loan_type"]
        data["loan_parent_id"] = payload.loan_parent_id if payload.loan_parent_id is not None else parent["loan_parent_id"]
        data["manager_name"] = payload.manager_name if payload.manager_name is not None else parent["manager_name"]
        data["owner_name"] = payload.owner_name if payload.owner_name is not None else parent["owner_name"]

        if payment_schedule_dao.update_row(conn, payment_schedule_id, data, actor, payload.version) == 0:
            raise AppException(status.HTTP_409_CONFLICT, "Schedule update failed due to version mismatch", "OPTIMISTIC_LOCK_CONFLICT")
        all_cols = list(SCHEDULE_ALL_COLUMNS)
        return _project_row(payment_schedule_dao.fetch_enriched_by_id(conn, payment_schedule_id, all_cols), all_cols)

    def patch_single_field(self, conn, payment_schedule_id: int, payload: ScheduleSingleFieldPatch, actor: str) -> tuple[str, dict]:
        existing = payment_schedule_dao.fetch_raw_by_id(
            conn, payment_schedule_id, ["payment_schedule_id", "loan_id", "loan_type", "amount_paid", "forgive_amount", "manager_received_amount", "owner_received_amount"]
        )
        if not existing:
            raise AppException(status.HTTP_404_NOT_FOUND, f"Schedule record with ID {payment_schedule_id} not found", "SCHEDULE_NOT_FOUND")

        field_name = next(iter(payload.model_fields_set - {"version"}))
        field_value = getattr(payload, field_name)

        if field_name == "installment_date":
            if payment_schedule_dao.exists_for_loan_and_year_month(conn, existing["loan_id"], field_value.year, field_value.month, exclude_payment_schedule_id=payment_schedule_id):
                raise AppException(status.HTTP_409_CONFLICT, f"Another entry exists in {field_value.year:04d}-{field_value.month:02d}", "DUPLICATE_MONTHLY_SCHEDULE")

        if field_name == "remaining_principal_amt":
            self._check_remaining_principal(existing["loan_type"], field_value)

        if field_name in ("amount_paid", "forgive_amount", "manager_received_amount", "owner_received_amount"):
            new_paid = field_value if field_name == "amount_paid" else existing["amount_paid"]
            new_forgive = field_value if field_name == "forgive_amount" else existing["forgive_amount"]
            new_mgr = field_value if field_name == "manager_received_amount" else existing["manager_received_amount"]
            new_own = field_value if field_name == "owner_received_amount" else existing["owner_received_amount"]
            if (new_mgr + new_own) != new_paid + new_forgive:
                raise AppException(
                    status.HTTP_400_BAD_REQUEST,
                    f"manager_received_amount ({new_mgr}) + owner_received_amount ({new_own}) must equal amount_paid ({new_paid}) + forgive_amount ({new_forgive})",
                    "RECEIVED_SPLIT_MISMATCH",
                )

        if payment_schedule_dao.update_single_field(conn, payment_schedule_id, field_name, field_value, actor, payload.version) == 0:
            raise AppException(status.HTTP_409_CONFLICT, "Single-field update failed due to version mismatch", "OPTIMISTIC_LOCK_CONFLICT")
        all_cols = list(SCHEDULE_ALL_COLUMNS)
        return field_name, _project_row(payment_schedule_dao.fetch_enriched_by_id(conn, payment_schedule_id, all_cols), all_cols)

    def delete_schedule(self, conn, payment_schedule_id: int) -> None:
        if payment_schedule_dao.delete_by_id(conn, payment_schedule_id) == 0:
            raise AppException(status.HTTP_404_NOT_FOUND, f"Schedule record with ID {payment_schedule_id} not found", "SCHEDULE_NOT_FOUND")


payment_schedule_service = PaymentScheduleService()
