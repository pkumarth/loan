import os
from datetime import date
from decimal import Decimal
from app.core.config import settings
from app.dao.report_dao import report_dao
from app.domain.loan import add_months
from app.domain.overdue import OverdueComputeRequest
from app.domain.report import REPORT_COLUMNS, ReportGenerateRequest
from app.service.overdue_service import overdue_service

_ZERO = Decimal("0.00")


def _open_due(row: dict) -> Decimal:
    return row["installment_amount"] + row["fine_amount"] + row["other_amount"] + row["kist_interest_amount"] - row["amount_paid"]


def _build_report_row(loan: dict, sched: list[dict], overrides: dict, run_date: date, year: int, month: int) -> dict:
    rows = []
    for r in sched:
        r = dict(r)
        ov = overrides.get(r["payment_schedule_id"])
        if ov:
            r["fine_amount"] = ov["fine_amount"]
            r["kist_interest_amount"] = ov["kist_interest_amount"]
            r["status"] = ov["status"]
        rows.append(r)
    rows.sort(key=lambda r: (r["installment_date"], r["current_kist_no"]))

    open_rows = [r for r in rows if r["status"] != "CLOSED"]
    overdue_rows = [r for r in open_rows if r["status"] == "OVERDUE"]
    current = open_rows[0] if open_rows else (rows[-1] if rows else None)

    if overdue_rows:
        report_status = "OVERDUE"
    elif open_rows or not rows:
        report_status = "OPEN"
    else:
        report_status = "CLOSED"

    def open_sum(key: str) -> Decimal:
        return sum((r[key] for r in open_rows), _ZERO)

    return {
        "loan_id": loan["loan_id"],
        "report_billing_year": year,
        "report_billing_month": month,
        "report_run_date": run_date,
        "loan_parent_id": loan["loan_parent_id"],
        "loan_type": loan["loan_type"],
        "report_status": report_status,
        "borrower_name": loan["borrower_name"],
        "guardian_name": loan["guardian_name"],
        "borrower_mobile": loan["borrower_mobile"],
        "guarantor_name": loan["guarantor_name"],
        "guarantor_mobile": loan["guarantor_mobile"],
        "mohalla": loan["mohalla"],
        "village": loan["village"],
        "borrowing_date": loan["borrowing_date"],
        "modified_borrowing_date": loan["modified_borrowing_date"],
        "emi_start_date": loan["emi_start_date"],
        "emi_first_installment_date": loan["emi_first_installment_date"],
        "emi_last_installment_date": loan["emi_last_installment_date"],
        "total_no_of_kist": loan["total_no_of_kist"],
        "manager_name": loan["manager_name"],
        "owner_name": loan["owner_name"],
        "rem_principal_amt": loan["rem_principal_amt"],
        "current_payment_schedule_id": current["payment_schedule_id"] if current else None,
        "current_kist_no": current["current_kist_no"] if current else None,
        "installment_date": current["installment_date"] if current else None,
        "billing_year": current["installment_date"].year if current else None,
        "billing_month": current["installment_date"].month if current else None,
        "installment_amount": current["installment_amount"] if current else None,
        "total_overdue_amount": sum((_open_due(r) for r in open_rows), _ZERO),
        "total_fine_amount": open_sum("fine_amount"),
        "total_interest_amount": open_sum("kist_interest_amount"),
        "total_other_amount": open_sum("other_amount"),
        "total_manager_paid_amount": sum((r["manager_received_amount"] for r in rows), _ZERO),
        "total_owner_paid_amount": sum((r["owner_received_amount"] for r in rows), _ZERO),
        "open_kist_count": len(open_rows),
        "overdue_kist_count": len(overdue_rows),
    }


def _write_tsv(rows: list[dict], year: int, month: int) -> str:
    os.makedirs(settings.REPORT_DIR, exist_ok=True)
    path = os.path.join(settings.REPORT_DIR, f"payment_schedule_report_{month:02d}_{year}.tsv")
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8", newline="") as f:
        f.write("\t".join(REPORT_COLUMNS) + "\n")
        for r in rows:
            f.write("\t".join("" if r[c] is None else str(r[c]).replace("\t", " ").replace("\n", " ") for c in REPORT_COLUMNS) + "\n")
    os.replace(tmp, path)
    return path


class ReportService:
    def generate(self, conn, req: ReportGenerateRequest, actor: str) -> dict:
        today = date.today()
        year = req.billing_year or today.year
        month = req.billing_month or today.month

        # Refresh overdue figures first (dry-run leaves the schedule untouched).
        overdue = overdue_service.compute(conn, OverdueComputeRequest(run_date=today, dry_run=req.dry_run), actor)
        overrides = {item["payment_schedule_id"]: item for item in overdue["items"]}

        loans = report_dao.fetch_scope_loans(conn, add_months(today, -11))
        sched = report_dao.fetch_schedule_rows(conn, [loan["loan_id"] for loan in loans])
        by_loan: dict[int, list[dict]] = {}
        for r in sched:
            by_loan.setdefault(r["loan_id"], []).append(r)

        report_rows = [
            _build_report_row(loan, by_loan.get(loan["loan_id"], []), overrides, today, year, month)
            for loan in loans
        ]

        file_path = None
        if not req.dry_run:
            # Purge + insert share the request transaction; a failed write rolls the purge back.
            report_dao.replace_all(conn, report_rows)
            file_path = _write_tsv(report_rows, year, month)

        status_counts = {"OPEN": 0, "OVERDUE": 0, "CLOSED": 0}
        for r in report_rows:
            status_counts[r["report_status"]] += 1
        return {
            "billing_year": year,
            "billing_month": month,
            "report_run_date": today,
            "dry_run": req.dry_run,
            "row_count": len(report_rows),
            "status_counts": status_counts,
            "total_overdue_amount": sum((r["total_overdue_amount"] for r in report_rows), _ZERO),
            "file_path": file_path,
        }


report_service = ReportService()
