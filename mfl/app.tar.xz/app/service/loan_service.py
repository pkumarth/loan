import uuid
from datetime import datetime, timezone
from decimal import Decimal
from fastapi import status
from app.core.exceptions import AppException
from app.dao.loan_dao import loan_dao
from app.domain.loan import (
    LOAN_ALL_COLUMNS,
    LOAN_PAYLOAD_TO_COLUMN,
    LOAN_PROTECTED_COLUMNS,
    LoanCreate,
    LoanFilterParams,
    LoanSingleFieldPatch,
    LoanUpdate,
)
from app.util.projection import resolve_projection

_K_QUANT = Decimal("0.00001")


def _gen_loan_acc_no() -> str:
    return f"LN-{datetime.now(timezone.utc).strftime('%Y%m%d')}-{uuid.uuid4().hex[:6].upper()}"


def _norm_loan_proj(expr: str | None) -> str | None:
    if not expr:
        return expr
    return expr.replace("monthly_amount", "installment_amount").replace("parent_loan_id", "loan_parent_id")


def _protected_error(field_name: str) -> AppException:
    return AppException(
        status.HTTP_400_BAD_REQUEST,
        f"'{field_name}' cannot be changed after loan creation",
        "LOAN_FIELD_PROTECTED",
    )


class LoanService:
    def create_loan(self, conn, payload: LoanCreate, actor: str) -> dict:
        data = payload.model_dump()
        principal = data.pop("principal_amt")
        data["rem_principal_amt"] = principal
        data["loan_account_no"] = payload.loan_account_no or _gen_loan_acc_no()
        data["original_principal_amt_k"] = (principal / Decimal(1000)).quantize(_K_QUANT)
        data["modified_borrowing_date"] = payload.borrowing_date
        new_id = loan_dao.insert_row(conn, data, actor)
        if payload.loan_parent_id is None:
            loan_dao.set_parent_to_self(conn, new_id)
        return loan_dao.fetch_by_id(conn, new_id, list(LOAN_ALL_COLUMNS))

    def get_loan_by_id(self, conn, loan_id: int, include: str | None, exclude: str | None) -> dict:
        cols = resolve_projection(LOAN_ALL_COLUMNS, include=_norm_loan_proj(include), exclude=_norm_loan_proj(exclude))
        record = loan_dao.fetch_by_id(conn, loan_id, cols)
        if not record:
            raise AppException(status.HTTP_404_NOT_FOUND, f"Loan with ID {loan_id} not found", "LOAN_NOT_FOUND")
        return record

    def list_loans(self, conn, filters: LoanFilterParams, include: str | None, exclude: str | None, page: int, size: int):
        cols = resolve_projection(LOAN_ALL_COLUMNS, include=_norm_loan_proj(include), exclude=_norm_loan_proj(exclude))
        where_clauses, params = loan_dao.build_filter_query(filters)
        if filters.has_any_filter() and not where_clauses:
            raise AppException(status.HTTP_400_BAD_REQUEST, "Invalid filter values provided", "INVALID_FILTER_VALUE")
        return loan_dao.fetch_paginated(conn, cols, where_clauses, params, page, size)

    def update_loan(self, conn, loan_id: int, payload: LoanUpdate, actor: str) -> dict:
        existing = loan_dao.fetch_by_id(conn, loan_id, ["loan_id", "loan_account_no", *LOAN_PROTECTED_COLUMNS])
        if not existing:
            raise AppException(status.HTTP_404_NOT_FOUND, f"Loan with ID {loan_id} not found", "LOAN_NOT_FOUND")
        for payload_name, column in (("principal_amt", "rem_principal_amt"), ("manager_amount", "manager_amount"), ("owner_amount", "owner_amount")):
            if payload_name in payload.model_fields_set and Decimal(str(getattr(payload, payload_name))) != Decimal(str(existing[column])):
                raise _protected_error(payload_name)
        data = payload.model_dump(exclude={"version", "principal_amt"})
        data["loan_account_no"] = payload.loan_account_no or existing["loan_account_no"]
        if loan_dao.update_row(conn, loan_id, data, actor, payload.version) == 0:
            raise AppException(status.HTTP_409_CONFLICT, "Loan update failed due to version mismatch", "OPTIMISTIC_LOCK_CONFLICT")
        return loan_dao.fetch_by_id(conn, loan_id, list(LOAN_ALL_COLUMNS))

    def patch_single_field(self, conn, loan_id: int, payload: LoanSingleFieldPatch, actor: str) -> tuple[str, dict]:
        existing = loan_dao.fetch_by_id(conn, loan_id, ["loan_id"])
        if not existing:
            raise AppException(status.HTTP_404_NOT_FOUND, f"Loan with ID {loan_id} not found", "LOAN_NOT_FOUND")
        payload_name = next(iter(payload.model_fields_set - {"version"}))
        column = LOAN_PAYLOAD_TO_COLUMN.get(payload_name, payload_name)
        if column in LOAN_PROTECTED_COLUMNS:
            raise _protected_error(payload_name)
        field_value = getattr(payload, payload_name)
        if loan_dao.update_single_field(conn, loan_id, column, field_value, actor, payload.version) == 0:
            raise AppException(status.HTTP_409_CONFLICT, "Single-field update failed due to version mismatch", "OPTIMISTIC_LOCK_CONFLICT")
        return payload_name, loan_dao.fetch_by_id(conn, loan_id, list(LOAN_ALL_COLUMNS))

    def delete_loan(self, conn, loan_id: int) -> None:
        if not loan_dao.fetch_by_id(conn, loan_id, ["loan_id"]):
            raise AppException(status.HTTP_404_NOT_FOUND, f"Loan with ID {loan_id} not found", "LOAN_NOT_FOUND")
        loan_dao.clear_self_parent(conn, loan_id)
        if loan_dao.delete_by_id(conn, loan_id) == 0:
            raise AppException(status.HTTP_404_NOT_FOUND, f"Loan with ID {loan_id} not found", "LOAN_NOT_FOUND")


loan_service = LoanService()
