from fastapi import status
from app.core.exceptions import AppException
from app.dao.address_dao import address_dao
from app.domain.address import ADDRESS_ALL_COLUMNS, AddressCreate, AddressFilterParams, AddressSingleFieldPatch, AddressUpdate
from app.util.projection import resolve_projection


class AddressService:
    def create_address(self, conn, payload: AddressCreate, actor: str) -> dict:
        new_id = address_dao.insert_row(conn, payload.model_dump(), actor)
        return address_dao.fetch_by_id(conn, new_id, list(ADDRESS_ALL_COLUMNS))

    def get_address_by_id(self, conn, address_id: int, include: str | None, exclude: str | None) -> dict:
        cols = resolve_projection(ADDRESS_ALL_COLUMNS, include=include, exclude=exclude)
        record = address_dao.fetch_by_id(conn, address_id, cols)
        if not record:
            raise AppException(status.HTTP_404_NOT_FOUND, f"Address with ID {address_id} not found", "ADDRESS_NOT_FOUND")
        return record

    def list_addresses(self, conn, filters: AddressFilterParams, include: str | None, exclude: str | None, page: int, size: int):
        cols = resolve_projection(ADDRESS_ALL_COLUMNS, include=include, exclude=exclude)
        where_clauses, params = address_dao.build_filter_query(filters)
        if filters.has_any_filter() and not where_clauses:
            raise AppException(status.HTTP_400_BAD_REQUEST, "Invalid filter values provided", "INVALID_FILTER_VALUE")
        return address_dao.fetch_paginated(conn, cols, where_clauses, params, page, size)

    def update_address(self, conn, address_id: int, payload: AddressUpdate, actor: str) -> dict:
        if not address_dao.fetch_by_id(conn, address_id, ["address_id"]):
            raise AppException(status.HTTP_404_NOT_FOUND, f"Address with ID {address_id} not found", "ADDRESS_NOT_FOUND")
        data = payload.model_dump(exclude={"version"})
        if address_dao.update_row(conn, address_id, data, actor, payload.version) == 0:
            raise AppException(status.HTTP_409_CONFLICT, "Address update failed due to version mismatch", "OPTIMISTIC_LOCK_CONFLICT")
        return address_dao.fetch_by_id(conn, address_id, list(ADDRESS_ALL_COLUMNS))

    def patch_single_field(self, conn, address_id: int, payload: AddressSingleFieldPatch, actor: str) -> tuple[str, dict]:
        if not address_dao.fetch_by_id(conn, address_id, ["address_id"]):
            raise AppException(status.HTTP_404_NOT_FOUND, f"Address with ID {address_id} not found", "ADDRESS_NOT_FOUND")
        field_name = next(iter(payload.model_fields_set - {"version"}))
        if address_dao.update_single_field(conn, address_id, field_name, getattr(payload, field_name), actor, payload.version) == 0:
            raise AppException(status.HTTP_409_CONFLICT, "Single-field update failed due to version mismatch", "OPTIMISTIC_LOCK_CONFLICT")
        return field_name, address_dao.fetch_by_id(conn, address_id, list(ADDRESS_ALL_COLUMNS))

    def delete_address(self, conn, address_id: int) -> None:
        if address_dao.delete_by_id(conn, address_id) == 0:
            raise AppException(status.HTTP_404_NOT_FOUND, f"Address with ID {address_id} not found", "ADDRESS_NOT_FOUND")


address_service = AddressService()
