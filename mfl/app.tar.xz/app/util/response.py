from decimal import Decimal
from enum import Enum
from typing import Any
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse


class ResponseStatus(str, Enum):
    SUCCESS = "success"
    FAILURE = "failure"
    PARTIAL_SUCCESS = "partial_success"
    PROCESSING = "processing"


def build_response(
    status_code: int,
    display_msg: str,
    cause: str = "success",
    resp_status: ResponseStatus = ResponseStatus.SUCCESS,
    data: Any = None,
    pagination: dict | None = None,
) -> JSONResponse:
    payload: dict[str, Any] = {
        "status": resp_status.value,
        "status_code": status_code,
        "display_msg": display_msg,
        "cause": cause,
    }
    if data is not None:
        payload["data"] = jsonable_encoder(data, custom_encoder={Decimal: float})
    if pagination is not None:
        payload["pagination"] = pagination
    return JSONResponse(status_code=status_code, content=payload)
