from fastapi import status
from app.core.exceptions import AppException

AUDIT_COLUMNS: tuple[str, ...] = (
    "created_at",
    "updated_at",
    "created_by",
    "updated_by",
    "version",
)


def resolve_projection(
    all_columns: tuple[str, ...],
    include: str | None = None,
    exclude: str | None = None,
    audit_columns: tuple[str, ...] = AUDIT_COLUMNS,
) -> list[str]:
    if include and exclude:
        raise AppException(
            status_code=status.HTTP_400_BAD_REQUEST,
            display_msg="Provide either 'include' or 'exclude' in projection, not both",
            cause="INVALID_PROJECTION",
        )

    allowed_set = set(all_columns)
    if include:
        requested = [c.strip() for c in include.split(",") if c.strip()]
        invalid = [c for c in requested if c not in allowed_set]
        if invalid:
            raise AppException(
                status_code=status.HTTP_400_BAD_REQUEST,
                display_msg=f"Invalid include field(s): {', '.join(invalid)}",
                cause="INVALID_PROJECTION_FIELD",
            )
        return list(dict.fromkeys(requested))

    if exclude:
        excluded = {c.strip() for c in exclude.split(",") if c.strip()}
        invalid = [c for c in excluded if c not in allowed_set]
        if invalid:
            raise AppException(
                status_code=status.HTTP_400_BAD_REQUEST,
                display_msg=f"Invalid exclude field(s): {', '.join(invalid)}",
                cause="INVALID_PROJECTION_FIELD",
            )
        cols = [c for c in all_columns if c not in excluded]
        if not cols:
            raise AppException(
                status_code=status.HTTP_400_BAD_REQUEST,
                display_msg="Exclusion left zero columns to retrieve",
                cause="EMPTY_PROJECTION",
            )
        return cols

    return [c for c in all_columns if c not in audit_columns]
