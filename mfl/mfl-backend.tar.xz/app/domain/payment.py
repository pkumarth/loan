from datetime import date
from decimal import Decimal
from enum import Enum
from typing import Optional

from pydantic import Field, model_validator

from app.domain.common import CleanBaseModel


class PaymentModeEnum(str, Enum):
    CASH = "CASH"
    UPI = "UPI"
    BANK_TRANSFER = "BANK_TRANSFER"
    CHEQUE = "CHEQUE"


class PaymentStatusEnum(str, Enum):
    SUCCESS = "SUCCESS"
    REVERSED = "REVERSED"
    BOUNCED = "BOUNCED"


PAYMENT_ALL_COLUMNS: tuple[str, ...] = (
    "payment_id", "receipt_no", "idempotency_key", "payment_schedule_id", "loan_id", "customer_id",
    "current_kist_no", "installment_date", "payment_amount", "payment_amt_k",
    "manager_received_amount", "owner_received_amount", "payer_name", "payment_date",
    "payment_mode", "transaction_ref", "payment_status", "remarks",
    "created_at", "updated_at", "created_by", "updated_by", "version",
)

# Immutable ledger: only these columns may be written, and only status/remarks change after insert.
PAYMENT_WRITE_COLUMNS: tuple[str, ...] = (
    "receipt_no", "idempotency_key", "payment_schedule_id", "loan_id", "customer_id", "current_kist_no",
    "installment_date", "payment_amount", "manager_received_amount", "owner_received_amount", "payer_name",
    "payment_date", "payment_mode", "transaction_ref", "payment_status", "remarks",
)


class LoanCollectRequest(CleanBaseModel):
    """Collect one amount against a loan; it is spread over the loan's open installments, last to first."""

    idempotency_key: str = Field(..., min_length=8, max_length=50, pattern=r"^[A-Za-z0-9_-]+$")
    manager_received_amount: Decimal = Field(default=Decimal("0.00"), ge=0)
    owner_received_amount: Decimal = Field(default=Decimal("0.00"), ge=0)
    payment_mode: PaymentModeEnum = PaymentModeEnum.CASH
    transaction_ref: Optional[str] = Field(default=None, max_length=100)
    payer_name: Optional[str] = Field(default=None, max_length=120)
    remarks: Optional[str] = Field(default=None, max_length=255)

    @model_validator(mode="after")
    def _amount_positive(self):
        if self.manager_received_amount + self.owner_received_amount <= 0:
            raise ValueError("Collected amount must be greater than 0")
        return self


class PaymentCreate(CleanBaseModel):
    """Collect against one installment. Amount = manager_received + owner_received (split invariant)."""

    idempotency_key: str = Field(..., min_length=8, max_length=64)
    payment_schedule_id: int = Field(..., gt=0)
    manager_received_amount: Decimal = Field(default=Decimal("0.00"), ge=0)
    owner_received_amount: Decimal = Field(default=Decimal("0.00"), ge=0)
    payment_mode: PaymentModeEnum = PaymentModeEnum.CASH
    transaction_ref: Optional[str] = Field(default=None, max_length=100)
    payer_name: Optional[str] = Field(default=None, max_length=120)
    remarks: Optional[str] = Field(default=None, max_length=255)

    @model_validator(mode="after")
    def _amount_positive(self):
        if self.manager_received_amount + self.owner_received_amount <= 0:
            raise ValueError("Collected amount must be greater than 0")
        return self


class PaymentPatch(CleanBaseModel):
    """Only status (SUCCESS -> REVERSED/BOUNCED) and remarks are mutable."""

    payment_status: Optional[PaymentStatusEnum] = None
    remarks: Optional[str] = Field(default=None, max_length=255)
    version: Optional[int] = Field(default=None, ge=1)

    @model_validator(mode="after")
    def _something_to_change(self):
        if self.payment_status is None and self.remarks is None:
            raise ValueError("Provide payment_status or remarks")
        return self


class PaymentFilterParams(CleanBaseModel):
    payment_ids: Optional[str] = None
    loan_id: Optional[int] = None
    customer_id: Optional[int] = None
    payment_schedule_id: Optional[int] = None
    payment_status: Optional[PaymentStatusEnum] = None
    payment_mode: Optional[PaymentModeEnum] = None
    payment_date: Optional[date] = None

    def has_any_filter(self) -> bool:
        return any(v is not None for v in self.model_dump().values())
