"""Test-only SQLite backend (selected with DB_BACKEND=sqlite).

Builds an in-memory SQLite database from schema.sql at startup, so there is no second schema to maintain.
Production remains MySQL. Known differences: money is stored as SQLite NUMERIC, updated_at is not auto-refreshed,
and all requests share one connection (serialised by a lock), so the MySQL commit-after-response race cannot occur.
"""
import re
import sqlite3
import threading
from datetime import date, datetime
from decimal import Decimal

sqlite3.register_adapter(Decimal, str)
sqlite3.register_adapter(date, lambda d: d.isoformat())
sqlite3.register_adapter(datetime, lambda d: d.isoformat(" "))
sqlite3.register_converter("DECIMAL", lambda b: Decimal(b.decode()))
sqlite3.register_converter("DATE", lambda b: date.fromisoformat(b.decode()))
sqlite3.register_converter("DATETIME", lambda b: datetime.fromisoformat(b.decode()))


def _enum_to_check(match: re.Match) -> str:
    col, values = match.group(1), match.group(2)
    return f"{col} TEXT CHECK ({col} IN ({values}))"


def build_sqlite_schema(mysql_sql: str) -> str:
    """Convert the MySQL DDL in schema.sql to SQLite DDL."""
    text = re.sub(r"--[^\n]*", "", mysql_sql)
    statements, extra_indexes = [], []
    for raw in text.split(";"):
        stmt = raw.strip()
        if not stmt:
            continue
        upper = stmt.upper()
        if upper.startswith(("CREATE DATABASE", "USE ", "DROP TABLE")):
            continue
        if upper.startswith("CREATE TABLE"):
            table = re.match(r"CREATE TABLE (\w+)", stmt).group(1)
            stmt = re.sub(r"\)\s*ENGINE=.*$", ")", stmt, flags=re.S)
            stmt = re.sub(r",\s*INDEX (\w+) \(([^)]*)\)", lambda m: _collect_index(m, table, extra_indexes), stmt)
            stmt = re.sub(r"UNIQUE KEY \w+ \(", "UNIQUE (", stmt)
            stmt = re.sub(r"\b(?:BIG|SMALL|TINY|MEDIUM)?INT(?:EGER)? UNSIGNED AUTO_INCREMENT PRIMARY KEY\b",
                          "INTEGER PRIMARY KEY AUTOINCREMENT", stmt)
            stmt = re.sub(r"\b(?:BIG|SMALL|TINY|MEDIUM)?INT UNSIGNED\b", "INTEGER", stmt)
            stmt = re.sub(r"(\w+)\s+ENUM\(([^)]*)\)", _enum_to_check, stmt)
            stmt = re.sub(r"\s+COLLATE \w+", "", stmt)
            stmt = re.sub(r"\s+ON UPDATE CURRENT_TIMESTAMP", "", stmt)
            stmt = re.sub(r"YEAR\((\w+)\)", r"CAST(strftime('%Y', \1) AS INTEGER)", stmt)
            stmt = re.sub(r"MONTH\((\w+)\)", r"CAST(strftime('%m', \1) AS INTEGER)", stmt)
        statements.append(stmt + ";")
    return "\n".join(statements + extra_indexes)


def _collect_index(match: re.Match, table: str, sink: list[str]) -> str:
    sink.append(f"CREATE INDEX {match.group(1)} ON {table} ({match.group(2)});")
    return ""


class _Cursor:
    def __init__(self, cur):
        self._cur = cur

    @staticmethod
    def _sql(sql: str) -> str:
        return sql.replace("%s", "?").replace(" FOR UPDATE", "")

    def _dict(self, row):
        if row is None:
            return None
        return dict(zip([d[0] for d in self._cur.description], row))

    def execute(self, sql, params=None):
        self._cur.execute(self._sql(sql), tuple(params) if params else ())
        return self._cur.rowcount

    def executemany(self, sql, seq):
        self._cur.executemany(self._sql(sql), seq)
        return self._cur.rowcount

    def fetchone(self):
        return self._dict(self._cur.fetchone())

    def fetchall(self):
        return [self._dict(r) for r in self._cur.fetchall()]

    @property
    def rowcount(self):
        return self._cur.rowcount

    @property
    def lastrowid(self):
        return self._cur.lastrowid

    def close(self):
        self._cur.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False


class _Connection:
    def __init__(self, raw, lock):
        self._raw = raw
        self._lock = lock
        self._released = False

    def cursor(self):
        return _Cursor(self._raw.cursor())

    def commit(self):
        self._raw.commit()

    def rollback(self):
        self._raw.rollback()

    def close(self):
        # The pool hands out the same connection; closing only releases the request lock.
        if not self._released:
            self._released = True
            self._lock.release()


class SqlitePool:
    def __init__(self, schema_sql: str):
        self._raw = sqlite3.connect(":memory:", check_same_thread=False, detect_types=sqlite3.PARSE_DECLTYPES)
        self._raw.execute("PRAGMA foreign_keys = ON")
        self._raw.executescript(build_sqlite_schema(schema_sql))
        self._raw.commit()
        self._lock = threading.Lock()

    def connection(self) -> _Connection:
        self._lock.acquire()
        return _Connection(self._raw, self._lock)
