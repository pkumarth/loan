import pymysql
from pymysql.cursors import DictCursor
from dbutils.pooled_db import PooledDB
from fastapi import Header, Request
from fastapi.routing import APIRoute
from app.core.config import settings

if settings.DB_BACKEND == "sqlite":
    from app.core.sqlite_backend import SqlitePool

    with open(settings.SCHEMA_FILE, encoding="utf-8") as _f:
        _pool = SqlitePool(_f.read())
else:
  _pool = PooledDB(
    creator=pymysql,
    maxconnections=settings.DB_POOL_MAX,
    mincached=2,
    maxcached=5,
    blocking=True,
    ping=1,
    host=settings.DB_HOST,
    user=settings.DB_USER,
    password=settings.DB_PASSWORD,
    database=settings.DB_NAME,
    port=settings.DB_PORT,
    charset="utf8mb4",
    cursorclass=DictCursor,
    autocommit=False,
    connect_timeout=5,
)


def get_db(request: Request):
    conn = _pool.connection()
    request.state.db_conn = conn
    try:
        yield conn
    finally:
        conn.close()


class TransactionalRoute(APIRoute):
    """Commits (or rolls back) the request's connection inside the route handler.

    Commits in a yield-dependency's teardown run after the response is sent, so a client that
    immediately reads back what it just created could miss it. Committing here makes the write
    visible before the response leaves the server.
    """

    def get_route_handler(self):
        handler = super().get_route_handler()

        async def transactional_handler(request: Request):
            try:
                response = await handler(request)
            except Exception:
                conn = getattr(request.state, "db_conn", None)
                if conn is not None:
                    conn.rollback()
                raise
            conn = getattr(request.state, "db_conn", None)
            if conn is not None:
                conn.commit()
            return response

        return transactional_handler


def get_actor(x_user_id: str | None = Header(default=None, alias="X-User-Id")) -> str:
    return (x_user_id or "SYSTEM").strip() or "SYSTEM"
