import uuid
from datetime import datetime
from decimal import Decimal

from fastapi import status

from app.core.exceptions import AppException
from app.dao.payment_dao import payment_dao
from app.domain.payment import PAYMENT_ALL_COLUMNS, LoanCollectRequest, PaymentCreate, PaymentFilterParams, PaymentPatch, PaymentStatusEnum
from app.service.payment_schedule_service import _runtime_balance_due
from app.service.report_service import report_service
from app.util.projection import resolve_projection


def _d(value) -> Decimal:
    return Decimal(str(value if value is not None else "0.00"))


class PaymentService:
    def collect(self, conn, payload: PaymentCreate, actor: str) -> tuple[dict, bool]:
        """Records a receipt and applies it to the installment. Returns (record, created).

        Replaying the same idempotency_key returns the original receipt and changes nothing.
        """
        existing = payment_dao.fetch_by_idempotency_key(conn, payload.idempotency_key)
        if existing:
            return payment_dao.fetch_by_id(conn, existing["payment_id"], list(PAYMENT_ALL_COLUMNS)), False

        sched = payment_dao.lock_schedule(conn, payload.payment_schedule_id)
        if not sched:
            raise AppException(status.HTTP_404_NOT_FOUND, f"Schedule record with ID {payload.payment_schedule_id} not found", "SCHEDULE_NOT_FOUND")
        if sched["loan_status"] != "ACTIVE":
            raise AppException(status.HTTP_400_BAD_REQUEST, "Loan is not ACTIVE; collection not allowed", "LOAN_NOT_ACTIVE")
        if sched["status"] in ("CLOSED", "WAIVED"):
            raise AppException(status.HTTP_400_BAD_REQUEST, "Installment is already settled", "INSTALLMENT_ALREADY_SETTLED")

        m = _d(payload.manager_received_amount)
        o = _d(payload.owner_received_amount)
        amount = m + o
        balance = _runtime_balance_due(sched)
        if amount > balance:
            raise AppException(
                status.HTTP_400_BAD_REQUEST,
                f"Collected amount {amount} exceeds balance due {balance}",
                "OVERPAYMENT",
            )

        now = datetime.now().replace(microsecond=0)
        new_balance = balance - amount
        payment_dao.update_schedule_collection(
            conn, sched["payment_schedule_id"],
            {
                "amount_paid": _d(sched["amount_paid"]) + amount,
                "manager_received_amount": _d(sched["manager_received_amount"]) + m,
                "owner_received_amount": _d(sched["owner_received_amount"]) + o,
                "payer_name": payload.payer_name,
                "payment_date": now,
                "status": "CLOSED" if new_balance <= 0 else "PARTIAL",
            },
            actor,
        )

        new_id = payment_dao.insert_row(
            conn,
            {
                "receipt_no": f"RCP-{now:%Y%m%d}-{uuid.uuid4().hex[:6].upper()}",
                "idempotency_key": payload.idempotency_key,
                "payment_schedule_id": sched["payment_schedule_id"],
                "loan_id": sched["loan_id"],
                "customer_id": sched["customer_id"],
                "current_kist_no": sched["current_kist_no"],
                "installment_date": sched["installment_date"],
                "payment_amount": amount,
                "manager_received_amount": m,
                "owner_received_amount": o,
                "payer_name": payload.payer_name,
                "payment_date": now,
                "payment_mode": payload.payment_mode,
                "transaction_ref": payload.transaction_ref,
                "payment_status": PaymentStatusEnum.SUCCESS,
                "remarks": payload.remarks,
            },
            actor,
        )
        return payment_dao.fetch_by_id(conn, new_id, list(PAYMENT_ALL_COLUMNS)), True

    def collect_for_loan(self, conn, loan_id: int, payload: LoanCollectRequest, actor: str) -> tuple[dict, bool]:
        """Spreads one collection over the loan's open installments, starting from the last one and moving back.

        Each installment gets min(remaining amount, its balance). Writes one receipt per installment touched,
        updates each installment, and rebuilds the loan's payment_schedule_report row. Returns (result, created).
        """
        loan = payment_dao.lock_loan(conn, loan_id)
        if not loan:
            raise AppException(status.HTTP_404_NOT_FOUND, f"Loan with ID {loan_id} not found", "LOAN_NOT_FOUND")

        prior = payment_dao.find_loan_collection_receipts(conn, payload.idempotency_key)
        if prior:
            if any(p["loan_id"] != loan_id for p in prior):
                raise AppException(status.HTTP_409_CONFLICT, "Idempotency key already used for another loan", "IDEMPOTENCY_KEY_REUSED")
            return self._loan_collection_result(conn, loan_id, [p["payment_id"] for p in prior]), False

        if loan["loan_status"] != "ACTIVE":
            raise AppException(status.HTTP_400_BAD_REQUEST, "Loan is not ACTIVE; collection not allowed", "LOAN_NOT_ACTIVE")

        scheds = payment_dao.lock_loan_schedules(conn, loan_id)
        open_rows = [s for s in scheds if s["status"] not in ("CLOSED", "WAIVED") and _runtime_balance_due(s) > 0]
        open_rows.sort(key=lambda s: (s["installment_date"], s["current_kist_no"]), reverse=True)

        m, o = _d(payload.manager_received_amount), _d(payload.owner_received_amount)
        amount = m + o
        total_due = sum((_runtime_balance_due(s) for s in open_rows), Decimal("0.00"))
        if amount > total_due:
            raise AppException(
                status.HTTP_400_BAD_REQUEST,
                f"Collected amount {amount} exceeds total due {total_due} for loan {loan_id}",
                "OVERPAYMENT",
            )

        now = datetime.now().replace(microsecond=0)
        rem_amount, rem_manager = amount, m
        receipt_ids: list[int] = []
        for s in open_rows:
            if rem_amount <= 0:
                break
            balance = _runtime_balance_due(s)
            applied = min(rem_amount, balance)
            mgr_part = min(rem_manager, applied)
            own_part = applied - mgr_part
            rem_amount -= applied
            rem_manager -= mgr_part
            payment_dao.update_schedule_collection(
                conn, s["payment_schedule_id"],
                {
                    "amount_paid": _d(s["amount_paid"]) + applied,
                    "manager_received_amount": _d(s["manager_received_amount"]) + mgr_part,
                    "owner_received_amount": _d(s["owner_received_amount"]) + own_part,
                    "payer_name": payload.payer_name,
                    "payment_date": now,
                    "status": "CLOSED" if balance - applied <= 0 else "PARTIAL",
                },
                actor,
            )
            receipt_ids.append(payment_dao.insert_row(
                conn,
                {
                    "receipt_no": f"RCP-{now:%Y%m%d}-{uuid.uuid4().hex[:6].upper()}",
                    "idempotency_key": f"{payload.idempotency_key}:{s['payment_schedule_id']}",
                    "payment_schedule_id": s["payment_schedule_id"],
                    "loan_id": loan_id,
                    "customer_id": s["customer_id"],
                    "current_kist_no": s["current_kist_no"],
                    "installment_date": s["installment_date"],
                    "payment_amount": applied,
                    "manager_received_amount": mgr_part,
                    "owner_received_amount": own_part,
                    "payer_name": payload.payer_name,
                    "payment_date": now,
                    "payment_mode": payload.payment_mode,
                    "transaction_ref": payload.transaction_ref,
                    "payment_status": PaymentStatusEnum.SUCCESS,
                    "remarks": payload.remarks,
                },
                actor,
            ))

        report_service.refresh_loan(conn, loan_id)
        return self._loan_collection_result(conn, loan_id, receipt_ids), True

    def _loan_collection_result(self, conn, loan_id: int, payment_ids: list[int]) -> dict:
        receipts = [payment_dao.fetch_by_id(conn, pid, list(PAYMENT_ALL_COLUMNS)) for pid in payment_ids]
        return {
            "loan_id": loan_id,
            "total_collected": sum((_d(r["payment_amount"]) for r in receipts), Decimal("0.00")),
            "manager_received_amount": sum((_d(r["manager_received_amount"]) for r in receipts), Decimal("0.00")),
            "owner_received_amount": sum((_d(r["owner_received_amount"]) for r in receipts), Decimal("0.00")),
            "installments_touched": len(receipts),
            "receipts": receipts,
        }

    def list_payments(self, conn, filters: PaymentFilterParams, page: int, size: int):
        clauses, params = payment_dao.build_filter_query(filters)
        if filters.has_any_filter() and not clauses:
            raise AppException(status.HTTP_400_BAD_REQUEST, "Invalid filter values provided", "INVALID_FILTER_VALUE")
        return payment_dao.list_joined(conn, clauses, params, page, size)

    def get_payment(self, conn, payment_id: int, include: str | None, exclude: str | None) -> dict:
        cols = resolve_projection(PAYMENT_ALL_COLUMNS, include=include, exclude=exclude)
        record = payment_dao.fetch_by_id(conn, payment_id, cols)
        if not record:
            raise AppException(status.HTTP_404_NOT_FOUND, f"Payment with ID {payment_id} not found", "PAYMENT_NOT_FOUND")
        return record

    def patch_payment(self, conn, payment_id: int, payload: PaymentPatch, actor: str) -> dict:
        row = payment_dao.lock_by_id(conn, payment_id)
        if not row:
            raise AppException(status.HTTP_404_NOT_FOUND, f"Payment with ID {payment_id} not found", "PAYMENT_NOT_FOUND")
        if payload.version is not None and payload.version != row["version"]:
            raise AppException(status.HTTP_409_CONFLICT, "Payment update failed due to version mismatch", "OPTIMISTIC_LOCK_CONFLICT")

        if payload.payment_status is not None:
            if payload.payment_status == PaymentStatusEnum.SUCCESS:
                raise AppException(status.HTTP_400_BAD_REQUEST, "Record a new collection instead of re-marking SUCCESS", "INVALID_STATUS_CHANGE")
            if row["payment_status"] != PaymentStatusEnum.SUCCESS.value:
                raise AppException(status.HTTP_400_BAD_REQUEST, f"Receipt is already {row['payment_status']}", "INVALID_STATUS_CHANGE")
            self._reverse_on_schedule(conn, row, actor)
            if payment_dao.update_single_field(conn, payment_id, "payment_status", payload.payment_status, actor, row["version"]) == 0:
                raise AppException(status.HTTP_409_CONFLICT, "Payment update failed due to version mismatch", "OPTIMISTIC_LOCK_CONFLICT")

        if payload.remarks is not None:
            version = row["version"] + (1 if payload.payment_status is not None else 0)
            if payment_dao.update_single_field(conn, payment_id, "remarks", payload.remarks, actor, version) == 0:
                raise AppException(status.HTTP_409_CONFLICT, "Payment update failed due to version mismatch", "OPTIMISTIC_LOCK_CONFLICT")

        return payment_dao.fetch_by_id(conn, payment_id, list(PAYMENT_ALL_COLUMNS))

    def _reverse_on_schedule(self, conn, row: dict, actor: str) -> None:
        """Takes the receipt's amounts back off the installment and recomputes its status."""
        sched = payment_dao.lock_schedule(conn, row["payment_schedule_id"])
        if not sched:
            raise AppException(status.HTTP_404_NOT_FOUND, "Linked schedule record not found", "SCHEDULE_NOT_FOUND")
        amount = _d(row["payment_amount"])
        new_paid = _d(sched["amount_paid"]) - amount
        if new_paid < 0:
            raise AppException(status.HTTP_409_CONFLICT, "Installment totals no longer match this receipt", "LEDGER_MISMATCH")
        new_balance = _runtime_balance_due({**sched, "amount_paid": new_paid})
        if new_balance <= 0:
            new_status = "CLOSED"
        elif new_paid > 0:
            new_status = "PARTIAL"
        else:
            new_status = "OPEN"
        payment_dao.update_schedule_collection(
            conn, sched["payment_schedule_id"],
            {
                "amount_paid": new_paid,
                "manager_received_amount": _d(sched["manager_received_amount"]) - _d(row["manager_received_amount"]),
                "owner_received_amount": _d(sched["owner_received_amount"]) - _d(row["owner_received_amount"]),
                "payer_name": None,
                "payment_date": sched["payment_date"],
                "status": new_status,
            },
            actor,
        )


payment_service = PaymentService()
