from datetime import date, datetime, timedelta
from decimal import Decimal

from app.domain.payment import PaymentStatusEnum

ZERO = Decimal("0.00")


def _d(value) -> Decimal:
    return Decimal(str(value if value is not None else "0")).quantize(Decimal("0.01"))


def _month_bounds(year: int, month: int) -> tuple[date, date]:
    start = date(year, month, 1)
    end = date(year + (month == 12), (month % 12) + 1, 1)
    return start, end


def _iso(value) -> str:
    return value.isoformat() if hasattr(value, "isoformat") else str(value)


def _cycle_for(day: int) -> str:
    """Collection cycle per the spec: days 8-20 => 12th cycle, otherwise 25th."""
    return "12th" if 8 <= day <= 20 else "25th"


class DashboardService:
    def summary(self, conn, billing_year: int | None, billing_month: int | None, today: date | None = None) -> dict:
        today = today or date.today()
        year = billing_year or today.year
        month = billing_month or today.month
        m_start, m_end = _month_bounds(year, month)
        t_start = datetime.combine(today, datetime.min.time())
        t_end = t_start + timedelta(days=1)
        mtd_start = datetime.combine(m_start, datetime.min.time())
        mtd_end = datetime.combine(m_end, datetime.min.time())

        with conn.cursor() as cur:
            cur.execute(
                "SELECT loan_type, loan_status, COUNT(*) AS n, COALESCE(SUM(rem_principal_amt),0) AS rem, "
                "COALESCE(SUM(original_principal_amt_k),0) AS orig_k, COALESCE(SUM(owner_amount),0) AS owner_amt, "
                "COALESCE(SUM(manager_amount),0) AS mgr_amt, COALESCE(SUM(processing_fee),0) AS fees "
                "FROM loans GROUP BY loan_type, loan_status"
            )
            loan_rows = cur.fetchall()

            cur.execute(
                "SELECT COUNT(*) AS n, COALESCE(SUM(payment_amount),0) AS total, "
                "COALESCE(SUM(manager_received_amount),0) AS mgr, COALESCE(SUM(owner_received_amount),0) AS own, "
                "COALESCE(SUM(CASE WHEN payment_mode='CASH' THEN payment_amount ELSE 0 END),0) AS cash, "
                "COALESCE(SUM(CASE WHEN payment_mode='UPI' THEN payment_amount ELSE 0 END),0) AS upi "
                "FROM payments WHERE payment_status = %s AND payment_date >= %s AND payment_date < %s",
                (PaymentStatusEnum.SUCCESS.value, mtd_start, mtd_end),
            )
            mtd = cur.fetchone()

            cur.execute(
                "SELECT installment_date, installment_amount, fine_amount, other_amount, kist_interest_amount, "
                "amount_paid, forgive_amount, status FROM payment_schedule "
                "WHERE installment_date >= %s AND installment_date < %s",
                (m_start, m_end),
            )
            month_rows = cur.fetchall()

            cur.execute(
                "SELECT COUNT(*) AS n, COUNT(DISTINCT loan_id) AS loans, "
                "COALESCE(SUM(installment_amount + fine_amount + other_amount + kist_interest_amount - amount_paid),0) AS due, "
                "COALESCE(SUM(fine_amount + kist_interest_amount),0) AS charges, "
                "COALESCE(SUM(forgive_amount),0) AS forgiven "
                "FROM payment_schedule WHERE status IN ('OVERDUE','PARTIAL')"
            )
            risk = cur.fetchone()

            cur.execute(
                "SELECT COALESCE(SUM(forgive_amount),0) AS forgiven FROM payment_schedule"
            )
            forgiven_all = cur.fetchone()

            cur.execute(
                "SELECT COUNT(*) AS total, "
                "SUM(CASE WHEN customer_status = 'BLACKLISTED' THEN 1 ELSE 0 END) AS blacklisted, "
                "SUM(CASE WHEN kyc_status <> 'VERIFIED' THEN 1 ELSE 0 END) AS kyc_pending, "
                "COUNT(DISTINCT guarantor_id) AS guarantors "
                "FROM customers"
            )
            cust = cur.fetchone()

            cur.execute("SELECT COUNT(DISTINCT customer_id) AS n FROM loans WHERE loan_status = 'ACTIVE'")
            active_borrowers = cur.fetchone()["n"]

            cur.execute(
                "SELECT a.village, COUNT(DISTINCT l.loan_id) AS loans, "
                "COALESCE(SUM(ps.installment_amount + ps.fine_amount + ps.other_amount + ps.kist_interest_amount - ps.amount_paid),0) AS due "
                "FROM payment_schedule ps "
                "JOIN loans l ON l.loan_id = ps.loan_id "
                "JOIN customers c ON c.customer_id = l.customer_id "
                "JOIN addresses a ON a.address_id = c.address_id "
                "WHERE ps.status IN ('OPEN','PARTIAL','OVERDUE') "
                "GROUP BY a.village ORDER BY due DESC LIMIT 5"
            )
            villages = cur.fetchall()

            cur.execute(
                "SELECT p.receipt_no, p.payment_amount, p.payment_mode, p.current_kist_no, p.loan_id, "
                "p.payment_date, c.customer_name, p.payment_status "
                "FROM payments p JOIN customers c ON c.customer_id = p.customer_id "
                "WHERE p.payment_date >= %s AND p.payment_date < %s "
                "ORDER BY p.payment_id DESC LIMIT 5",
                (t_start, t_end),
            )
            todays_receipts = cur.fetchall()

            cur.execute(
                "SELECT COUNT(*) AS n FROM payment_schedule WHERE billing_year = %s AND billing_month = %s",
                (year, month),
            )
            generated_count = cur.fetchone()["n"]

        # Portfolio & capital (loan header aggregates)
        mix = {"EMI": 0, "MONTHLY_INTEREST": 0, "ONETIME": 0}
        active_count = closed_count = 0
        active_aum = disbursed = owner_dep = mgr_dep = fees = ZERO
        for r in loan_rows:
            disbursed += _d(r["orig_k"]) * 1000
            owner_dep += _d(r["owner_amt"])
            mgr_dep += _d(r["mgr_amt"])
            fees += _d(r["fees"])
            if r["loan_status"] == "ACTIVE":
                active_count += r["n"]
                active_aum += _d(r["rem"])
                mix[r["loan_type"]] = mix.get(r["loan_type"], 0) + r["n"]
            elif r["loan_status"] == "CLOSED":
                closed_count += r["n"]

        # 12th / 25th cycle funnel for the billing month (cycle from installment day)
        cycles = {"12th": {"expected": ZERO, "collected": ZERO, "pending": ZERO, "open_kists": 0},
                  "25th": {"expected": ZERO, "collected": ZERO, "pending": ZERO, "open_kists": 0}}
        for r in month_rows:
            key = _cycle_for(r["installment_date"].day)
            expected = _d(r["installment_amount"]) + _d(r["fine_amount"]) + _d(r["other_amount"]) + _d(r["kist_interest_amount"])
            paid = _d(r["amount_paid"])
            balance = expected - paid
            cycles[key]["expected"] += expected
            cycles[key]["collected"] += paid
            if balance > 0:
                cycles[key]["pending"] += balance
                cycles[key]["open_kists"] += 1
        for key, c in cycles.items():
            c["efficiency_pct"] = float(round(c["collected"] / c["expected"] * 100, 1)) if c["expected"] > 0 else 0.0
            c["expected"], c["collected"], c["pending"] = (float(c["expected"]), float(c["collected"]), float(c["pending"]))

        mtd_total = _d(mtd["total"])
        mtd_mgr = _d(mtd["mgr"])
        mtd_own = _d(mtd["own"])
        alerts = []
        if generated_count == 0 and today.day >= 6:
            alerts.append({"type": "GENERATE_MONTHLY", "message": f"{month:02d}/{year} monthly kists have not been generated yet."})
        if risk["n"] > 0:
            alerts.append({"type": "OVERDUE", "message": f"{risk['n']} overdue / partial kists need fine compute."})
        if cust["blacklisted"]:
            alerts.append({"type": "BLACKLISTED", "message": f"{cust['blacklisted']} blacklisted customer(s)."})

        return {
            "period": {"billing_year": year, "billing_month": month, "as_of": today.isoformat()},
            "portfolio": {
                "active_aum": float(active_aum),
                "total_disbursed": float(disbursed),
                "active_loans": active_count,
                "closed_loans": closed_count,
                "product_mix": mix,
            },
            "capital": {
                "owner_deployed": float(owner_dep),
                "manager_deployed": float(mgr_dep),
                "processing_fees": float(fees),
                "mtd_collected": float(mtd_total),
                "mtd_owner_received": float(mtd_own),
                "mtd_manager_received": float(mtd_mgr),
                "mtd_cash": float(_d(mtd["cash"])),
                "mtd_upi": float(_d(mtd["upi"])),
                "mtd_receipts": mtd["n"],
                "total_forgiven": float(_d(forgiven_all["forgiven"])),
            },
            "cycles": cycles,
            "risk": {
                "overdue_partial_kists": risk["n"],
                "overdue_partial_loans": risk["loans"],
                "overdue_partial_due": float(_d(risk["due"])),
                "fines_and_interest": float(_d(risk["charges"])),
                "forgiven_on_overdue": float(_d(risk["forgiven"])),
            },
            "customers": {
                "total": cust["total"] or 0,
                "active_borrowers": active_borrowers or 0,
                "guarantors": cust["guarantors"] or 0,
                "kyc_pending": cust["kyc_pending"] or 0,
                "blacklisted": cust["blacklisted"] or 0,
            },
            "top_villages": [
                {"village": v["village"] or "—", "loans": v["loans"], "due": float(_d(v["due"]))} for v in villages
            ],
            "todays_receipts": [
                {
                    "receipt_no": r["receipt_no"], "customer_name": r["customer_name"], "loan_id": r["loan_id"],
                    "amount": float(_d(r["payment_amount"])), "payment_mode": r["payment_mode"],
                    "current_kist_no": r["current_kist_no"], "payment_date": _iso(r["payment_date"]),
                    "payment_status": r["payment_status"],
                }
                for r in todays_receipts
            ],
            "alerts": alerts,
        }


dashboard_service = DashboardService()
