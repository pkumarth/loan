import math
from typing import Any

from app.dao.base_dao import BaseDAO
from app.domain.payment import PAYMENT_ALL_COLUMNS, PAYMENT_WRITE_COLUMNS, PaymentFilterParams

_SELECT_COLS = ", ".join(f"p.`{c}`" for c in PAYMENT_ALL_COLUMNS)


class PaymentDAO(BaseDAO):
    table_name = "payments"
    pk_column = "payment_id"
    allowed_columns = PAYMENT_ALL_COLUMNS
    write_columns = PAYMENT_WRITE_COLUMNS
    update_columns = ()
    patch_columns = ("payment_status", "remarks")

    def fetch_by_idempotency_key(self, conn, key: str) -> dict | None:
        sql = f"SELECT {self._safe_select_clause(list(PAYMENT_ALL_COLUMNS))} FROM `payments` WHERE `idempotency_key` = %s"
        with conn.cursor() as cur:
            cur.execute(sql, (key,))
            return cur.fetchone()

    def lock_by_id(self, conn, payment_id: int) -> dict | None:
        """SELECT ... FOR UPDATE so two reversals of the same receipt cannot both apply."""
        sql = f"SELECT {self._safe_select_clause(list(PAYMENT_ALL_COLUMNS))} FROM `payments` WHERE `payment_id` = %s FOR UPDATE"
        with conn.cursor() as cur:
            cur.execute(sql, (payment_id,))
            return cur.fetchone()

    def lock_schedule(self, conn, payment_schedule_id: int) -> dict | None:
        """Locks the installment and returns the columns needed for runtime balance + customer lookup."""
        sql = (
            "SELECT ps.payment_schedule_id, ps.loan_id, ps.current_kist_no, ps.installment_date, ps.status, "
            "ps.installment_amount, ps.fine_amount, ps.other_amount, ps.kist_interest_amount, "
            "ps.amount_paid, ps.manager_received_amount, ps.owner_received_amount, ps.forgive_amount, "
            "ps.payment_date, l.customer_id, l.loan_status "
            "FROM `payment_schedule` ps JOIN `loans` l ON l.loan_id = ps.loan_id "
            "WHERE ps.payment_schedule_id = %s FOR UPDATE"
        )
        with conn.cursor() as cur:
            cur.execute(sql, (payment_schedule_id,))
            return cur.fetchone()

    def update_schedule_collection(self, conn, payment_schedule_id: int, data: dict[str, Any], actor: str) -> int:
        sql = (
            "UPDATE `payment_schedule` SET `amount_paid` = %s, `manager_received_amount` = %s, "
            "`owner_received_amount` = %s, `payer_name` = COALESCE(%s, `payer_name`), `payment_date` = %s, "
            "`status` = %s, `updated_by` = %s, `version` = `version` + 1 WHERE `payment_schedule_id` = %s"
        )
        params = (
            data["amount_paid"], data["manager_received_amount"], data["owner_received_amount"],
            data["payer_name"], data["payment_date"], data["status"], actor, payment_schedule_id,
        )
        with conn.cursor() as cur:
            cur.execute(sql, params)
            return cur.rowcount

    def lock_loan(self, conn, loan_id: int) -> dict | None:
        with conn.cursor() as cur:
            cur.execute("SELECT `loan_id`, `customer_id`, `loan_status` FROM `loans` WHERE `loan_id` = %s FOR UPDATE", (loan_id,))
            return cur.fetchone()

    def lock_loan_schedules(self, conn, loan_id: int) -> list[dict]:
        """All installments of one loan, locked in id order (same columns as lock_schedule)."""
        sql = (
            "SELECT ps.payment_schedule_id, ps.loan_id, ps.current_kist_no, ps.installment_date, ps.status, "
            "ps.installment_amount, ps.fine_amount, ps.other_amount, ps.kist_interest_amount, "
            "ps.amount_paid, ps.manager_received_amount, ps.owner_received_amount, ps.forgive_amount, "
            "ps.payment_date, l.customer_id, l.loan_status "
            "FROM `payment_schedule` ps JOIN `loans` l ON l.loan_id = ps.loan_id "
            "WHERE ps.loan_id = %s ORDER BY ps.payment_schedule_id FOR UPDATE"
        )
        with conn.cursor() as cur:
            cur.execute(sql, (loan_id,))
            return cur.fetchall()

    def find_loan_collection_receipts(self, conn, key: str) -> list[dict]:
        """Receipts written by a loan-level collection with this key; children are stored as '<key>:<schedule_id>'.

        Range comparisons are unsafe here: utf8mb4_unicode_ci does not order ':' and ';' the way ASCII does.
        The SQL filter is a superset (case-insensitive equality), and the exact 'key:' prefix is checked in Python.
        """
        with conn.cursor() as cur:
            cur.execute(
                "SELECT `payment_id`, `loan_id`, `idempotency_key` FROM `payments` "
                "WHERE LEFT(`idempotency_key`, %s) = %s ORDER BY `payment_id`",
                (len(key), key),
            )
            rows = cur.fetchall()
        return [r for r in rows if r["idempotency_key"].startswith(f"{key}:")]

    def build_filter_query(self, filters: PaymentFilterParams) -> tuple[list[str], list[Any]]:
        clauses, params = [], []
        if filters.payment_ids:
            ids = [int(x.strip()) for x in filters.payment_ids.split(",") if x.strip().isdigit()]
            if ids:
                clauses.append(f"p.`payment_id` IN ({', '.join(['%s'] * len(ids))})")
                params.extend(ids)
        for col in ("loan_id", "customer_id", "payment_schedule_id", "payment_status", "payment_mode"):
            val = getattr(filters, col)
            if val is not None:
                clauses.append(f"p.`{col}` = %s")
                params.append(val.value if hasattr(val, "value") else val)
        if filters.payment_date is not None:
            clauses.append("DATE(p.`payment_date`) = %s")
            params.append(filters.payment_date.isoformat())
        return clauses, params

    def list_joined(self, conn, clauses: list[str], params: list[Any], page: int, size: int) -> tuple[list[dict], dict]:
        """Receipts with borrower name and loan account for the receipts table."""
        where_sql = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        from_sql = "FROM `payments` p JOIN `loans` l ON l.loan_id = p.loan_id JOIN `customers` c ON c.customer_id = p.customer_id"
        offset = (page - 1) * size
        with conn.cursor() as cur:
            cur.execute(f"SELECT COUNT(*) AS total {from_sql} {where_sql}", tuple(params))
            total = cur.fetchone()["total"]
            cur.execute(
                f"SELECT {_SELECT_COLS}, c.`customer_name`, l.`loan_account_no` {from_sql} {where_sql} "
                f"ORDER BY p.`payment_id` DESC LIMIT %s OFFSET %s",
                (*params, size, offset),
            )
            rows = cur.fetchall()
        total_pages = math.ceil(total / size) if total > 0 else 0
        return rows, {
            "page": page, "size": size, "total_elements": total,
            "total_pages": total_pages, "has_next": page < total_pages,
        }


payment_dao = PaymentDAO()
