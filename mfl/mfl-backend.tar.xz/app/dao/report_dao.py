from datetime import date
from app.domain.report import REPORT_COLUMNS


class ReportDAO:
    def fetch_scope_loans(self, conn, onetime_cutoff: date, loan_id: int | None = None) -> list[dict]:
        """EMI / MONTHLY_INTEREST ACTIVE loans, plus ACTIVE ONETIME loans older than the cutoff (modified_borrowing_date).

        Pass loan_id to restrict the result to one loan.
        """
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT l.loan_id, l.loan_parent_id, l.loan_type, l.borrowing_date, l.modified_borrowing_date,
                       l.emi_start_date, l.emi_first_installment_date, l.emi_last_installment_date,
                       l.total_no_of_kist, l.rem_principal_amt, l.manager_name, l.owner_name,
                       c.customer_name AS borrower_name, c.guardian_name, c.customer_mobile AS borrower_mobile,
                       g.customer_name AS guarantor_name,
                       COALESCE(g.customer_mobile, c.guarantor_mobile) AS guarantor_mobile,
                       a.mohalla, a.village
                FROM loans l
                INNER JOIN customers c ON c.customer_id = l.customer_id
                LEFT JOIN addresses a ON a.address_id = c.address_id
                LEFT JOIN customers g ON g.customer_id = COALESCE(l.guarantor_id, c.guarantor_id)
                WHERE l.loan_status = 'ACTIVE'
                  AND (l.loan_type IN ('EMI', 'MONTHLY_INTEREST')
                       OR (l.loan_type = 'ONETIME' AND l.modified_borrowing_date < %s))
                  AND (%s IS NULL OR l.loan_id = %s)
                ORDER BY l.loan_id
                """,
                (onetime_cutoff, loan_id, loan_id),
            )
            return cur.fetchall()

    def fetch_schedule_rows(self, conn, loan_ids: list[int]) -> list[dict]:
        if not loan_ids:
            return []
        placeholders = ", ".join(["%s"] * len(loan_ids))
        with conn.cursor() as cur:
            cur.execute(
                f"""
                SELECT ps.payment_schedule_id, ps.loan_id, ps.status, ps.installment_date, ps.current_kist_no,
                       ps.installment_amount, ps.fine_amount, ps.other_amount, ps.kist_interest_amount,
                       ps.amount_paid, ps.manager_received_amount, ps.owner_received_amount
                FROM payment_schedule ps
                WHERE ps.loan_id IN ({placeholders})
                """,
                tuple(loan_ids),
            )
            return cur.fetchall()

    def replace_all(self, conn, rows: list[dict]) -> None:
        """Purge the whole report table and insert the rebuilt rows, inside the caller's transaction."""
        cols = ", ".join(REPORT_COLUMNS)
        placeholders = ", ".join(["%s"] * len(REPORT_COLUMNS))
        with conn.cursor() as cur:
            cur.execute("DELETE FROM payment_schedule_report")
            if rows:
                cur.executemany(
                    f"INSERT INTO payment_schedule_report ({cols}) VALUES ({placeholders})",
                    [tuple(r[c] for c in REPORT_COLUMNS) for r in rows],
                )
    def fetch_report_rows(self, conn, clauses: list[str], params: list, page: int, size: int) -> tuple[list[dict], dict]:
        """Paginated read of payment_schedule_report (all REPORT_COLUMNS), ordered by loan_id."""
        where_sql = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        offset = (page - 1) * size
        with conn.cursor() as cur:
            cur.execute(f"SELECT COUNT(*) AS total FROM payment_schedule_report {where_sql}", tuple(params))
            total_elements = cur.fetchone()["total"]
            cur.execute(
                f"SELECT {', '.join(REPORT_COLUMNS)} FROM payment_schedule_report {where_sql} "
                f"ORDER BY loan_id LIMIT %s OFFSET %s",
                (*params, size, offset),
            )
            rows = cur.fetchall()
        total_pages = -(-total_elements // size) if total_elements else 0
        return rows, {
            "page": page,
            "size": size,
            "total_elements": total_elements,
            "total_pages": total_pages,
            "has_next": page < total_pages,
        }

    def replace_loan(self, conn, loan_id: int, row: dict) -> None:
        """Replaces the single report row of one loan (inside the caller's transaction)."""
        cols = ", ".join(REPORT_COLUMNS)
        placeholders = ", ".join(["%s"] * len(REPORT_COLUMNS))
        with conn.cursor() as cur:
            cur.execute("DELETE FROM payment_schedule_report WHERE loan_id = %s", (loan_id,))
            cur.execute(
                f"INSERT INTO payment_schedule_report ({cols}) VALUES ({placeholders})",
                tuple(row[c] for c in REPORT_COLUMNS),
            )

    def delete_loan(self, conn, loan_id: int) -> None:
        with conn.cursor() as cur:
            cur.execute("DELETE FROM payment_schedule_report WHERE loan_id = %s", (loan_id,))


report_dao = ReportDAO()
