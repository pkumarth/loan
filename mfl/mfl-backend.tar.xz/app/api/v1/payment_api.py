from datetime import date

from fastapi import APIRouter, Depends, Query, status

from app.core.config import settings
from app.core.database import TransactionalRoute, get_actor, get_db
from app.domain.payment import LoanCollectRequest, PaymentCreate, PaymentFilterParams, PaymentModeEnum, PaymentPatch, PaymentStatusEnum
from app.service.payment_service import payment_service
from app.util.response import build_response

router = APIRouter(route_class=TransactionalRoute, prefix="/payments", tags=["5. Payments"])


@router.post("", status_code=status.HTTP_201_CREATED)
def collect_payment(payload: PaymentCreate, conn=Depends(get_db), actor: str = Depends(get_actor)):
    record, created = payment_service.collect(conn, payload, actor)
    if created:
        return build_response(status.HTTP_201_CREATED, f"Receipt {record['receipt_no']} recorded", data=record)
    return build_response(status.HTTP_200_OK, f"Receipt {record['receipt_no']} already recorded (idempotent replay)", data=record)


@router.post("/loans/{loan_id}/collect", status_code=status.HTTP_201_CREATED)
def collect_loan_payment(loan_id: int, payload: LoanCollectRequest, conn=Depends(get_db), actor: str = Depends(get_actor)):
    result, created = payment_service.collect_for_loan(conn, loan_id, payload, actor)
    n = result["installments_touched"]
    if created:
        return build_response(status.HTTP_201_CREATED, f"Loan {loan_id}: collected {result['total_collected']} across {n} installment(s)", data=result)
    return build_response(status.HTTP_200_OK, f"Loan {loan_id}: already recorded (idempotent replay)", data=result)


@router.get("")
def list_payments(
    payment_ids: str | None = Query(default=None),
    loan_id: int | None = Query(default=None),
    customer_id: int | None = Query(default=None),
    payment_schedule_id: int | None = Query(default=None),
    payment_status: PaymentStatusEnum | None = Query(default=None),
    payment_mode: PaymentModeEnum | None = Query(default=None),
    payment_date: date | None = Query(default=None),
    page: int = Query(default=1, ge=1),
    size: int = Query(default=settings.DEFAULT_PAGE_SIZE, ge=1, le=settings.MAX_PAGE_SIZE),
    conn=Depends(get_db),
):
    filters = PaymentFilterParams(
        payment_ids=payment_ids, loan_id=loan_id, customer_id=customer_id, payment_schedule_id=payment_schedule_id,
        payment_status=payment_status, payment_mode=payment_mode, payment_date=payment_date,
    )
    rows, pagination = payment_service.list_payments(conn, filters, page, size)
    return build_response(status.HTTP_200_OK, "Payments retrieved successfully", data=rows, pagination=pagination)


@router.get("/{payment_id}")
def get_payment(payment_id: int, include: str | None = Query(default=None), exclude: str | None = Query(default=None), conn=Depends(get_db)):
    return build_response(status.HTTP_200_OK, "Payment retrieved successfully", data=payment_service.get_payment(conn, payment_id, include, exclude))


@router.patch("/{payment_id}")
def patch_payment(payment_id: int, payload: PaymentPatch, conn=Depends(get_db), actor: str = Depends(get_actor)):
    return build_response(status.HTTP_200_OK, "Payment updated successfully", data=payment_service.patch_payment(conn, payment_id, payload, actor))
