from fastapi import APIRouter, Depends, Query, status

from app.core.config import settings
from app.core.database import TransactionalRoute, get_db
from app.service.dashboard_service import dashboard_service
from app.service.report_service import report_service
from app.util.response import build_response

router = APIRouter(route_class=TransactionalRoute, prefix="/dashboard", tags=["6. Dashboard"])


@router.get("/summary")
def dashboard_summary(
    billing_year: int | None = Query(default=None, ge=2000, le=2100),
    billing_month: int | None = Query(default=None, ge=1, le=12),
    conn=Depends(get_db),
):
    data = dashboard_service.summary(conn, billing_year, billing_month)
    return build_response(status.HTTP_200_OK, "Dashboard summary computed", data=data)


@router.get("/report")
def dashboard_report_rows(
    report_status: str | None = Query(default=None, pattern="^(OPEN|OVERDUE|CLOSED)$"),
    loan_type: str | None = Query(default=None, pattern="^(EMI|MONTHLY_INTEREST|ONETIME)$"),
    search: str | None = Query(default=None, max_length=120, description="Borrower name or loan id"),
    page: int = Query(default=1, ge=1),
    size: int = Query(default=settings.DEFAULT_PAGE_SIZE, ge=1, le=settings.MAX_PAGE_SIZE),
    conn=Depends(get_db),
):
    rows, pagination = report_service.list_rows(conn, report_status, loan_type, search, page, size)
    return build_response(status.HTTP_200_OK, "Report rows retrieved successfully", data=rows, pagination=pagination)
