"use client";

import { useQuery } from "@tanstack/react-query";
import { api, Envelope, Pagination } from "@/lib/api-client";

type Params = Record<string, string | number | boolean | null | undefined>;

/** Paginated GET helper used by every list screen. Query key includes all filters + page. */
export function useList<T>(resource: string, params: Params, enabled = true) {
  return useQuery({
    queryKey: [resource, params],
    queryFn: () => api<T[]>(resource, { query: params }) as Promise<Envelope<T[]>>,
    enabled,
    placeholderData: (prev) => prev,
  });
}

export const EMPTY_PAGE: Pagination = { page: 1, size: 0, total_elements: 0, total_pages: 0, has_next: false };
