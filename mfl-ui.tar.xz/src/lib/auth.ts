"use client";

// STUB AUTH — client-side only, for development. Not secure: anyone can set localStorage.
// Replace with the real Mobile + Password + OTP flow (backend endpoints + SMS provider) before real use.

export type AdminRole = "Owner" | "Manager";
export type Session = { name: string; role: AdminRole; mobile: string };

// Registered admins per the UX spec (Section 0 / Screen 0). Mobile numbers are placeholders.
export const ADMINS: Record<AdminRole, { name: string }> = {
  Owner: { name: "praveen" },
  Manager: { name: "bhikhari_yadav" },
};

// Stub OTP. Override with NEXT_PUBLIC_DEV_OTP in .env if desired.
export const DEV_OTP = process.env.NEXT_PUBLIC_DEV_OTP ?? "123456";
export const OTP_RESEND_SECONDS = 60;

const SESSION_KEY = "mfl-session";

export function getSession(): Session | null {
  if (typeof window === "undefined") return null;
  const raw = window.localStorage.getItem(SESSION_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as Session;
  } catch {
    return null;
  }
}

export function setSession(session: Session): void {
  window.localStorage.setItem(SESSION_KEY, JSON.stringify(session));
}

export function clearSession(): void {
  window.localStorage.removeItem(SESSION_KEY);
}

/** Stub check: 10-digit mobile, non-empty password. No credential is verified. */
export function validateCredentials(mobile: string, password: string): string | null {
  if (!/^\d{10}$/.test(mobile)) return "Enter a 10-digit mobile number";
  if (password.length === 0) return "Enter your password";
  return null;
}

export function verifyOtp(code: string): boolean {
  return code === DEV_OTP;
}
