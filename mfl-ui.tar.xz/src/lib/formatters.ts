// Indian numbering (₹1,20,000.00) and DD-MMM-YYYY dates, per the UX spec.

const inrNumber = new Intl.NumberFormat("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

/** Spec format: "Rs. 1,20,000.00" (Indian grouping). */
export function formatINR(value: number | string | null | undefined): string {
  if (value === null || value === undefined || value === "") return "—";
  const n = typeof value === "string" ? Number(value) : value;
  return Number.isFinite(n) ? `Rs. ${inrNumber.format(n)}` : "—";
}

/** Same grouping without the "Rs." prefix, e.g. "1,20,000.00". */
export function formatAmount(value: number | string | null | undefined): string {
  if (value === null || value === undefined || value === "") return "—";
  const n = typeof value === "string" ? Number(value) : value;
  return Number.isFinite(n) ? inrNumber.format(n) : "—";
}

const dateFmt = new Intl.DateTimeFormat("en-GB", { day: "2-digit", month: "short", year: "numeric" });

export function formatDate(value: string | null | undefined): string {
  if (!value) return "—";
  const d = new Date(`${value.slice(0, 10)}T00:00:00`);
  return Number.isNaN(d.getTime()) ? value : dateFmt.format(d);
}

/** Today as YYYY-MM-DD in local time (the backend default hisab/run date). */
export function todayISO(): string {
  const d = new Date();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${m}-${day}`;
}

export function addMonthsISO(iso: string, months: number): string {
  const [y, m, d] = iso.split("-").map(Number);
  const total = m - 1 + months;
  const year = y + Math.floor(total / 12);
  const month = ((total % 12) + 12) % 12;
  const maxDay = new Date(year, month + 1, 0).getDate();
  const dt = new Date(year, month, Math.min(d, maxDay));
  return `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, "0")}-${String(dt.getDate()).padStart(2, "0")}`;
}

/** Collection cycle per the spec: start day 8..cutoff 20 => 12th cycle, otherwise 25th. */
export function cycleFor(isoDate: string, start = 8, cutoff = 20): "12th" | "25th" {
  const day = Number(isoDate.slice(8, 10));
  return day >= start && day <= cutoff ? "12th" : "25th";
}

/** Short display labels for loan types. The API values are unchanged: EMI, MONTHLY_INTEREST, ONETIME. */
export const LOAN_TYPE_LABEL: Record<"EMI" | "MONTHLY_INTEREST" | "ONETIME", string> = {
  EMI: "EMI",
  MONTHLY_INTEREST: "MI",
  ONETIME: "OT",
};

const inrWhole = new Intl.NumberFormat("en-IN", { maximumFractionDigits: 0 });

/** Indian grouping with no decimal part, e.g. "1,20,000". */
export function formatWhole(value: number | string | null | undefined): string {
  if (value === null || value === undefined || value === "") return "—";
  const n = typeof value === "string" ? Number(value) : value;
  return Number.isFinite(n) ? inrWhole.format(n) : "—";
}

/**
 * Accrued interest = principal × rate × days ÷ 3000, rounded to whole rupees (half up).
 * Days run from the borrowing date to today; a future borrowing date gives 0.
 */
export function accruedInterest(principal: number, rate: number, borrowingISO: string, todayIso: string = todayISO()): number {
  const start = Date.parse(`${borrowingISO.slice(0, 10)}T00:00:00`);
  const end = Date.parse(`${todayIso}T00:00:00`);
  const days = Math.max(0, Math.round((end - start) / 86_400_000));
  return Math.round((principal * rate * days) / 3000);
}
