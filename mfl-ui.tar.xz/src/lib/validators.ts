import { z } from "zod";

// Mirrors the backend rule: (manager_amount + owner_amount) / 1000 == principal in k, i.e. the split must equal principal.
export const capitalSplitSchema = z
  .object({
    principal_amt: z.number({ message: "Enter principal amount" }).positive("Principal must be greater than 0"),
    manager_amount: z.number().min(0, "Cannot be negative"),
    owner_amount: z.number().min(0, "Cannot be negative"),
  })
  .refine((v) => Math.abs(v.manager_amount + v.owner_amount - v.principal_amt) < 0.005, {
    message: "Manager + owner must equal principal",
    path: ["owner_amount"],
  });

// Collection rule: manager + owner received = amount paid + forgive.
export const collectionSchema = z.object({
  manager_received_amount: z.number().min(0),
  owner_received_amount: z.number().min(0),
  forgive_amount: z.number().min(0),
});

export const mobileSchema = z.string().regex(/^\d{10}$/, "Enter a 10-digit mobile number");
export const panSchema = z
  .string()
  .transform((s) => s.toUpperCase())
  .refine((s) => s === "" || /^[A-Z]{5}[0-9]{4}[A-Z]$/.test(s), "PAN format: ABCDE1234F");
export const aadhaarSchema = z
  .string()
  .refine((s) => s === "" || /^\d{4}-?\d{4}-?\d{4}$/.test(s), "Aadhaar must be 12 digits");

export function num(value: string): number {
  const n = Number(value);
  return Number.isFinite(n) ? n : 0;
}
