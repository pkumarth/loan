/** Turns a snake_case key into a field label, e.g. "police_station" -> "Police station". */
export function label(k: string) {
  return k.replace(/_/g, " ").replace(/^./, (c) => c.toUpperCase());
}

/** Blank strings become null so optional columns are not stored as empty text. */
export function clean<T extends Record<string, string>>(obj: T): Record<string, string | null> {
  return Object.fromEntries(Object.entries(obj).map(([k, v]) => [k, v.trim() === "" ? null : v.trim()]));
}
