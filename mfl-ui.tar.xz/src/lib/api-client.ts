// Single HTTP entry point for the MFL backend. Every call returns the MFL envelope:
// { status, status_code, display_msg, cause, data, pagination }.

import { getSession } from "@/lib/auth";

export type Pagination = {
  page: number;
  size: number;
  total_elements: number;
  total_pages: number;
  has_next: boolean;
};

export type Envelope<T> = {
  status: "success" | "failure";
  status_code: number;
  display_msg: string;
  cause: unknown;
  data: T;
  pagination?: Pagination;
};

export class ApiError extends Error {
  constructor(
    public readonly httpStatus: number,
    public readonly displayMsg: string,
    public readonly cause: unknown,
  ) {
    super(displayMsg);
  }

  /** Field-level message from a validation error, e.g. "principal_amt: Input should be greater than 0". */
  fieldMessages(): string[] {
    if (typeof this.cause === "string") return this.cause.split("; ");
    return [];
  }
}

export const BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL ?? "http://127.0.0.1:8000";
export const API_PREFIX = `${BASE_URL}/mfl-core/api/v1`;
export const DEFAULT_USER = "praveen";

/** X-User-Id = the logged-in admin (stub session); falls back to the Owner name when logged out. */
export function getActiveUser(): string {
  return getSession()?.name ?? DEFAULT_USER;
}

type Query = Record<string, string | number | boolean | null | undefined>;

export type ApiOptions = {
  method?: "GET" | "POST" | "PUT" | "PATCH" | "DELETE";
  body?: unknown;
  query?: Query;
};

function buildQuery(query?: Query): string {
  if (!query) return "";
  const params = new URLSearchParams();
  for (const [key, value] of Object.entries(query)) {
    if (value !== undefined && value !== null && value !== "") params.set(key, String(value));
  }
  const qs = params.toString();
  return qs ? `?${qs}` : "";
}

export async function api<T>(path: string, opts: ApiOptions = {}): Promise<Envelope<T>> {
  const res = await fetch(`${API_PREFIX}${path}${buildQuery(opts.query)}`, {
    method: opts.method ?? "GET",
    headers: {
      "Content-Type": "application/json",
      "X-User-Id": getActiveUser(),
    },
    body: opts.body === undefined ? undefined : JSON.stringify(opts.body),
    cache: "no-store",
  });
  const text = await res.text();
  let json: Envelope<T> | null = null;
  try {
    json = text ? (JSON.parse(text) as Envelope<T>) : null;
  } catch {
    json = null;
  }
  if (!res.ok || !json || json.status === "failure") {
    throw new ApiError(
      res.status,
      json?.display_msg ?? `Request failed (${res.status})`,
      json?.cause ?? null,
    );
  }
  return json;
}

export async function checkHealth(): Promise<boolean> {
  try {
    const res = await fetch(`${BASE_URL}/mfl-core/health`, { cache: "no-store" });
    return res.ok;
  } catch {
    return false;
  }
}
