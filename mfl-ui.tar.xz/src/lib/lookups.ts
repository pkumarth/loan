"use client";

import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api-client";
import type { Address, Customer, ScheduleRow } from "@/types/mfl-api";

// The loans list only carries ids. Customer name/mobile, guarantor name, village and mohalla
// come from the customer and address records, so the Loan tab joins them client-side.
// Query keys start with "/customers" and "/addresses" so existing prefix invalidation refreshes them.

const LOOKUP_PAGE_SIZE = 200; // backend rejects larger sizes

async function fetchAll<T>(resource: string): Promise<T[]> {
  const out: T[] = [];
  for (let page = 1; ; page++) {
    const res = await api<T[]>(resource, { query: { page, size: LOOKUP_PAGE_SIZE } });
    out.push(...res.data);
    if (!res.pagination?.has_next) break;
  }
  return out;
}

export function useCustomerLookup() {
  const q = useQuery({
    queryKey: ["/customers", "all"],
    queryFn: () => fetchAll<Customer>("/customers"),
    staleTime: 60_000,
  });
  const byId = useMemo(() => new Map((q.data ?? []).map((c) => [c.customer_id, c])), [q.data]);
  return { byId, isLoading: q.isLoading };
}

export function useAddressLookup() {
  const q = useQuery({
    queryKey: ["/addresses", "all"],
    queryFn: () => fetchAll<Address>("/addresses"),
    staleTime: 60_000,
  });
  const byId = useMemo(() => new Map((q.data ?? []).map((a) => [a.address_id, a])), [q.data]);
  return { byId, isLoading: q.isLoading };
}

export function useScheduleLookup() {
  const q = useQuery({
    queryKey: ["/payment-schedules", "all"],
    queryFn: () => fetchAll<ScheduleRow>("/payment-schedules"),
    staleTime: 60_000,
  });
  const byId = useMemo(() => new Map((q.data ?? []).map((r) => [r.payment_schedule_id, r])), [q.data]);
  return { byId, isLoading: q.isLoading };
}
