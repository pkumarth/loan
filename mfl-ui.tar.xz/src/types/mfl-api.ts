// Types mirror the FastAPI response models. Money fields arrive as JSON numbers.

export type LoanType = "EMI" | "MONTHLY_INTEREST" | "ONETIME";
export type LoanStatus = "DRAFT" | "ACTIVE" | "CLOSED" | "RESTRUCTURED" | "DEFAULTED";
export type ScheduleStatus = "OPEN" | "PARTIAL" | "CLOSED" | "OVERDUE" | "WAIVED";
export type ReportStatus = "OPEN" | "OVERDUE" | "CLOSED";
export type Relation = "FATHER" | "HUSBAND" | "MOTHER" | "OTHER";

export interface Address {
  address_id: number;
  country: string;
  state: string;
  district: string;
  police_station: string | null;
  village: string | null;
  mohalla: string | null;
  ward_no: string | null;
  landmark: string | null;
  postal_code: string;
  version: number;
}

export interface Customer {
  customer_id: number;
  customer_code?: string | null;
  customer_name: string;
  guardian_name: string;
  guardian_relation: Relation;
  customer_mobile: string;
  customer_email?: string | null;
  address_id: number;
  guarantor_id: number | null;
  guarantor_relation?: Relation;
  guarantor_mobile?: string | null;
  customer_status?: string;
  customer_rating?: number | null;
  family_income?: number | null;
  family_loan?: number | null;
  version: number;
}

export interface Loan {
  loan_id: number;
  loan_account_no: string;
  loan_parent_id: number | null;
  customer_id: number;
  guarantor_id: number | null;
  rem_principal_amt: number;
  original_principal_amt_k: number;
  rate_of_interest: number;
  borrowing_date: string;
  modified_borrowing_date: string;
  emi_start_date: string | null;
  emi_first_installment_date: string | null;
  emi_last_installment_date: string | null;
  loan_type: LoanType;
  total_no_of_kist: number;
  installment_amount: number;
  loan_status: LoanStatus;
  manager_name: string | null;
  manager_amount: number;
  owner_name: string | null;
  owner_amount: number;
  processing_fee: number;
  loan_purpose: string | null;
  fine_rule: string | null;
  description: string | null;
  version: number;
}

export interface ScheduleRow {
  payment_schedule_id: number;
  loan_id: number;
  loan_parent_id: number | null;
  loan_type: LoanType;
  customer_name: string;
  customer_mobile: string;
  mohalla: string | null;
  village: string | null;
  guardian_name: string;
  guarantor_name: string | null;
  guarantor_mobile: string | null;
  current_kist_no: number;
  total_no_of_kist: number;
  billing_year: number;
  billing_month: number;
  rem_principal_amt: number;
  rate_of_interest: number;
  emi_start_date: string | null;
  emi_first_installment_date: string | null;
  emi_last_installment_date: string | null;
  installment_date: string;
  installment_amount: number;
  fine_amount: number;
  other_amount: number;
  kist_interest_amount: number;
  forgive_amount: number;
  partial_principal_amt_return: number;
  manager_name: string | null;
  manager_received_amount: number;
  owner_name: string | null;
  owner_received_amount: number;
  payer_name: string | null;
  amount_paid: number;
  remaining_principal_amt: number;
  balance_due: number;
  status: ScheduleStatus;
  payment_date: string | null;
  version: number;
}

export interface OnetimeDryRunItem {
  loan_id: number;
  loan_account_no: string;
  customer_name: string;
  guardian_name: string;
  rem_principal_amt: number;
  rate_of_interest: number;
  modified_borrowing_date: string;
  days: number;
  per_day_interest: number;
  interest_amount: number;
  total_due: number;
}

export interface OnetimeSettlementResult {
  dry_run: boolean;
  loan_id: number;
  guardian_name: string;
  hisab_date: string;
  days: number;
  per_day_interest: number;
  interest_amount: number;
  total_due: number;
  rem_principal_amt: number;
  rate_of_interest: number;
  // real run only
  payment_schedule_id?: number;
  amount_paid?: number;
  forgive_amount?: number;
  partial_principal_amt_return?: number;
  shortfall_amount?: number;
  previous_rem_principal_amt?: number;
  loan_status?: LoanStatus;
  next_current_kist_no?: number;
}

export interface OverdueItem {
  payment_schedule_id: number;
  loan_id: number;
  loan_type: LoanType;
  current_kist_no: number;
  installment_date: string;
  days: number;
  installment_amount: number;
  amount_paid: number;
  other_amount: number;
  fine_amount: number;
  kist_interest_amount: number;
  due_amount: number;
  previous_status: ScheduleStatus;
  status: ScheduleStatus;
}

export interface OverdueResult {
  run_date: string;
  dry_run: boolean;
  loan_id: number | null;
  row_count: number;
  total_due: number;
  loans: { loan_id: number; row_count: number; total_due: number }[];
  items: OverdueItem[];
}

export interface ReportResult {
  billing_year: number;
  billing_month: number;
  report_run_date: string;
  dry_run: boolean;
  row_count: number;
  status_counts: Record<ReportStatus, number>;
  total_overdue_amount: number;
  file_path: string | null;
}

export interface GenerateMonthlyResult {
  billing_period: string;
  billing_year: number;
  billing_month: number;
  generated_count: number;
  cycle_12_count: number;
  cycle_25_count: number;
  skipped_already_generated: number;
  skipped_kists_completed: number;
  skipped_not_due_yet: number;
  items: Record<string, unknown>[];
}

export type PaymentMode = "CASH" | "UPI" | "BANK_TRANSFER" | "CHEQUE";
export type PaymentStatus = "SUCCESS" | "REVERSED" | "BOUNCED";

export interface PaymentRecord {
  payment_id: number;
  receipt_no: string;
  idempotency_key: string;
  payment_schedule_id: number | null;
  loan_id: number;
  customer_id: number;
  current_kist_no: number | null;
  installment_date: string | null;
  payment_amount: number;
  manager_received_amount: number;
  owner_received_amount: number;
  payer_name: string | null;
  payment_date: string;
  payment_mode: PaymentMode;
  transaction_ref: string | null;
  payment_status: PaymentStatus;
  remarks: string | null;
  // list view only
  customer_name?: string;
  loan_account_no?: string;
  version: number;
}

export interface DashboardSummary {
  period: { billing_year: number; billing_month: number; as_of: string };
  portfolio: {
    active_aum: number;
    total_disbursed: number;
    active_loans: number;
    closed_loans: number;
    product_mix: Record<string, number>;
  };
  capital: {
    owner_deployed: number;
    manager_deployed: number;
    processing_fees: number;
    mtd_collected: number;
    mtd_owner_received: number;
    mtd_manager_received: number;
    mtd_cash: number;
    mtd_upi: number;
    mtd_receipts: number;
    total_forgiven: number;
  };
  cycles: Record<"12th" | "25th", {
    expected: number; collected: number; pending: number; open_kists: number; efficiency_pct: number;
  }>;
  risk: {
    overdue_partial_kists: number;
    overdue_partial_loans: number;
    overdue_partial_due: number;
    fines_and_interest: number;
    forgiven_on_overdue: number;
  };
  customers: {
    total: number; active_borrowers: number; guarantors: number; kyc_pending: number; blacklisted: number;
  };
  top_villages: { village: string; loans: number; due: number }[];
  todays_receipts: {
    receipt_no: string; customer_name: string; loan_id: number; amount: number;
    payment_mode: PaymentMode; current_kist_no: number | null; payment_date: string; payment_status: PaymentStatus;
  }[];
  alerts: { type: "GENERATE_MONTHLY" | "OVERDUE" | "BLACKLISTED"; message: string }[];
}
