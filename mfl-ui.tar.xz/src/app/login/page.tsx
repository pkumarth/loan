"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { ShieldCheck } from "lucide-react";
import { Button, Field, Input } from "@/components/shared/ui";
import { checkHealth } from "@/lib/api-client";
import {
  ADMINS,
  AdminRole,
  DEV_OTP,
  OTP_RESEND_SECONDS,
  setSession,
  validateCredentials,
  verifyOtp,
} from "@/lib/auth";

export default function LoginPage() {
  const router = useRouter();
  const [role, setRole] = useState<AdminRole>("Owner");
  const [mobile, setMobile] = useState("");
  const [password, setPassword] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [otp, setOtp] = useState("");
  const [secondsLeft, setSecondsLeft] = useState(0);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (secondsLeft <= 0) return;
    const t = setTimeout(() => setSecondsLeft((s) => s - 1), 1000);
    return () => clearTimeout(t);
  }, [secondsLeft]);

  function sendOtp(e?: React.FormEvent) {
    e?.preventDefault();
    const err = validateCredentials(mobile, password);
    setError(err);
    if (err) return;
    // Stub: no SMS is sent. The code is DEV_OTP.
    setOtpSent(true);
    setSecondsLeft(OTP_RESEND_SECONDS);
  }

  function verify(e: React.FormEvent) {
    e.preventDefault();
    if (!verifyOtp(otp)) {
      setError("Incorrect OTP");
      return;
    }
    setSession({ name: ADMINS[role].name, role, mobile });
    router.replace("/");
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-100 p-4">
      <div className="w-full max-w-md rounded-lg bg-white p-6 shadow-md">
        <div className="mb-4 flex items-center gap-2 text-sm font-semibold">
          <ShieldCheck className="h-5 w-5" /> MFL Core Admin Portal
        </div>
        <p className="mb-4 text-[8px] text-slate-500">Restricted to Manager and Owner accounts.</p>
        <div className="mb-3 rounded border border-amber-300 bg-amber-50 p-2 text-[8px] text-amber-900">
          Development stub: no real authentication. Sending OTP does not send an SMS.
          {process.env.NODE_ENV === "development" && <> Dev OTP: <code>{DEV_OTP}</code></>}
        </div>

        <form onSubmit={otpSent ? verify : sendOtp} className="flex flex-col gap-4">
          <fieldset className="flex gap-4 text-[10px]" disabled={otpSent}>
            <legend className="mb-1 font-medium text-slate-700">Admin role</legend>
            {(Object.keys(ADMINS) as AdminRole[]).map((r) => (
              <label key={r} className="flex items-center gap-1">
                <input type="radio" name="role" checked={role === r} onChange={() => setRole(r)} />
                {r} ({ADMINS[r].name})
              </label>
            ))}
          </fieldset>

          <Field label="Mobile number">
            <Input
              inputMode="numeric"
              maxLength={10}
              value={mobile}
              onChange={(e) => setMobile(e.target.value.replace(/\D/g, ""))}
              disabled={otpSent}
              autoComplete="username"
            />
          </Field>

          <Field label="Password">
            <Input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={otpSent}
              autoComplete="current-password"
            />
          </Field>

          {otpSent && (
            <>
              <Field label="6-digit OTP" hint={`Stub code. Resend available in ${secondsLeft}s.`}>
                <Input
                  inputMode="numeric"
                  maxLength={6}
                  value={otp}
                  onChange={(e) => setOtp(e.target.value.replace(/\D/g, ""))}
                  autoFocus
                />
              </Field>
              <button
                type="button"
                className="self-start text-[10px] underline disabled:text-slate-400 disabled:no-underline"
                disabled={secondsLeft > 0}
                onClick={() => sendOtp()}
              >
                Resend OTP
              </button>
            </>
          )}

          {error && <p className="text-[10px] text-red-600">{error}</p>}

          <Button variant="primary" type="submit" disabled={otpSent && otp.length !== 6}>
            {otpSent ? "Verify OTP & enter workspace" : "Send OTP"}
          </Button>
        </form>
        <HealthLine />
      </div>
    </div>
  );
}

function HealthLine() {
  const [online, setOnline] = useState<boolean | null>(null);
  useEffect(() => {
    checkHealth().then(setOnline);
  }, []);
  return (
    <p className="mt-4 text-[8px] text-slate-500">
      Backend:{" "}
      {online === null ? "checking…" : online ? "Online" : "Unreachable"}
    </p>
  );
}
