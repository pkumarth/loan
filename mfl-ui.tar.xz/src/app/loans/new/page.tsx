"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { PageHeader, Card, Button, Field, Input, Select, DryRunBanner } from "@/components/shared/ui";
import { api } from "@/lib/api-client";
import { toastError, toastSuccess } from "@/components/providers";
import { capitalSplitSchema } from "@/lib/validators";
import { addMonthsISO, formatINR, LOAN_TYPE_LABEL, todayISO } from "@/lib/formatters";
import type { Loan } from "@/types/mfl-api";

type Form = {
  customer_id: string; loan_type: string; principal_amt: string; rate_of_interest: string;
  borrowing_date: string; installment_amount: string; total_no_of_kist: string;
  manager_name: string; manager_amount: string; owner_name: string; owner_amount: string;
  processing_fee: string; loan_purpose: string; loan_parent_id: string;
};

const EMPTY: Form = {
  customer_id: "", loan_type: "EMI", principal_amt: "", rate_of_interest: "2",
  borrowing_date: todayISO(), installment_amount: "", total_no_of_kist: "",
  manager_name: "", manager_amount: "0", owner_name: "", owner_amount: "0",
  processing_fee: "200", loan_purpose: "", loan_parent_id: "",
};

const n = (v: string) => (v === "" ? undefined : Number(v));

export default function NewLoanPage() {
  const router = useRouter();
  const qc = useQueryClient();
  const [form, setForm] = useState<Form>(EMPTY);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [confirming, setConfirming] = useState(false);

  const set = (k: keyof Form) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
    setForm({ ...form, [k]: e.target.value });

  const split = useMemo(() => {
    const parsed = capitalSplitSchema.safeParse({
      principal_amt: Number(form.principal_amt),
      manager_amount: Number(form.manager_amount || 0),
      owner_amount: Number(form.owner_amount || 0),
    });
    return parsed.success ? null : parsed.error.issues[0].message;
  }, [form.principal_amt, form.manager_amount, form.owner_amount]);

  const isOnetime = form.loan_type === "ONETIME";
  const maturity = form.total_no_of_kist && !isOnetime ? addMonthsISO(form.borrowing_date, Number(form.total_no_of_kist)) : null;

  const create = useMutation({
    mutationFn: () =>
      api<Loan>("/loans", {
        method: "POST",
        body: {
          customer_id: Number(form.customer_id),
          loan_type: form.loan_type,
          principal_amt: Number(form.principal_amt),
          rate_of_interest: n(form.rate_of_interest),
          borrowing_date: form.borrowing_date,
          installment_amount: isOnetime ? 0 : n(form.installment_amount),
          total_no_of_kist: isOnetime ? undefined : n(form.total_no_of_kist),
          manager_name: form.manager_name || null,
          manager_amount: Number(form.manager_amount || 0),
          owner_name: form.owner_name || null,
          owner_amount: Number(form.owner_amount || 0),
          processing_fee: Number(form.processing_fee || 0),
          loan_purpose: form.loan_purpose || null,
          loan_parent_id: form.loan_parent_id ? Number(form.loan_parent_id) : null,
        },
      }),
    onSuccess: (res) => {
      toastSuccess(`Loan ${res.data.loan_account_no} created`);
      qc.invalidateQueries({ queryKey: ["/loans"] });
      router.push(`/loans/${res.data.loan_id}`);
    },
    onError: toastError,
  });

  function review(e: React.FormEvent) {
    e.preventDefault();
    const errs: Record<string, string> = {};
    if (!form.customer_id) errs.customer_id = "Customer ID is required";
    if (!form.principal_amt || Number(form.principal_amt) <= 0) errs.principal_amt = "Principal must be greater than 0";
    if (!isOnetime && (!form.installment_amount || !form.total_no_of_kist)) errs.installment_amount = "Installment and kist count are required";
    if (split) errs.owner_amount = split;
    setErrors(errs);
    if (Object.keys(errs).length === 0) setConfirming(true);
  }

  return (
    <div>
      <PageHeader title="New loan" actions={<Link href="/loans" className="text-[10px] underline">Back</Link>} />
      <form onSubmit={review} className="grid gap-4 lg:grid-cols-2">
        <Card title="Borrower & terms">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Customer ID" error={errors.customer_id}><Input value={form.customer_id} onChange={set("customer_id")} required /></Field>
            <Field label="Loan type">
              <Select value={form.loan_type} onChange={set("loan_type")}>
                <option value="EMI">EMI</option><option value="MONTHLY_INTEREST">MI</option><option value="ONETIME">OT</option>
              </Select>
            </Field>
            <Field label="Principal (₹)" error={errors.principal_amt}><Input type="number" step="0.01" value={form.principal_amt} onChange={set("principal_amt")} required /></Field>
            <Field label="Rate of interest (%)" hint="Default 2%"><Input type="number" step="0.01" value={form.rate_of_interest} onChange={set("rate_of_interest")} /></Field>
            <Field label="Borrowing date"><Input type="date" value={form.borrowing_date} onChange={set("borrowing_date")} /></Field>
            <Field label="Parent loan ID (optional)"><Input value={form.loan_parent_id} onChange={set("loan_parent_id")} /></Field>
            {!isOnetime && (
              <>
                <Field label="Installment amount (₹)" error={errors.installment_amount}><Input type="number" step="0.01" value={form.installment_amount} onChange={set("installment_amount")} /></Field>
                <Field label="Number of kists"><Input type="number" value={form.total_no_of_kist} onChange={set("total_no_of_kist")} /></Field>
              </>
            )}
            <Field label="Processing fee (₹)"><Input type="number" step="0.01" value={form.processing_fee} onChange={set("processing_fee")} /></Field>
            <Field label="Purpose"><Input value={form.loan_purpose} onChange={set("loan_purpose")} /></Field>
          </div>
          {maturity && <p className="mt-3 text-[10px] text-slate-600">Last installment (approx.): {maturity}</p>}
        </Card>

        <Card title="Capital split">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Manager name"><Input value={form.manager_name} onChange={set("manager_name")} /></Field>
            <Field label="Manager amount (₹)"><Input type="number" step="0.01" value={form.manager_amount} onChange={set("manager_amount")} /></Field>
            <Field label="Owner name"><Input value={form.owner_name} onChange={set("owner_name")} /></Field>
            <Field label="Owner amount (₹)" error={errors.owner_amount}><Input type="number" step="0.01" value={form.owner_amount} onChange={set("owner_amount")} /></Field>
          </div>
          <p className={`mt-3 text-[10px] ${split ? "text-red-600" : "text-emerald-700"}`}>
            {split ?? `Split balances: ${formatINR(Number(form.manager_amount) + Number(form.owner_amount))} of ${formatINR(Number(form.principal_amt) || 0)}`}
          </p>
          <div className="mt-6 flex justify-end"><Button variant="primary" type="submit">Review loan</Button></div>
        </Card>
      </form>

      {confirming && (
        <Card title="Confirm loan" className="mt-4">
          <DryRunBanner show={false} />
          <p className="mb-3 text-[10px]">
            Create a {LOAN_TYPE_LABEL[form.loan_type as keyof typeof LOAN_TYPE_LABEL] ?? form.loan_type} loan of <strong>{formatINR(Number(form.principal_amt))}</strong> for customer #{form.customer_id} at {form.rate_of_interest}% from {form.borrowing_date}?
          </p>
          <div className="flex gap-2">
            <Button variant="primary" onClick={() => create.mutate()} disabled={create.isPending}>Confirm & save</Button>
            <Button onClick={() => setConfirming(false)}>Edit</Button>
          </div>
        </Card>
      )}
    </div>
  );
}
