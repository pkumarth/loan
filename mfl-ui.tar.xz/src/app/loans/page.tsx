"use client";

import Link from "next/link";
import { useState } from "react";
import { PageHeader, Button, TableWrap, th, td, amt, Empty, Pagination, StatusBadge, Input, Select } from "@/components/shared/ui";
import { useList } from "@/lib/use-list";
import { useAddressLookup, useCustomerLookup } from "@/lib/lookups";
import { accruedInterest, formatWhole, formatDate, LOAN_TYPE_LABEL, todayISO } from "@/lib/formatters";
import type { Loan } from "@/types/mfl-api";

const DASH = "—";

export default function LoansPage() {
  const [page, setPage] = useState(1);
  const [type, setType] = useState("");
  const [status, setStatus] = useState("");
  const [account, setAccount] = useState("");
  const list = useList<Loan>("/loans", {
    page, size: 50,
    loan_type: type || undefined,
    loan_status: status || undefined,
    loan_account_no: account || undefined,
  });
  const customers = useCustomerLookup();
  const addresses = useAddressLookup();

  const rows = list.data?.data ?? [];
  const today = todayISO();

  return (
    <div>
      <PageHeader title="Loans Portfolio" actions={<Link href="/loans/new"><Button variant="primary">New loan</Button></Link>}>
        <div className="flex flex-wrap gap-2">
          <Input placeholder="Account no" value={account} onChange={(e) => { setAccount(e.target.value); setPage(1); }} />
          <Select value={type} onChange={(e) => { setType(e.target.value); setPage(1); }}>
            <option value="">All types</option>
            <option value="EMI">EMI</option><option value="MONTHLY_INTEREST">MI</option><option value="ONETIME">OT</option>
          </Select>
          <Select value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }}>
            <option value="">All statuses</option>
            <option>ACTIVE</option><option>CLOSED</option><option>DRAFT</option><option>RESTRUCTURED</option><option>DEFAULTED</option>
          </Select>
        </div>
      </PageHeader>

      {list.data && rows.length === 0 ? <Empty>No loans match these filters.</Empty> : (
        <TableWrap>
          <thead>
            <tr>
              <th className={th}>Loan ID</th>
              <th className={th}>Customer</th>
              <th className={th}>Guarantor</th>
              <th className={th}>Mohalla</th>
              <th className={th}>Mobile</th>
              <th className={`${th} text-right`}>Principal</th>
              <th className={`${th} text-right`}>Rate</th>
              <th className={th}>Borrowing date</th>
              <th className={th}>Loan type</th>
              <th className={th}>EMI start</th>
              <th className={th}>First installment</th>
              <th className={th}>Last installment</th>
              <th className={`${th} text-right`}>Kists</th>
              <th className={`${th} text-right`}>Installment amt</th>
              <th className={`${th} text-right`}>Interest</th>
              <th className={th}>Loan status</th>
              <th className={th}>Manager</th>
              <th className={th}>Owner</th>
              <th className={`${th} text-right`}>Processing fee</th>
              <th className={th}>Purpose</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((l) => {
              const customer = customers.byId.get(l.customer_id);
              const address = customer ? addresses.byId.get(customer.address_id) : undefined;
              const guarantor = l.guarantor_id ? customers.byId.get(l.guarantor_id) : undefined;
              return (
                <tr key={l.loan_id} className="hover:bg-slate-50">
                  <td className={td}><Link className="underline" href={`/loans/${l.loan_id}/fields`}>{l.loan_id}</Link></td>
                  <td className={td}>{customer?.customer_name ?? `#${l.customer_id}`}</td>
                  <td className={td}>{guarantor?.customer_name ?? (l.guarantor_id ? `#${l.guarantor_id}` : DASH)}</td>
                  <td className={td}>{address?.mohalla ?? DASH}</td>
                  <td className={td}>{customer?.customer_mobile ?? DASH}</td>
                  <td className={amt}>{formatWhole(l.rem_principal_amt)}</td>
                  <td className={amt}>{l.rate_of_interest}</td>
                  <td className={td}>{formatDate(l.modified_borrowing_date)}</td>
                  <td className={td}>{LOAN_TYPE_LABEL[l.loan_type]}</td>
                  <td className={td}>{formatDate(l.emi_start_date)}</td>
                  <td className={td}>{formatDate(l.emi_first_installment_date)}</td>
                  <td className={td}>{formatDate(l.emi_last_installment_date)}</td>
                  <td className={amt}>{l.total_no_of_kist}</td>
                  <td className={amt}>{formatWhole(l.installment_amount)}</td>
                  <td className={amt}>{l.loan_type === "EMI" ? DASH : formatWhole(accruedInterest(l.rem_principal_amt, l.rate_of_interest, l.modified_borrowing_date, today))}</td>
                  <td className={td}><StatusBadge status={l.loan_status} /></td>
                  <td className={amt}>{formatWhole(l.manager_amount)}</td>
                  <td className={amt}>{formatWhole(l.owner_amount)}</td>
                  <td className={amt}>{formatWhole(l.processing_fee)}</td>
                  <td className={td}>{l.loan_purpose ?? DASH}</td>
                </tr>
              );
            })}
          </tbody>
        </TableWrap>
      )}
      <Pagination page={page} totalPages={list.data?.pagination?.total_pages ?? 1} onChange={setPage} />
    </div>
  );
}
