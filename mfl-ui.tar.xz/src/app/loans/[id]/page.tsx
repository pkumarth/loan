"use client";

import Link from "next/link";
import { use } from "react";
import { useQuery } from "@tanstack/react-query";
import { PageHeader, Card, Empty, StatusBadge } from "@/components/shared/ui";
import { InlinePatchCell } from "@/components/shared/inline-patch-cell";
import { api } from "@/lib/api-client";
import { useList } from "@/lib/use-list";
import { formatINR, formatDate, LOAN_TYPE_LABEL } from "@/lib/formatters";
import type { Loan, ScheduleRow } from "@/types/mfl-api";
import { ScheduleTable } from "@/components/shared/schedule-table";

export default function LoanDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const loan = useQuery({ queryKey: ["/loans", id], queryFn: () => api<Loan>(`/loans/${id}`) });
  const schedules = useList<ScheduleRow>("/payment-schedules", { loan_id: id, size: 100 });
  const l = loan.data?.data;
  const invalidate = [["/loans", id]];

  return (
    <div>
      <PageHeader title={l ? `Loan ${l.loan_account_no}` : `Loan ${id}`} actions={<Link href="/loans" className="text-[10px] underline">Back</Link>}>
        {l && <div className="flex gap-2 text-[10px]"><StatusBadge status={l.loan_type} label={LOAN_TYPE_LABEL[l.loan_type]} /><StatusBadge status={l.loan_status} /></div>}
      </PageHeader>
      {loan.isError && <Empty>Loan not found.</Empty>}
      {l && (
        <div className="mb-6 grid gap-4 md:grid-cols-2">
          <Card title="Loan">
            <dl className="grid grid-cols-2 gap-2 text-[10px]">
              <dt className="text-slate-500">Customer ID</dt><dd>{l.customer_id}</dd>
              <dt className="text-slate-500">Principal (remaining)</dt><dd>{formatINR(l.rem_principal_amt)}</dd>
              <dt className="text-slate-500">Rate of interest</dt><dd>{l.rate_of_interest}%</dd>
              <dt className="text-slate-500">Borrowed on</dt><dd>{formatDate(l.borrowing_date)}</dd>
              <dt className="text-slate-500">Installment</dt><dd>{formatINR(l.installment_amount)}</dd>
              <dt className="text-slate-500">Kists</dt><dd>{l.total_no_of_kist}</dd>
              <dt className="text-slate-500">Purpose</dt>
              <dd><InlinePatchCell value={l.loan_purpose} path={`/loans/${id}`} field="loan_purpose" invalidate={invalidate} /></dd>
              <dt className="text-slate-500">Loan status</dt>
              <dd><InlinePatchCell value={l.loan_status} path={`/loans/${id}`} field="loan_status" invalidate={invalidate} /></dd>
            </dl>
          </Card>
          <Card title="Capital split">
            <dl className="grid grid-cols-2 gap-2 text-[10px]">
              <dt className="text-slate-500">Manager</dt><dd>{l.manager_name ?? "—"} · {formatINR(l.manager_amount)}</dd>
              <dt className="text-slate-500">Owner</dt><dd>{l.owner_name ?? "—"} · {formatINR(l.owner_amount)}</dd>
              <dt className="text-slate-500">Processing fee</dt><dd>{formatINR(l.processing_fee)}</dd>
            </dl>
          </Card>
        </div>
      )}
      <Card title="Installments">
        <ScheduleTable rows={schedules.data?.data ?? []} empty="No installments yet. Use Kist & Monthly Collections to generate them." />
      </Card>
    </div>
  );
}
