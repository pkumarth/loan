"use client";

import Link from "next/link";
import { use, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, Pencil } from "lucide-react";
import { PageHeader, Card, Button, Empty, Input, Select, TableWrap, th, td } from "@/components/shared/ui";
import { api } from "@/lib/api-client";
import { toastError, toastSuccess } from "@/components/providers";
import { formatDate, formatWhole } from "@/lib/formatters";
import { label } from "@/lib/form-utils";
import type { Loan } from "@/types/mfl-api";

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const MONEY_KEY_RE = /amount|principal|fee|interest|income|loan$/;

// Fields the operator may edit inline. Capital amounts and principal are excluded because
// manager + owner must always equal principal, so they cannot change one at a time here.
const EDITABLE: Record<string, { kind: "text" | "number" | "status" }> = {
  loan_status: { kind: "status" },
  loan_purpose: { kind: "text" },
  description: { kind: "text" },
  rate_of_interest: { kind: "number" },
  processing_fee: { kind: "number" },
  manager_name: { kind: "text" },
  owner_name: { kind: "text" },
};

const STATUSES = ["DRAFT", "ACTIVE", "CLOSED", "RESTRUCTURED", "DEFAULTED"];

/** Renders one API value: dates as "14 Nov 2026", money as whole rupees, null as a dash. */
function display(key: string, value: unknown): string {
  if (value === null || value === undefined || value === "") return "—";
  if (typeof value === "string" && DATE_RE.test(value)) return formatDate(value);
  if (typeof value === "number") return MONEY_KEY_RE.test(key) ? formatWhole(value) : String(value);
  if (typeof value === "object") return JSON.stringify(value);
  return String(value);
}

export default function LoanFieldsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const qc = useQueryClient();
  const loan = useQuery({ queryKey: ["/loans", id], queryFn: () => api<Loan>(`/loans/${id}`) });
  const l = loan.data?.data as unknown as Record<string, unknown> | undefined;
  const [editing, setEditing] = useState<string | null>(null);
  const [draft, setDraft] = useState("");

  const save = useMutation({
    mutationFn: ({ field, value }: { field: string; value: string | number | null }) =>
      api(`/loans/${id}`, { method: "PATCH", body: { [field]: value } }),
    onSuccess: (_res, { field }) => {
      toastSuccess(`${label(field)} updated`);
      setEditing(null);
      qc.invalidateQueries({ queryKey: ["/loans"] });
    },
    onError: toastError,
  });

  function startEdit(key: string, value: unknown) {
    setEditing(key);
    setDraft(value === null || value === undefined ? "" : String(value));
  }

  function commit(key: string) {
    const kind = EDITABLE[key].kind;
    const value = kind === "number" ? (draft === "" ? null : Number(draft)) : draft.trim() === "" ? null : draft.trim();
    save.mutate({ field: key, value });
  }

  function renderEditor(key: string) {
    const kind = EDITABLE[key].kind;
    if (kind === "status") {
      return (
        <Select value={draft} onChange={(e) => setDraft(e.target.value)} autoFocus className="min-w-32">
          {STATUSES.map((s) => <option key={s}>{s}</option>)}
        </Select>
      );
    }
    return (
      <Input
        autoFocus
        type={kind === "number" ? "number" : "text"}
        step={kind === "number" ? "0.01" : undefined}
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        onKeyDown={(e) => e.key === "Escape" && setEditing(null)}
        className="min-w-40"
      />
    );
  }

  return (
    <div>
      <PageHeader
        title={l ? `Loan ${l.loan_account_no}` : `Loan ${id}`}
        actions={
          <Link href="/loans" aria-label="Back to loans" className="inline-flex items-center gap-1 rounded px-2 py-1 text-sm hover:bg-slate-100">
            <ArrowLeft className="h-4 w-4" /> Back
          </Link>
        }
      />
      {loan.isError && <Empty>Loan not found.</Empty>}
      {l && (
        <Card title="All fields">
          <TableWrap>
            <thead>
              <tr>
                <th className={th}>Field</th>
                <th className={th}>Value</th>
                <th className={th}></th>
              </tr>
            </thead>
            <tbody>
              {Object.entries(l).map(([key, value]) => {
                const editable = key in EDITABLE;
                const isEditing = editing === key;
                return (
                  <tr key={key} className="hover:bg-slate-50">
                    <td className={td}>{label(key)}</td>
                    <td className={td}>{isEditing ? renderEditor(key) : display(key, value)}</td>
                    <td className={td}>
                      {editable && !isEditing && (
                        <button
                          className="rounded p-1 hover:bg-slate-200"
                          aria-label={`Edit ${label(key)}`}
                          title="Edit"
                          onClick={() => startEdit(key, value)}
                        >
                          <Pencil className="h-3 w-3" />
                        </button>
                      )}
                      {isEditing && (
                        <div className="flex gap-1">
                          <Button variant="primary" onClick={() => commit(key)} disabled={save.isPending}>Save</Button>
                          <Button onClick={() => setEditing(null)}>Cancel</Button>
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </TableWrap>
        </Card>
      )}
    </div>
  );
}
