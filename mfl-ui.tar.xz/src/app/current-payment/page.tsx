"use client";

import { useState } from "react";
import { CollectModal, MODES } from "@/components/shared/collect-modal";
import { Pencil } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { PageHeader, Card, Button, Field, Input, Select, Modal, TableWrap, th, td, amt, Empty, Pagination, StatusBadge } from "@/components/shared/ui";
import { api } from "@/lib/api-client";
import { toastError, toastSuccess } from "@/components/providers";
import { useList } from "@/lib/use-list";
import { formatDate, formatINR, formatWhole } from "@/lib/formatters";
import { useScheduleLookup } from "@/lib/lookups";
import type { PaymentRecord, ScheduleRow } from "@/types/mfl-api";

const DASH = "—";

// Receipts ledger columns, in the order the payments table shows them.
const RECEIPT_COLUMNS: { key: string; header: string; money?: boolean }[] = [
  { key: "payment_id", header: "Payment ID" },
  { key: "payment_schedule_id", header: "Schedule ID" },
  { key: "loan_id", header: "Loan ID" },
  { key: "customer_name", header: "Customer name" },
  { key: "mohalla", header: "Mohalla" },
  { key: "current_kist_no", header: "Current kist" },
  { key: "installment_date", header: "Installment date" },
  { key: "payment_amount", header: "Payment amount", money: true },
  { key: "payment_date", header: "Payment date" },
  { key: "payment_mode", header: "Payment mode" },
  { key: "payment_status", header: "Payment status" },
  { key: "payer_name", header: "Payer name" },
  { key: "manager_name", header: "Manager" },
  { key: "manager_received_amount", header: "Manager received", money: true },
  { key: "owner_name", header: "Owner" },
  { key: "owner_received_amount", header: "Owner received", money: true },
  { key: "receipt_no", header: "Receipt no" },
  { key: "transaction_ref", header: "Transaction ref" },
  { key: "remarks", header: "Remarks" },
];

type Tab = "receipts" | "dues";
const TABS: { key: Tab; label: string }[] = [
  { key: "receipts", label: "Payments receipt ledger" },
  { key: "dues", label: "Payments Due ledger" },
];

export default function CurrentPaymentPage() {
  const [tab, setTab] = useState<Tab>("receipts");
  return (
    <div className="space-y-6">
      <PageHeader title="Current-Payment" />
      <div className="flex gap-2 border-b border-slate-200" role="tablist" aria-label="Payments">
        {TABS.map((t) => (
          <button
            key={t.key}
            role="tab"
            aria-selected={tab === t.key}
            aria-current={tab === t.key ? "page" : undefined}
            onClick={() => setTab(t.key)}
            className={`-mb-px border-b-2 px-3 py-2 text-sm ${
              tab === t.key ? "border-indigo-600 font-semibold text-indigo-700" : "border-transparent text-slate-600 hover:text-slate-900"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>
      {tab === "receipts" ? <ReceiptsSection /> : <DuesSection />}
    </div>
  );
}

/** Section A: calculated payables from the kist ledger. */
function DuesSection() {
  const [page, setPage] = useState(1);
  const [status, setStatus] = useState("OPEN");
  const [selected, setSelected] = useState<ScheduleRow | null>(null);
  const list = useList<ScheduleRow>("/payment-schedules", { page, size: 50, status });

  return (
    <Card title="Calculated current payables">
      <div className="mb-3 flex items-center gap-2">
        <Select value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }} aria-label="Dues status">
          <option>OPEN</option><option>PARTIAL</option><option>OVERDUE</option>
        </Select>
        <span className="text-[10px] text-slate-500">{list.data?.pagination?.total_elements ?? 0} installments</span>
      </div>
      {list.data && list.data.data.length === 0 ? <Empty>No {status} installments.</Empty> : (
        <TableWrap>
          <thead>
            <tr>
              <th className={th}>Loan</th><th className={th}>Borrower</th><th className={th}>Kist</th>
              <th className={th}>Installment date</th><th className={th}>Status</th>
              <th className={`${th} text-right`}>Installment</th><th className={`${th} text-right`}>Paid</th>
              <th className={`${th} text-right`}>Balance due</th><th className={th}></th>
            </tr>
          </thead>
          <tbody>
            {(list.data?.data ?? []).map((r) => (
              <tr key={r.payment_schedule_id} className="hover:bg-slate-50">
                <td className={td}>#{r.loan_id}</td>
                <td className={td}>{r.customer_name}</td>
                <td className={td}>{r.current_kist_no} / {r.total_no_of_kist}</td>
                <td className={td}>{formatDate(r.installment_date)}</td>
                <td className={td}><StatusBadge status={r.status} /></td>
                <td className={amt}>{formatINR(r.installment_amount)}</td>
                <td className={amt}>{formatINR(r.amount_paid)}</td>
                <td className={amt}>{formatINR(r.balance_due)}</td>
                <td className={td}>
                  <Button variant="primary" onClick={() => setSelected(r)}>Collect Now</Button>
                </td>
              </tr>
            ))}
          </tbody>
        </TableWrap>
      )}
      <Pagination page={page} totalPages={list.data?.pagination?.total_pages ?? 1} onChange={setPage} />

      {selected && (
        <CollectModal key={selected.payment_schedule_id} schedule={selected} onClose={() => setSelected(null)} />
      )}
    </Card>
  );
}

/** Section B: immutable receipts ledger. Only status can change (reversal). */
function ReceiptsSection() {
  const qc = useQueryClient();
  const [page, setPage] = useState(1);
  const [status, setStatus] = useState("");
  const [mode, setMode] = useState("");
  const list = useList<PaymentRecord>("/payments", {
    page, size: 50, payment_status: status || undefined, payment_mode: mode || undefined,
  });
  const rows = list.data?.data ?? [];
  const schedules = useScheduleLookup();

  const [editing, setEditing] = useState<PaymentRecord | null>(null);
  const [remarks, setRemarks] = useState("");

  const saveRemarks = useMutation({
    mutationFn: ({ id, value }: { id: number; value: string | null }) =>
      api<PaymentRecord>(`/payments/${id}`, { method: "PATCH", body: { remarks: value } }),
    onSuccess: (res) => {
      toastSuccess(`Receipt ${res.data.receipt_no} updated`);
      setEditing(null);
      qc.invalidateQueries({ queryKey: ["/payments"] });
    },
    onError: toastError,
  });

  function openEdit(r: PaymentRecord) {
    setEditing(r);
    setRemarks(r.remarks ?? "");
  }

  return (
    <Card title="Payments receipt ledger">
      <div className="mb-3 flex flex-wrap gap-2">
        <Select value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }} aria-label="Receipt status">
          <option value="">All statuses</option><option>SUCCESS</option><option>REVERSED</option><option>BOUNCED</option>
        </Select>
        <Select value={mode} onChange={(e) => { setMode(e.target.value); setPage(1); }} aria-label="Payment mode">
          <option value="">All modes</option>{MODES.map((x) => <option key={x}>{x}</option>)}
        </Select>
      </div>
      {list.data && rows.length === 0 ? <Empty>No receipts yet.</Empty> : (
        <TableWrap>
          <thead>
            <tr>
              {RECEIPT_COLUMNS.map((c) => (
                <th key={c.header} className={c.money ? `${th} text-right` : th}>{c.header}</th>
              ))}
              <th className={th}></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => {
              const sched = schedules.byId.get(r.payment_schedule_id ?? -1);
              const values: Record<string, { text: string; money?: boolean }> = {
                payment_id: { text: String(r.payment_id) },
                payment_schedule_id: { text: r.payment_schedule_id == null ? DASH : String(r.payment_schedule_id) },
                loan_id: { text: String(r.loan_id) },
                customer_name: { text: r.customer_name ?? DASH },
                mohalla: { text: sched?.mohalla ?? DASH },
                current_kist_no: { text: r.current_kist_no == null ? DASH : String(r.current_kist_no) },
                installment_date: { text: formatDate(r.installment_date) },
                payment_amount: { text: formatWhole(r.payment_amount), money: true },
                payment_date: { text: formatDate(r.payment_date) },
                payment_mode: { text: r.payment_mode },
                payment_status: { text: r.payment_status },
                payer_name: { text: r.payer_name ?? DASH },
                manager_name: { text: sched?.manager_name ?? DASH },
                manager_received_amount: { text: formatWhole(r.manager_received_amount), money: true },
                owner_name: { text: sched?.owner_name ?? DASH },
                owner_received_amount: { text: formatWhole(r.owner_received_amount), money: true },
                receipt_no: { text: r.receipt_no },
                transaction_ref: { text: r.transaction_ref ?? DASH },
                remarks: { text: r.remarks ?? DASH },
              };
              return (
                <tr key={r.payment_id} className="hover:bg-slate-50">
                  {RECEIPT_COLUMNS.map((c) => {
                    const v = values[c.key];
                    return (
                      <td key={c.key} className={v.money ? amt : td}>
                        {c.key === "payment_status" ? <StatusBadge status={r.payment_status} /> : v.text}
                      </td>
                    );
                  })}
                  <td className={td}>
                    <button className="rounded p-1 hover:bg-slate-200" aria-label={`Edit receipt ${r.receipt_no}`} title="Edit" onClick={() => openEdit(r)}>
                      <Pencil className="h-3 w-3" />
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </TableWrap>
      )}
      <Pagination page={page} totalPages={list.data?.pagination?.total_pages ?? 1} onChange={setPage} />

      <Modal open={editing !== null} title={`Edit receipt ${editing?.receipt_no ?? ""}`} onClose={() => setEditing(null)}>
        {editing && (
          <form
            className="flex flex-col gap-3"
            onSubmit={(e) => {
              e.preventDefault();
              saveRemarks.mutate({ id: editing.payment_id, value: remarks.trim() === "" ? null : remarks.trim() });
            }}
          >
            <p className="text-sm text-slate-600">
              {editing.customer_name} · {formatWhole(editing.payment_amount)} · {editing.payment_mode}
            </p>
            <Field label="Remarks" hint="Amounts, payer and reference are fixed once a receipt is saved.">
              <Input autoFocus maxLength={255} value={remarks} onChange={(e) => setRemarks(e.target.value)} />
            </Field>
            <div className="flex justify-end gap-2">
              <Button onClick={() => setEditing(null)}>Cancel</Button>
              <Button variant="primary" type="submit" disabled={saveRemarks.isPending}>Save</Button>
            </div>
          </form>
        )}
      </Modal>
    </Card>
  );
}
