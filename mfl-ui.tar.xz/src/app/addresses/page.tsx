"use client";

import Link from "next/link";
import { useState } from "react";
import { useQueryClient, useMutation } from "@tanstack/react-query";
import { PageHeader, Button, Modal, Field, Input, TableWrap, th, td, Empty, Pagination } from "@/components/shared/ui";
import { api } from "@/lib/api-client";
import { useList } from "@/lib/use-list";
import { toastError, toastSuccess } from "@/components/providers";
import type { Address } from "@/types/mfl-api";
import { label, clean } from "@/lib/form-utils";

const EMPTY = { country: "India", state: "BIHAR", district: "MADHUBANI", police_station: "", village: "", mohalla: "", ward_no: "", landmark: "", postal_code: "" };

export default function AddressesPage() {
  const [page, setPage] = useState(1);
  const [village, setVillage] = useState("");
  const [mohalla, setMohalla] = useState("");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(EMPTY);
  const qc = useQueryClient();
  const list = useList<Address>("/addresses", {
    page,
    size: 50,
    village: village || undefined,
    mohalla: mohalla || undefined,
  });

  const create = useMutation({
    mutationFn: () => api("/addresses", { method: "POST", body: clean(form) }),
    onSuccess: () => {
      toastSuccess("Address saved");
      setOpen(false);
      setForm(EMPTY);
      qc.invalidateQueries({ queryKey: ["/addresses"] });
    },
    onError: toastError,
  });

  return (
    <div>
      <PageHeader
        title="Addresses"
        actions={<Button variant="primary" onClick={() => setOpen(true)}>New address</Button>}
      >
        <div className="flex flex-wrap gap-2">
          <Input placeholder="Filter by village" value={village} onChange={(e) => { setVillage(e.target.value); setPage(1); }} />
          <Input placeholder="Filter by mohalla" value={mohalla} onChange={(e) => { setMohalla(e.target.value); setPage(1); }} />
        </div>
      </PageHeader>

      {list.data && list.data.data.length === 0 ? <Empty>No addresses found.</Empty> : (
        <TableWrap>
          <thead>
            <tr>
              {["ID", "Village", "Mohalla", "Police station", "District", "State", "Postal code"].map((h) => <th key={h} className={th}>{h}</th>)}
            </tr>
          </thead>
          <tbody>
            {(list.data?.data ?? []).map((a) => (
              <tr key={a.address_id} className="hover:bg-slate-50">
                <td className={td}><Link className="underline" href={`/addresses/${a.address_id}`}>{a.address_id}</Link></td>
                <td className={td}>{a.village ?? "—"}</td>
                <td className={td}>{a.mohalla ?? "—"}</td>
                <td className={td}>{a.police_station ?? "—"}</td>
                <td className={td}>{a.district}</td>
                <td className={td}>{a.state}</td>
                <td className={td}>{a.postal_code}</td>
              </tr>
            ))}
          </tbody>
        </TableWrap>
      )}
      <Pagination page={page} totalPages={list.data?.pagination?.total_pages ?? 1} onChange={setPage} />

      <Modal open={open} title="New address" onClose={() => setOpen(false)} wide>
        <form className="grid grid-cols-2 gap-3" onSubmit={(e) => { e.preventDefault(); create.mutate(); }}>
          {(Object.keys(EMPTY) as (keyof typeof EMPTY)[]).map((k) => (
            <Field key={k} label={label(k)}>
              <Input
                required={k === "postal_code"}
                value={form[k]}
                onChange={(e) => setForm({ ...form, [k]: e.target.value })}
              />
            </Field>
          ))}
          <div className="col-span-2 flex justify-end gap-2">
            <Button onClick={() => setOpen(false)}>Cancel</Button>
            <Button variant="primary" type="submit" disabled={create.isPending}>Save address</Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
