"use client";

import Link from "next/link";
import { use, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, Pencil } from "lucide-react";
import { PageHeader, Card, Button, Empty, Input, TableWrap, th, td } from "@/components/shared/ui";
import { api } from "@/lib/api-client";
import { toastError, toastSuccess } from "@/components/providers";
import { label } from "@/lib/form-utils";
import type { Address } from "@/types/mfl-api";

// Editable fields. Country, state and district are the region and stay fixed.
const EDITABLE = new Set(["village", "mohalla", "police_station", "ward_no", "landmark", "postal_code"]);

/** Address details. Click the pencil on a field to edit just that field (PATCH). */
export default function AddressDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const qc = useQueryClient();
  const address = useQuery({ queryKey: ["/addresses", id], queryFn: () => api<Address>(`/addresses/${id}`) });
  const a = address.data?.data as unknown as Record<string, unknown> | undefined;
  const [editing, setEditing] = useState<string | null>(null);
  const [draft, setDraft] = useState("");

  const save = useMutation({
    mutationFn: ({ field, value }: { field: string; value: string | null }) =>
      api(`/addresses/${id}`, { method: "PATCH", body: { [field]: value } }),
    onSuccess: (_res, { field }) => {
      toastSuccess(`${label(field)} updated`);
      setEditing(null);
      qc.invalidateQueries({ queryKey: ["/addresses"] });
    },
    onError: toastError,
  });

  function commit(key: string) {
    const value = draft.trim() === "" ? null : draft.trim();
    if (key === "postal_code" && value !== null && !/^.{4,12}$/.test(value)) {
      toastError(new Error("Postal code must be 4 to 12 characters"));
      return;
    }
    save.mutate({ field: key, value });
  }

  return (
    <div>
      <PageHeader
        title={a?.village ? `Village ${a.village}` : `Address ${id}`}
        actions={
          <Link href="/addresses" aria-label="Back to addresses" className="inline-flex items-center gap-1 rounded px-2 py-1 text-sm hover:bg-slate-100">
            <ArrowLeft className="h-4 w-4" /> Back
          </Link>
        }
      />
      {address.isError && <Empty>Address not found.</Empty>}
      {a && (
        <Card title="Address details">
          <TableWrap>
            <thead>
              <tr>
                <th className={th}>Field</th>
                <th className={th}>Value</th>
                <th className={th}></th>
              </tr>
            </thead>
            <tbody>
              {Object.entries(a).map(([key, value]) => {
                const editable = EDITABLE.has(key);
                const isEditing = editing === key;
                const shown = value === null || value === undefined || value === "" ? "—" : String(value);
                return (
                  <tr key={key} className="hover:bg-slate-50">
                    <td className={td}>{label(key)}</td>
                    <td className={td}>
                      {isEditing ? (
                        <Input
                          autoFocus
                          value={draft}
                          onChange={(e) => setDraft(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === "Escape") setEditing(null);
                            if (e.key === "Enter") { e.preventDefault(); commit(key); }
                          }}
                          className="min-w-40"
                        />
                      ) : shown}
                    </td>
                    <td className={td}>
                      {editable && !isEditing && (
                        <button
                          className="rounded p-1 hover:bg-slate-200"
                          aria-label={`Edit ${label(key)}`}
                          title="Edit"
                          onClick={() => { setEditing(key); setDraft(value === null || value === undefined ? "" : String(value)); }}
                        >
                          <Pencil className="h-3 w-3" />
                        </button>
                      )}
                      {isEditing && (
                        <div className="flex gap-1">
                          <Button variant="primary" onClick={() => commit(key)} disabled={save.isPending}>Save</Button>
                          <Button onClick={() => setEditing(null)}>Cancel</Button>
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </TableWrap>
        </Card>
      )}
    </div>
  );
}
