"use client";

import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { PageHeader, Card, Button, Field, Input, TableWrap, th, td, amt, Empty, DryRunBanner, Pagination } from "@/components/shared/ui";
import { api, Envelope } from "@/lib/api-client";
import { toastError, toastSuccess } from "@/components/providers";
import { formatINR, formatDate, todayISO } from "@/lib/formatters";
import type { OnetimeDryRunItem, OnetimeSettlementResult } from "@/types/mfl-api";

export default function OnetimePage() {
  const [hisab, setHisab] = useState(todayISO());
  const [page, setPage] = useState(1);
  const [loanId, setLoanId] = useState("");
  const [manager, setManager] = useState("0");
  const [owner, setOwner] = useState("0");
  const [forgive, setForgive] = useState("0");
  const [payer, setPayer] = useState("");
  const [preview, setPreview] = useState<OnetimeSettlementResult | null>(null);
  const [saved, setSaved] = useState<OnetimeSettlementResult | null>(null);
  const [board, setBoard] = useState<Envelope<OnetimeDryRunItem[]> | null>(null);
  const qc = useQueryClient();

  // Dry run for all active ONETIME loans (server-side paginated; each page is a POST).
  const runAll = useMutation({
    mutationFn: (p: number) =>
      api<OnetimeDryRunItem[]>("/payment-schedules/onetime-dry-run", {
        method: "POST",
        body: { hisab_date: hisab },
        query: { page: p, size: 50 },
      }),
    onSuccess: (res) => setBoard(res),
    onError: toastError,
  });
  const goToPage = (p: number) => {
    setPage(p);
    runAll.mutate(p);
  };

  const settlePayload = (dry: boolean) => ({
    loan_id: Number(loanId),
    hisab_date: hisab,
    dry_run: dry,
    manager_received_amount: Number(manager || 0),
    owner_received_amount: Number(owner || 0),
    forgive_amount: Number(forgive || 0),
    payer_name: payer || null,
  });

  const settle = useMutation({
    mutationFn: (dry: boolean) =>
      api<OnetimeSettlementResult>("/payment-schedules/onetime-settlement", { method: "POST", body: settlePayload(dry) }),
    onSuccess: (res, dry) => {
      if (dry) {
        setPreview(res.data);
        setSaved(null);
      } else {
        setSaved(res.data);
        setPreview(null);
        toastSuccess("Settlement recorded");
        qc.invalidateQueries({ queryKey: ["/payment-schedules"] });
        qc.invalidateQueries({ queryKey: ["/loans"] });
      }
    },
    onError: toastError,
  });

  const canSettle = loanId !== "" && Number(loanId) > 0;

  return (
    <div>
      <PageHeader title="Onetime Hisab & Settlement" />
      <div className="grid gap-4 xl:grid-cols-2">
        <Card title="Dry run — all active OT loans">
          <div className="mb-3 flex flex-wrap items-end gap-2">
            <Field label="Hisab date"><Input type="date" value={hisab} onChange={(e) => setHisab(e.target.value)} /></Field>
            <Button variant="primary" onClick={() => goToPage(1)} disabled={runAll.isPending}>Run dry run</Button>
          </div>
          <DryRunBanner />
          {board && board.data.length === 0 ? <Empty>No active OT loans.</Empty> : (
            <>
              <TableWrap>
                <thead>
                  <tr>
                    <th className={th}>Loan</th><th className={th}>Borrower</th><th className={th}>Guardian</th>
                    <th className={`${th} text-right`}>Principal</th><th className={`${th} text-right`}>Days</th>
                    <th className={`${th} text-right`}>Per day</th><th className={`${th} text-right`}>Interest</th>
                    <th className={`${th} text-right`}>Total due</th>
                  </tr>
                </thead>
                <tbody>
                  {(board?.data ?? []).map((r) => (
                    <tr key={r.loan_id} className="cursor-pointer hover:bg-slate-50" onClick={() => setLoanId(String(r.loan_id))}>
                      <td className={td}>{r.loan_account_no}</td>
                      <td className={td}>{r.customer_name}</td>
                      <td className={td}>{r.guardian_name}</td>
                      <td className={amt}>{formatINR(r.rem_principal_amt)}</td>
                      <td className={amt}>{r.days}</td>
                      <td className={amt}>{formatINR(r.per_day_interest)}</td>
                      <td className={amt}>{formatINR(r.interest_amount)}</td>
                      <td className={amt}>{formatINR(r.total_due)}</td>
                    </tr>
                  ))}
                </tbody>
              </TableWrap>
              <Pagination page={page} totalPages={board?.pagination?.total_pages ?? 1} onChange={goToPage} />
            </>
          )}
          <p className="mt-2 text-[8px] text-slate-500">Click a row to load that loan into the settlement form.</p>
        </Card>

        <Card title="Settle one loan">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Loan ID"><Input value={loanId} onChange={(e) => setLoanId(e.target.value)} /></Field>
            <Field label="Payer name"><Input value={payer} onChange={(e) => setPayer(e.target.value)} /></Field>
            <Field label="Manager received (₹)"><Input type="number" step="0.01" value={manager} onChange={(e) => setManager(e.target.value)} /></Field>
            <Field label="Owner received (₹)"><Input type="number" step="0.01" value={owner} onChange={(e) => setOwner(e.target.value)} /></Field>
            <Field label="Forgive (₹)" hint="Amount waived from the total due"><Input type="number" step="0.01" value={forgive} onChange={(e) => setForgive(e.target.value)} /></Field>
          </div>
          <div className="mt-4 flex gap-2">
            <Button onClick={() => settle.mutate(true)} disabled={!canSettle || settle.isPending}>Preview settlement</Button>
            <Button variant="primary" onClick={() => settle.mutate(false)} disabled={!canSettle || !preview || settle.isPending}>
              Confirm settlement
            </Button>
          </div>
          {preview && (
            <div className="mt-4">
              <DryRunBanner />
              <SettlementSummary r={preview} />
            </div>
          )}
          {saved && (
            <div className="mt-4 rounded border border-emerald-300 bg-emerald-50 p-3 text-[10px]">
              <div className="mb-2 font-semibold">Saved — loan status: {saved.loan_status}</div>
              <SettlementSummary r={saved} />
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}

function SettlementSummary({ r }: { r: OnetimeSettlementResult }) {
  return (
    <dl className="grid grid-cols-2 gap-2 text-[10px]">
      <dt className="text-slate-500">Guardian</dt><dd>{r.guardian_name}</dd>
      <dt className="text-slate-500">Hisab date</dt><dd>{formatDate(r.hisab_date)}</dd>
      <dt className="text-slate-500">Days</dt><dd>{r.days}</dd>
      <dt className="text-slate-500">Per day interest</dt><dd>{formatINR(r.per_day_interest)}</dd>
      <dt className="text-slate-500">Interest</dt><dd>{formatINR(r.interest_amount)}</dd>
      <dt className="text-slate-500">Total due</dt><dd className="font-semibold">{formatINR(r.total_due)}</dd>
      {!r.dry_run && (
        <>
          <dt className="text-slate-500">Amount paid</dt><dd>{formatINR(r.amount_paid)}</dd>
          <dt className="text-slate-500">Forgiven</dt><dd>{formatINR(r.forgive_amount)}</dd>
          <dt className="text-slate-500">Shortfall</dt><dd>{formatINR(r.shortfall_amount)}</dd>
          <dt className="text-slate-500">Principal returned</dt><dd>{formatINR(r.partial_principal_amt_return)}</dd>
        </>
      )}
    </dl>
  );
}
