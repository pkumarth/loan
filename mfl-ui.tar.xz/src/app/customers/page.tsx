"use client";

import Link from "next/link";
import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { PageHeader, Button, Modal, Field, Input, Select, TableWrap, th, td, amt, Empty, Pagination } from "@/components/shared/ui";
import { api } from "@/lib/api-client";
import { useList } from "@/lib/use-list";
import { useAddressLookup, useCustomerLookup } from "@/lib/lookups";
import { toastError, toastSuccess } from "@/components/providers";
import { mobileSchema } from "@/lib/validators";
import { clean, label } from "@/lib/form-utils";
import { formatWhole } from "@/lib/formatters";
import type { Customer } from "@/types/mfl-api";

const RELATIONS = ["FATHER", "HUSBAND", "MOTHER", "OTHER"];
const EMPTY = {
  customer_name: "", guardian_name: "", guardian_relation: "FATHER", guarantor_relation: "FATHER", customer_mobile: "",
  address_id: "", guarantor_id: "", guarantor_mobile: "", aadhaar_no: "", pan_no: "",
};
const DASH = "—";

export default function CustomersPage() {
  const [page, setPage] = useState(1);
  const [name, setName] = useState("");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(EMPTY);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const qc = useQueryClient();
  const list = useList<Customer>("/customers", { page, size: 50, customer_name: name || undefined });
  const customers = useCustomerLookup();
  const addresses = useAddressLookup();

  const create = useMutation({
    mutationFn: () => {
      const body = clean(form);
      return api("/customers", {
        method: "POST",
        body: {
          ...body,
          address_id: Number(form.address_id),
          guarantor_id: form.guarantor_id ? Number(form.guarantor_id) : null,
        },
      });
    },
    onSuccess: () => {
      toastSuccess("Customer created");
      setOpen(false);
      setForm(EMPTY);
      qc.invalidateQueries({ queryKey: ["/customers"] });
    },
    onError: toastError,
  });

  function submit(e: React.FormEvent) {
    e.preventDefault();
    const errs: Record<string, string> = {};
    const m = mobileSchema.safeParse(form.customer_mobile);
    if (!m.success) errs.customer_mobile = m.error.issues[0].message;
    if (!form.address_id) errs.address_id = "Select an address ID";
    setErrors(errs);
    if (Object.keys(errs).length === 0) create.mutate();
  }

  const rows = list.data?.data ?? [];

  return (
    <div>
      <PageHeader
        title="Customers"
        actions={<Button variant="primary" onClick={() => setOpen(true)}>New customer</Button>}
      >
        <Input placeholder="Search by name" value={name} onChange={(e) => { setName(e.target.value); setPage(1); }} />
      </PageHeader>

      {list.data && rows.length === 0 ? <Empty>No customers found.</Empty> : (
        <TableWrap>
          <thead>
            <tr>
              <th className={th}>Customer ID</th>
              <th className={th}>Customer name</th>
              <th className={th}>Guardian name</th>
              <th className={th}>Guardian relation</th>
              <th className={th}>Customer mobile</th>
              <th className={th}>Guarantor name</th>
              <th className={th}>Guarantor relation</th>
              <th className={th}>Guarantor mobile</th>
              <th className={th}>Village</th>
              <th className={th}>Mohalla</th>
              <th className={th}>Customer status</th>
              <th className={th}>Customer rating</th>
              <th className={`${th} text-right`}>Family income</th>
              <th className={`${th} text-right`}>Family loan</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((c) => {
              const guarantor = c.guarantor_id ? customers.byId.get(c.guarantor_id) : undefined;
              const address = addresses.byId.get(c.address_id);
              return (
                <tr key={c.customer_id} className="hover:bg-slate-50">
                  <td className={td}><Link className="underline" href={`/customers/${c.customer_id}`}>{c.customer_id}</Link></td>
                  <td className={td}>{c.customer_name}</td>
                  <td className={td}>{c.guardian_name}</td>
                  <td className={td}>{c.guardian_relation}</td>
                  <td className={td}>{c.customer_mobile}</td>
                  <td className={td}>
                    {c.guarantor_id ? (
                      <Link className="underline" href={`/customers/${c.guarantor_id}`}>{guarantor?.customer_name ?? `#${c.guarantor_id}`}</Link>
                    ) : DASH}
                  </td>
                  <td className={td}>{guarantor ? guarantor.guarantor_relation ?? DASH : DASH}</td>
                  <td className={td}>{guarantor?.customer_mobile ?? DASH}</td>
                  <td className={td}>
                    {address ? <Link className="underline" href={`/addresses/${address.address_id}`}>{address.village ?? DASH}</Link> : DASH}
                  </td>
                  <td className={td}>
                    {address ? <Link className="underline" href={`/addresses/${address.address_id}`}>{address.mohalla ?? DASH}</Link> : DASH}
                  </td>
                  <td className={td}>{c.customer_status ?? DASH}</td>
                  <td className={td}>{c.customer_rating ?? DASH}</td>
                  <td className={amt}>{formatWhole(c.family_income)}</td>
                  <td className={amt}>{formatWhole(c.family_loan)}</td>
                </tr>
              );
            })}
          </tbody>
        </TableWrap>
      )}
      <Pagination page={page} totalPages={list.data?.pagination?.total_pages ?? 1} onChange={setPage} />

      <Modal open={open} title="New customer" onClose={() => setOpen(false)} wide>
        <form className="grid grid-cols-2 gap-3" onSubmit={submit}>
          {(Object.keys(EMPTY) as (keyof typeof EMPTY)[]).map((k) => (
            <Field key={k} label={label(k)} error={errors[k]}>
              {k === "guardian_relation" || k === "guarantor_relation" ? (
                <Select value={form[k]} onChange={(e) => setForm({ ...form, [k]: e.target.value })}>
                  {RELATIONS.map((r) => <option key={r}>{r}</option>)}
                </Select>
              ) : (
                <Input
                  required={["customer_name", "guardian_name", "customer_mobile", "address_id"].includes(k)}
                  value={form[k]}
                  onChange={(e) => setForm({ ...form, [k]: e.target.value })}
                />
              )}
            </Field>
          ))}
          <div className="col-span-2 flex justify-end gap-2">
            <Button onClick={() => setOpen(false)}>Cancel</Button>
            <Button variant="primary" type="submit" disabled={create.isPending}>Save customer</Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
