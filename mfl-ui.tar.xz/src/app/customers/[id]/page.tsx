"use client";

import Link from "next/link";
import { use, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, Pencil } from "lucide-react";
import { PageHeader, Card, Button, Empty, Input, Select, StatusBadge, TableWrap, th, td, amt } from "@/components/shared/ui";
import { api } from "@/lib/api-client";
import { toastError, toastSuccess } from "@/components/providers";
import { useList } from "@/lib/use-list";
import { useAddressLookup, useCustomerLookup } from "@/lib/lookups";
import { label } from "@/lib/form-utils";
import { formatDate, formatINR, formatWhole, LOAN_TYPE_LABEL } from "@/lib/formatters";
import type { Customer, Loan } from "@/types/mfl-api";

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const MONEY_KEY_RE = /income|loan$/;
const RELATIONS = ["FATHER", "HUSBAND", "MOTHER", "OTHER"];
const STATUSES = ["ACTIVE", "INACTIVE", "BLACKLISTED"];
const KYC = ["NOT_UPLOADED", "UPLOADED", "PENDING", "VERIFIED", "REJECTED"];

// Editable fields and how each is entered. Relations (address, guarantor) and identifiers are not editable here.
type Kind = "text" | "mobile" | "rating" | "money" | "relation" | "status" | "kyc";
const EDITABLE: Record<string, Kind> = {
  customer_name: "text",
  guardian_name: "text",
  guardian_relation: "relation",
  guarantor_relation: "relation",
  customer_mobile: "mobile",
  customer_email: "text",
  customer_status: "status",
  customer_rating: "rating",
  family_income: "money",
  family_loan: "money",
  kyc_status: "kyc",
};
const OPTIONS: Partial<Record<Kind, string[]>> = { relation: RELATIONS, status: STATUSES, kyc: KYC };

function display(key: string, value: unknown): string {
  if (value === null || value === undefined || value === "") return "—";
  if (typeof value === "string" && DATE_RE.test(value)) return formatDate(value);
  if (typeof value === "number") return MONEY_KEY_RE.test(key) ? formatWhole(value) : String(value);
  return String(value);
}

export default function CustomerDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const qc = useQueryClient();
  const customer = useQuery({ queryKey: ["/customers", id], queryFn: () => api<Customer>(`/customers/${id}`) });
  const loans = useList<Loan>("/loans", { customer_id: id, size: 50 });
  const customers = useCustomerLookup();
  const addresses = useAddressLookup();
  const c = customer.data?.data;
  const [editing, setEditing] = useState<string | null>(null);
  const [draft, setDraft] = useState("");

  const save = useMutation({
    mutationFn: ({ field, value }: { field: string; value: string | number | null }) =>
      api(`/customers/${id}`, { method: "PATCH", body: { [field]: value } }),
    onSuccess: (_res, { field }) => {
      toastSuccess(`${label(field)} updated`);
      setEditing(null);
      qc.invalidateQueries({ queryKey: ["/customers"] });
    },
    onError: toastError,
  });

  function startEdit(key: string, value: unknown) {
    setEditing(key);
    setDraft(value === null || value === undefined ? "" : String(value));
  }

  function commit(key: string) {
    const kind = EDITABLE[key];
    const trimmed = draft.trim();
    let value: string | number | null = trimmed === "" ? null : trimmed;
    if (kind === "rating" || kind === "money") value = trimmed === "" ? null : Number(trimmed);
    if (kind === "mobile" && value !== null && !/^\d{10}$/.test(String(value))) {
      toastError(new Error("Enter a 10-digit mobile number"));
      return;
    }
    save.mutate({ field: key, value });
  }

  function renderEditor(key: string) {
    const kind = EDITABLE[key];
    const options = OPTIONS[kind];
    if (options) {
      return (
        <Select value={draft} onChange={(e) => setDraft(e.target.value)} autoFocus className="min-w-32">
          {options.map((o) => <option key={o}>{o}</option>)}
        </Select>
      );
    }
    const type = kind === "rating" || kind === "money" ? "number" : "text";
    return (
      <Input
        autoFocus
        type={type}
        min={kind === "rating" ? 0 : undefined}
        step={kind === "money" ? "0.01" : kind === "rating" ? 1 : undefined}
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        onKeyDown={(e) => e.key === "Escape" && setEditing(null)}
        className="min-w-40"
      />
    );
  }

  /** Value cell: IDs link to their record; everything else is displayed as-is. */
  function valueCell(key: string, value: unknown) {
    if (key === "guarantor_id" && typeof value === "number") {
      const g = customers.byId.get(value);
      return <Link className="underline" href={`/customers/${value}`}>{g?.customer_name ?? `#${value}`} (#{value})</Link>;
    }
    if (key === "address_id" && typeof value === "number") {
      const a = addresses.byId.get(value);
      return <Link className="underline" href={`/addresses/${value}`}>{a?.village ?? `#${value}`} (#{value})</Link>;
    }
    if (key === "customer_status" && typeof value === "string") return <StatusBadge status={value} />;
    return display(key, value);
  }

  return (
    <div>
      <PageHeader
        title={c ? c.customer_name : `Customer ${id}`}
        actions={
          <Link href="/customers" aria-label="Back to customers" className="inline-flex items-center gap-1 rounded px-2 py-1 text-sm hover:bg-slate-100">
            <ArrowLeft className="h-4 w-4" /> Back
          </Link>
        }
      />
      {customer.isError && <Empty>Customer not found.</Empty>}
      {c && (
        <Card title="Customer details" className="mb-6">
          <TableWrap>
            <thead>
              <tr>
                <th className={th}>Field</th>
                <th className={th}>Value</th>
                <th className={th}></th>
              </tr>
            </thead>
            <tbody>
              {Object.entries(c).map(([key, value]) => {
                const editable = key in EDITABLE;
                const isEditing = editing === key;
                return (
                  <tr key={key} className="hover:bg-slate-50">
                    <td className={td}>{label(key)}</td>
                    <td className={MONEY_KEY_RE.test(key) ? amt : td}>{isEditing ? renderEditor(key) : valueCell(key, value)}</td>
                    <td className={td}>
                      {editable && !isEditing && (
                        <button className="rounded p-1 hover:bg-slate-200" aria-label={`Edit ${label(key)}`} title="Edit" onClick={() => startEdit(key, value)}>
                          <Pencil className="h-3 w-3" />
                        </button>
                      )}
                      {isEditing && (
                        <div className="flex gap-1">
                          <Button variant="primary" onClick={() => commit(key)} disabled={save.isPending}>Save</Button>
                          <Button onClick={() => setEditing(null)}>Cancel</Button>
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </TableWrap>
        </Card>
      )}

      <Card title="Loans">
        {loans.data && loans.data.data.length === 0 ? <Empty>No loans for this customer.</Empty> : (
          <TableWrap>
            <thead>
              <tr>
                {["Loan ID", "Type", "Borrowed on", "Principal", "Remaining", "Status"].map((h) => <th key={h} className={th}>{h}</th>)}
              </tr>
            </thead>
            <tbody>
              {(loans.data?.data ?? []).map((l) => (
                <tr key={l.loan_id} className="hover:bg-slate-50">
                  <td className={td}><Link className="underline" href={`/loans/${l.loan_id}/fields`}>{l.loan_id}</Link></td>
                  <td className={td}>{LOAN_TYPE_LABEL[l.loan_type]}</td>
                  <td className={td}>{formatDate(l.borrowing_date)}</td>
                  <td className={amt}>{formatINR(l.original_principal_amt_k * 1000)}</td>
                  <td className={amt}>{formatINR(l.rem_principal_amt)}</td>
                  <td className={td}><StatusBadge status={l.loan_status} /></td>
                </tr>
              ))}
            </tbody>
          </TableWrap>
        )}
      </Card>
    </div>
  );
}
