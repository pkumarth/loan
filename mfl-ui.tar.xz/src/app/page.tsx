"use client";

import Link from "next/link";
import { useQuery } from "@tanstack/react-query";
import { PageHeader, Card, Empty, StatusBadge } from "@/components/shared/ui";
import { api } from "@/lib/api-client";
import { formatDate, formatINR } from "@/lib/formatters";
import type { DashboardSummary } from "@/types/mfl-api";

export default function DashboardPage() {
  const q = useQuery({
    queryKey: ["dashboard-summary"],
    queryFn: () => api<DashboardSummary>("/dashboard/summary"),
    refetchInterval: 60_000,
  });

  if (q.isError) return <Empty>Could not load the dashboard. Check that the backend is running.</Empty>;
  const d = q.data?.data;
  if (!d) return <Empty>Loading dashboard…</Empty>;

  return (
    <div className="space-y-4">
      <PageHeader title="Executive Dashboard" actions={<span className="text-[10px] text-slate-500">As of {formatDate(d.period.as_of)}</span>} />

      {d.alerts.length > 0 && (
        <div className="space-y-2">
          {d.alerts.map((a) => (
            <div key={a.type} className="flex items-center justify-between rounded border border-amber-300 bg-amber-50 px-4 py-2 text-[10px]">
              <span>{a.message}</span>
              {a.type === "GENERATE_MONTHLY" && <Link className="font-medium underline" href="/schedules/generate">Preview dry run →</Link>}
              {a.type === "OVERDUE" && <Link className="font-medium underline" href="/operations">Run overdue compute →</Link>}
            </div>
          ))}
        </div>
      )}

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <Card title="Total active AUM">
          <div className="text-xl font-semibold tabular-nums">{formatINR(d.portfolio.active_aum)}</div>
          <div className="mt-1 text-[10px] text-slate-600">{d.portfolio.active_loans} active · {d.portfolio.closed_loans} closed</div>
          <div className="mt-1 text-[8px] text-slate-500">
            EMI {d.portfolio.product_mix.EMI ?? 0} · MI {d.portfolio.product_mix.MONTHLY_INTEREST ?? 0} · OT {d.portfolio.product_mix.ONETIME ?? 0}
          </div>
        </Card>
        <Card title="Capital deployed">
          <div className="text-xl font-semibold tabular-nums">{formatINR(d.capital.owner_deployed + d.capital.manager_deployed)}</div>
          <div className="mt-1 text-[10px] text-slate-600">Owner {formatINR(d.capital.owner_deployed)}</div>
          <div className="text-[10px] text-slate-600">Manager {formatINR(d.capital.manager_deployed)}</div>
        </Card>
        <Card title={`Collected in ${d.period.billing_month}/${d.period.billing_year}`}>
          <div className="text-xl font-semibold tabular-nums">{formatINR(d.capital.mtd_collected)}</div>
          <div className="mt-1 text-[8px] text-slate-600">Cash {formatINR(d.capital.mtd_cash)} · UPI {formatINR(d.capital.mtd_upi)}</div>
          <div className="text-[8px] text-slate-500">{d.capital.mtd_receipts} receipts</div>
        </Card>
        <Card title="Overdue & fines">
          <div className="text-xl font-semibold tabular-nums text-red-700">{formatINR(d.risk.overdue_partial_due)}</div>
          <div className="mt-1 text-[10px] text-slate-600">{d.risk.overdue_partial_kists} kists · {d.risk.overdue_partial_loans} loans</div>
          <div className="text-[8px] text-slate-500">Fines & interest {formatINR(d.risk.fines_and_interest)}</div>
        </Card>
      </div>

      <div className="grid gap-4 xl:grid-cols-2">
        <Card title="12th & 25th cycle collection">
          {(["12th", "25th"] as const).map((k) => {
            const c = d.cycles[k];
            return (
              <div key={k} className="mb-4">
                <div className="flex justify-between text-[10px]">
                  <span className="font-medium">{k} cycle</span>
                  <span className="tabular-nums">{formatINR(c.collected)} / {formatINR(c.expected)}</span>
                </div>
                <div className="mt-1 h-3 w-full rounded bg-slate-200">
                  <div className="h-3 rounded bg-emerald-600" style={{ width: `${Math.min(c.efficiency_pct, 100)}%` }} />
                </div>
                <div className="mt-1 text-[8px] text-slate-600">
                  {c.efficiency_pct}% collected · pending {formatINR(c.pending)} · {c.open_kists} open kists
                </div>
              </div>
            );
          })}
          <div className="flex gap-3 text-[10px]">
            <Link className="underline" href="/current-payment">Open Current-Payment →</Link>
            <Link className="underline" href="/schedules">Open kist ledger →</Link>
          </div>
        </Card>

        <Card title="Owner vs manager">
          <table className="w-full text-[10px]">
            <thead>
              <tr className="text-left text-slate-500">
                <th className="py-1 font-medium">Metric</th>
                <th className="py-1 text-right font-medium">Owner</th>
                <th className="py-1 text-right font-medium">Manager</th>
              </tr>
            </thead>
            <tbody className="tabular-nums">
              <tr className="border-t border-slate-100">
                <td className="py-1">Deployed capital</td>
                <td className="py-1 text-right">{formatINR(d.capital.owner_deployed)}</td>
                <td className="py-1 text-right">{formatINR(d.capital.manager_deployed)}</td>
              </tr>
              <tr className="border-t border-slate-100">
                <td className="py-1">Collected this month</td>
                <td className="py-1 text-right">{formatINR(d.capital.mtd_owner_received)}</td>
                <td className="py-1 text-right">{formatINR(d.capital.mtd_manager_received)}</td>
              </tr>
              <tr className="border-t border-slate-100">
                <td className="py-1">Processing fees</td>
                <td className="py-1 text-right" colSpan={2}>{formatINR(d.capital.processing_fees)}</td>
              </tr>
              <tr className="border-t border-slate-100">
                <td className="py-1">Forgiven (all time)</td>
                <td className="py-1 text-right" colSpan={2}>{formatINR(d.capital.total_forgiven)}</td>
              </tr>
            </tbody>
          </table>
        </Card>
      </div>

      <div className="grid gap-4 xl:grid-cols-3">
        <Card title="Top villages by pending due">
          {d.top_villages.length === 0 ? <Empty>No pending dues.</Empty> : (
            <ol className="space-y-2 text-[10px]">
              {d.top_villages.map((v, i) => (
                <li key={v.village} className="flex justify-between">
                  <span>{i + 1}. {v.village} <span className="text-slate-500">({v.loans} loans)</span></span>
                  <span className="tabular-nums">{formatINR(v.due)}</span>
                </li>
              ))}
            </ol>
          )}
          <Link className="mt-3 inline-block text-[10px] underline" href="/addresses">Address & Village dashboard →</Link>
        </Card>

        <Card title="Customers & KYC">
          <dl className="grid grid-cols-2 gap-2 text-[10px]">
            <dt className="text-slate-500">Total customers</dt><dd className="tabular-nums">{d.customers.total}</dd>
            <dt className="text-slate-500">Active borrowers</dt><dd className="tabular-nums">{d.customers.active_borrowers}</dd>
            <dt className="text-slate-500">Guarantors</dt><dd className="tabular-nums">{d.customers.guarantors}</dd>
            <dt className="text-slate-500">KYC not verified</dt><dd className="tabular-nums">{d.customers.kyc_pending}</dd>
            <dt className="text-slate-500">Blacklisted</dt><dd className="tabular-nums">{d.customers.blacklisted}</dd>
          </dl>
          <Link className="mt-3 inline-block text-[10px] underline" href="/customers">Customer directory →</Link>
        </Card>

        <Card title="Today's receipts">
          {d.todays_receipts.length === 0 ? <Empty>No receipts logged today.</Empty> : (
            <ul className="space-y-2 text-[10px]">
              {d.todays_receipts.map((r) => (
                <li key={r.receipt_no}>
                  <div className="flex justify-between">
                    <span className="font-mono text-[8px]">{r.receipt_no}</span>
                    <StatusBadge status={r.payment_status} />
                  </div>
                  <div className="text-slate-600">
                    {r.customer_name} · {formatINR(r.amount)} · {r.payment_mode}
                    {r.current_kist_no ? ` · Kist #${r.current_kist_no}` : ""}
                  </div>
                </li>
              ))}
            </ul>
          )}
          <Link className="mt-3 inline-block text-[10px] underline" href="/current-payment">Go to Current-Payment →</Link>
        </Card>
      </div>
    </div>
  );
}
