"use client";

import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Pagination } from "@/components/shared/ui";
import { CollectModal } from "@/components/shared/collect-modal";
import { ScheduleLedgerTable } from "@/components/shared/schedule-ledger";
import { useList } from "@/lib/use-list";
import { PageHeader, Card, Button, Field, Input, DryRunBanner, TableWrap, th, td, amt, StatusBadge } from "@/components/shared/ui";
import { api } from "@/lib/api-client";
import { toastError, toastSuccess } from "@/components/providers";
import { formatINR, formatDate, todayISO } from "@/lib/formatters";
import type { OverdueResult, ReportResult, ScheduleRow } from "@/types/mfl-api";
import { RecordPaymentTab } from "@/components/operations/record-payment-tab";

type Tab = "reports" | "payment";
const TABS: { key: Tab; label: string }[] = [
  { key: "reports", label: "Overdue & reports" },
  { key: "payment", label: "Record payment" },
];

export default function OperationsPage() {
  const [tab, setTab] = useState<Tab>("reports");
  const now = new Date();
  const [year, setYear] = useState(String(now.getFullYear()));
  const [month, setMonth] = useState(String(now.getMonth() + 1));
  return (
    <div>
      <PageHeader title="Overdue Engine & Reports" />
      <div className="mb-4 flex gap-2 border-b border-slate-200" role="tablist" aria-label="Operations">
        {TABS.map((t) => (
          <button
            key={t.key}
            role="tab"
            aria-selected={tab === t.key}
            aria-current={tab === t.key ? "page" : undefined}
            onClick={() => setTab(t.key)}
            className={`-mb-px border-b-2 px-3 py-2 text-sm ${
              tab === t.key ? "border-indigo-600 font-semibold text-indigo-700" : "border-transparent text-slate-600 hover:text-slate-900"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>
      {tab === "reports" ? (
        <div className="space-y-4">
          <div className="grid gap-4 xl:grid-cols-2">
            <OverdueCard />
            <ReportCard year={year} month={month} onYear={setYear} onMonth={setMonth} />
          </div>
          <ReportTable year={year} month={month} />
        </div>
      ) : (
        <RecordPaymentTab />
      )}
    </div>
  );
}

function OverdueCard() {
  const [runDate, setRunDate] = useState(todayISO());
  const [loanId, setLoanId] = useState("");
  const [result, setResult] = useState<OverdueResult | null>(null);
  const qc = useQueryClient();

  const run = useMutation({
    mutationFn: (dry: boolean) =>
      api<OverdueResult>("/payment-schedules/overdue-compute", {
        method: "POST",
        body: { run_date: runDate, loan_id: loanId ? Number(loanId) : null, dry_run: dry },
      }),
    onSuccess: (res, dry) => {
      setResult(res.data);
      if (!dry) {
        toastSuccess(`Overdue computed for ${res.data.row_count} installments`);
        qc.invalidateQueries({ queryKey: ["/payment-schedules"] });
      }
    },
    onError: toastError,
  });

  return (
    <Card title="Overdue compute (EMI & monthly interest)">
      <p className="mb-3 text-[8px] text-slate-500">
        Fine is 1% of remaining principal, applied once. Interest is 2.5/3000 per day on unpaid installment. Monthly-interest loans carry neither.
      </p>
      <div className="flex flex-wrap items-end gap-2">
        <Field label="Run date"><Input type="date" value={runDate} onChange={(e) => setRunDate(e.target.value)} /></Field>
        <Field label="Loan ID (optional)"><Input value={loanId} onChange={(e) => setLoanId(e.target.value)} className="w-28" /></Field>
        <Button onClick={() => run.mutate(true)} disabled={run.isPending}>Dry run</Button>
        <Button variant="primary" onClick={() => run.mutate(false)} disabled={run.isPending || !result}>Run & save</Button>
      </div>
      {result && (
        <div className="mt-4">
          <DryRunBanner show={result.dry_run} />
          <p className="my-2 text-[10px]">
            {result.row_count} open installments · total due <strong>{formatINR(result.total_due)}</strong>
          </p>
          <TableWrap>
            <thead>
              <tr>
                <th className={th}>Schedule</th><th className={th}>Loan</th><th className={th}>Kist date</th>
                <th className={`${th} text-right`}>Days</th><th className={`${th} text-right`}>Fine</th>
                <th className={`${th} text-right`}>Interest</th><th className={`${th} text-right`}>Due</th>
                <th className={th}>Status</th>
              </tr>
            </thead>
            <tbody>
              {result.items.map((i) => (
                <tr key={i.payment_schedule_id}>
                  <td className={td}>{i.payment_schedule_id}</td>
                  <td className={td}>{i.loan_id}</td>
                  <td className={td}>{formatDate(i.installment_date)}</td>
                  <td className={amt}>{i.days}</td>
                  <td className={amt}>{formatINR(i.fine_amount)}</td>
                  <td className={amt}>{formatINR(i.kist_interest_amount)}</td>
                  <td className={amt}>{formatINR(i.due_amount)}</td>
                  <td className={td}><StatusBadge status={i.status} /></td>
                </tr>
              ))}
            </tbody>
          </TableWrap>
        </div>
      )}
    </Card>
  );
}

function ReportCard({ year, month, onYear, onMonth }: { year: string; month: string; onYear: (v: string) => void; onMonth: (v: string) => void }) {
  const [result, setResult] = useState<ReportResult | null>(null);
  const qc = useQueryClient();

  const run = useMutation({
    mutationFn: (dry: boolean) =>
      api<ReportResult>("/payment-schedules/report-generate", {
        method: "POST",
        body: { billing_year: Number(year), billing_month: Number(month), dry_run: dry },
      }),
    onSuccess: (res, dry) => {
      setResult(res.data);
      if (!dry) {
        toastSuccess(`Report rebuilt: ${res.data.row_count} rows`);
        qc.invalidateQueries({ queryKey: ["/payment-schedules"] });
      }
    },
    onError: toastError,
  });

  return (
    <Card title="Monthly payment schedule report">
      <p className="mb-3 text-[8px] text-slate-500">
        Purges and rebuilds one row per open loan for the billing month. Closed loans are excluded.
      </p>
      <div className="flex flex-wrap items-end gap-2">
        <Field label="Year"><Input type="number" value={year} onChange={(e) => onYear(e.target.value)} className="w-28" /></Field>
        <Field label="Month"><Input type="number" min={1} max={12} value={month} onChange={(e) => onMonth(e.target.value)} className="w-20" /></Field>
        <Button onClick={() => run.mutate(true)} disabled={run.isPending}>Dry run</Button>
        <Button variant="primary" onClick={() => run.mutate(false)} disabled={run.isPending}>Generate report</Button>
      </div>
      {result && (
        <div className="mt-4 text-[10px]">
          <DryRunBanner show={result.dry_run} />
          <dl className="mt-2 grid grid-cols-2 gap-2">
            <dt className="text-slate-500">Rows</dt><dd>{result.row_count}</dd>
            <dt className="text-slate-500">Overdue amount</dt><dd>{formatINR(result.total_overdue_amount)}</dd>
            <dt className="text-slate-500">Open / overdue / closed</dt>
            <dd>{result.status_counts.OPEN} / {result.status_counts.OVERDUE} / {result.status_counts.CLOSED}</dd>
            {result.file_path && (<><dt className="text-slate-500">File</dt><dd className="break-all">{result.file_path}</dd></>)}
          </dl>
        </div>
      )}
    </Card>
  );
}

/** Full report table: every schedule row for the billing month, with Collect on each row. */
function ReportTable({ year, month }: { year: string; month: string }) {
  const [page, setPage] = useState(1);
  const [collecting, setCollecting] = useState<ScheduleRow | null>(null);
  const list = useList<ScheduleRow>("/payment-schedules", {
    page, size: 50, billing_year: Number(year) || undefined, billing_month: Number(month) || undefined,
  });
  const rows = list.data?.data ?? [];

  return (
    <Card title={`Monthly report rows — ${month}/${year}`}>
      <ScheduleLedgerTable
        rows={rows}
        empty={list.data && rows.length === 0 ? "No schedule rows for this billing month. Generate the report first." : undefined}
        rowAction={(r) => (
          <Button variant="primary" onClick={() => setCollecting(r)} disabled={r.balance_due <= 0}>Collect</Button>
        )}
      />
      <Pagination page={page} totalPages={list.data?.pagination?.total_pages ?? 1} onChange={setPage} />
      {collecting && (
        <CollectModal key={collecting.payment_schedule_id} schedule={collecting} onClose={() => setCollecting(null)} />
      )}
    </Card>
  );
}
