"use client";

import Link from "next/link";
import { use, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, Pencil } from "lucide-react";
import { PageHeader, Card, Button, Empty, Input, TableWrap, th, td } from "@/components/shared/ui";
import { api } from "@/lib/api-client";
import { toastError, toastSuccess } from "@/components/providers";
import { label } from "@/lib/form-utils";
import { formatDate, formatWhole, LOAN_TYPE_LABEL } from "@/lib/formatters";
import type { ScheduleRow } from "@/types/mfl-api";

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const MONEY_KEY_RE = /amount|principal|fine|interest|forgive|balance|return|paid|received/;

// Editable fields. Amounts paid and received come from the receipts ledger, so they stay read-only here.
type Kind = "text" | "date" | "money";
const EDITABLE: Record<string, Kind> = {
  payer_name: "text",
  manager_name: "text",
  owner_name: "text",
  installment_date: "date",
  installment_amount: "money",
  fine_amount: "money",
  other_amount: "money",
  kist_interest_amount: "money",
  forgive_amount: "money",
};

function display(key: string, value: unknown): string {
  if (value === null || value === undefined || value === "") return "—";
  if (key === "loan_type" && typeof value === "string") return LOAN_TYPE_LABEL[value as ScheduleRow["loan_type"]] ?? value;
  if (typeof value === "string" && DATE_RE.test(value)) return formatDate(value);
  if (typeof value === "number") return MONEY_KEY_RE.test(key) ? formatWhole(value) : String(value);
  return String(value);
}

/** One kist entry, every field. Click the pencil on an editable field to change just that field (PATCH). */
export default function ScheduleDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const qc = useQueryClient();
  const schedule = useQuery({
    queryKey: ["/payment-schedules", id],
    queryFn: () => api<ScheduleRow>(`/payment-schedules/${id}`),
  });
  const s = schedule.data?.data as unknown as Record<string, unknown> | undefined;
  const [editing, setEditing] = useState<string | null>(null);
  const [draft, setDraft] = useState("");

  const save = useMutation({
    mutationFn: ({ field, value }: { field: string; value: string | number | null }) =>
      api(`/payment-schedules/${id}`, { method: "PATCH", body: { [field]: value } }),
    onSuccess: (_res, { field }) => {
      toastSuccess(`${label(field)} updated`);
      setEditing(null);
      qc.invalidateQueries({ queryKey: ["/payment-schedules"] });
    },
    onError: toastError,
  });

  function commit(key: string) {
    const kind = EDITABLE[key];
    const trimmed = draft.trim();
    let value: string | number | null = trimmed === "" ? null : trimmed;
    if (kind === "money") {
      value = trimmed === "" ? null : Number(trimmed);
      if (value !== null && (!Number.isFinite(value) || value < 0)) {
        toastError(new Error("Enter an amount of 0 or more"));
        return;
      }
    }
    save.mutate({ field: key, value });
  }

  return (
    <div>
      <PageHeader
        title={s ? `Kist ${s.current_kist_no} · ${s.customer_name}` : `Schedule ${id}`}
        actions={
          <Link href="/schedules" aria-label="Back to kist ledger" className="inline-flex items-center gap-1 rounded px-2 py-1 text-sm hover:bg-slate-100">
            <ArrowLeft className="h-4 w-4" /> Back
          </Link>
        }
      />
      {schedule.isError && <Empty>Schedule entry not found.</Empty>}
      {s && (
        <Card title="Schedule details">
          <TableWrap>
            <thead>
              <tr>
                <th className={th}>Field</th>
                <th className={th}>Value</th>
                <th className={th}></th>
              </tr>
            </thead>
            <tbody>
              {Object.entries(s).map(([key, value]) => {
                const editable = key in EDITABLE;
                const isEditing = editing === key;
                const kind = EDITABLE[key];
                return (
                  <tr key={key} className="hover:bg-slate-50">
                    <td className={td}>{label(key)}</td>
                    <td className={td}>
                      {isEditing ? (
                        <Input
                          autoFocus
                          type={kind === "date" ? "date" : kind === "money" ? "number" : "text"}
                          step={kind === "money" ? "0.01" : undefined}
                          min={kind === "money" ? 0 : undefined}
                          value={draft}
                          onChange={(e) => setDraft(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === "Escape") setEditing(null);
                            if (e.key === "Enter") { e.preventDefault(); commit(key); }
                          }}
                          className="min-w-40"
                        />
                      ) : display(key, value)}
                    </td>
                    <td className={td}>
                      {editable && !isEditing && (
                        <button
                          className="rounded p-1 hover:bg-slate-200"
                          aria-label={`Edit ${label(key)}`}
                          title="Edit"
                          onClick={() => { setEditing(key); setDraft(value === null || value === undefined ? "" : String(value)); }}
                        >
                          <Pencil className="h-3 w-3" />
                        </button>
                      )}
                      {isEditing && (
                        <div className="flex gap-1">
                          <Button variant="primary" onClick={() => commit(key)} disabled={save.isPending}>Save</Button>
                          <Button onClick={() => setEditing(null)}>Cancel</Button>
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </TableWrap>
        </Card>
      )}
    </div>
  );
}
