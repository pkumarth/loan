"use client";

import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { PageHeader, Card, Button, Field, Input, DryRunBanner } from "@/components/shared/ui";
import { api } from "@/lib/api-client";
import { toastError, toastSuccess } from "@/components/providers";
import type { GenerateMonthlyResult } from "@/types/mfl-api";

export default function GenerateMonthlyPage() {
  const now = new Date();
  const [year, setYear] = useState(String(now.getFullYear()));
  const [month, setMonth] = useState(String(now.getMonth() + 1));
  const [result, setResult] = useState<GenerateMonthlyResult | null>(null);
  const [dryRun, setDryRun] = useState(true);
  const qc = useQueryClient();

  const run = useMutation({
    mutationFn: (dry: boolean) =>
      api<GenerateMonthlyResult>("/payment-schedules/generate-monthly", {
        method: "POST",
        body: { billing_year: Number(year), billing_month: Number(month), dry_run: dry },
      }),
    onSuccess: (res, dry) => {
      setResult(res.data);
      setDryRun(dry);
      if (!dry) {
        toastSuccess(`${res.data.generated_count} installments generated`);
        qc.invalidateQueries({ queryKey: ["/payment-schedules"] });
      }
    },
    onError: toastError,
  });

  return (
    <div>
      <PageHeader title="Generate monthly installments" actions={<Button onClick={() => window.history.back()}>Back</Button>} />
      <Card title="Billing period" className="max-w-xl">
        <div className="grid grid-cols-2 gap-3">
          <Field label="Year"><Input type="number" value={year} onChange={(e) => setYear(e.target.value)} /></Field>
          <Field label="Month (1–12)"><Input type="number" min={1} max={12} value={month} onChange={(e) => setMonth(e.target.value)} /></Field>
        </div>
        <div className="mt-4 flex gap-2">
          <Button variant="secondary" onClick={() => run.mutate(true)} disabled={run.isPending}>Preview (dry run)</Button>
          <Button variant="primary" onClick={() => run.mutate(false)} disabled={run.isPending || !result || !dryRun}>
            Generate
          </Button>
        </div>
        <p className="mt-2 text-[8px] text-slate-500">Generate is enabled after a preview for the same period.</p>
      </Card>

      {result && (
        <Card title="Result" className="mt-4 max-w-3xl">
          <DryRunBanner show={dryRun} />
          <dl className="mt-3 grid grid-cols-2 gap-2 text-[10px] md:grid-cols-3">
            <dt className="text-slate-500">Period</dt><dd>{result.billing_period}</dd>
            <dt className="text-slate-500">{dryRun ? "Would generate" : "Generated"}</dt><dd>{result.generated_count}</dd>
            <dt className="text-slate-500">12th cycle</dt><dd>{result.cycle_12_count}</dd>
            <dt className="text-slate-500">25th cycle</dt><dd>{result.cycle_25_count}</dd>
            <dt className="text-slate-500">Already generated</dt><dd>{result.skipped_already_generated}</dd>
            <dt className="text-slate-500">Kists completed</dt><dd>{result.skipped_kists_completed}</dd>
            <dt className="text-slate-500">Not due yet</dt><dd>{result.skipped_not_due_yet}</dd>
          </dl>
        </Card>
      )}
    </div>
  );
}
