"use client";

import Link from "next/link";
import { useState } from "react";
import { PageHeader, Button, Input, Select, Pagination, Card } from "@/components/shared/ui";
import { useList } from "@/lib/use-list";
import { cycleFor, formatWhole, todayISO } from "@/lib/formatters";
import { ScheduleLedgerTable } from "@/components/shared/schedule-ledger";
import type { ScheduleRow } from "@/types/mfl-api";

export default function SchedulesPage() {
  const [page, setPage] = useState(1);
  const [status, setStatus] = useState("");
  const [loanType, setLoanType] = useState("");
  const [date, setDate] = useState("");
  const [loanId, setLoanId] = useState("");
  const list = useList<ScheduleRow>("/payment-schedules", {
    page, size: 50,
    status: status || undefined,
    loan_type: loanType || undefined,
    installment_date: date || undefined,
    loan_id: loanId || undefined,
  });
  const rows = list.data?.data ?? [];
  const totals = rows.reduce(
    (acc, r) => ({ due: acc.due + r.balance_due, paid: acc.paid + r.amount_paid }),
    { due: 0, paid: 0 },
  );
  const reset = (fn: (v: string) => void) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    fn(e.target.value);
    setPage(1);
  };

  return (
    <div>
      <PageHeader
        title="Kist & Monthly Collections"
        actions={<Link href="/schedules/generate"><Button variant="primary">Generate monthly</Button></Link>}
      >
        <div className="flex flex-wrap gap-2">
          <Select value={status} onChange={reset(setStatus)}>
            <option value="">All statuses</option>
            <option>OPEN</option><option>PARTIAL</option><option>OVERDUE</option><option>CLOSED</option><option>WAIVED</option>
          </Select>
          <Select value={loanType} onChange={reset(setLoanType)}>
            <option value="">All types</option><option value="EMI">EMI</option><option value="MONTHLY_INTEREST">MI</option><option value="ONETIME">OT</option>
          </Select>
          <Input type="date" value={date} onChange={reset(setDate)} aria-label="Installment date" />
          <Input placeholder="Loan ID" value={loanId} onChange={reset(setLoanId)} className="w-28" />
          <Button variant="ghost" onClick={() => setDate(todayISO())}>Today</Button>
        </div>
      </PageHeader>
      <Card className="mb-4">
        <p className="text-sm">
          This page: balance due <strong>{formatWhole(totals.due)}</strong> · paid <strong>{formatWhole(totals.paid)}</strong>
          {date && <> · cycle for {date}: <strong>{cycleFor(date)}</strong></>}
        </p>
      </Card>

      <ScheduleLedgerTable
        rows={rows}
        empty={list.data && rows.length === 0 ? "No installments match these filters." : undefined}
        onLoanClick={(loan) => { setLoanId(String(loan)); setPage(1); }}
      />
      <Pagination page={page} totalPages={list.data?.pagination?.total_pages ?? 1} onChange={setPage} />
    </div>
  );
}
