"use client";

import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api-client";
import { toastError, toastSuccess } from "@/components/providers";

// Click-to-edit cell backed by a PATCH endpoint (single-field update, per the spec).
export function InlinePatchCell({
  value,
  path,
  field,
  invalidate,
  type = "text",
  display,
}: {
  value: string | number | null;
  path: string;
  field: string;
  invalidate: string[][];
  type?: "text" | "number";
  display?: string;
}) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(value === null ? "" : String(value));
  const qc = useQueryClient();
  const save = useMutation({
    mutationFn: (v: string | number) =>
      api(path, { method: "PATCH", body: { [field]: type === "number" ? Number(v) : v } }),
    onSuccess: () => {
      toastSuccess(`${field} updated`);
      invalidate.forEach((key) => qc.invalidateQueries({ queryKey: key }));
      setEditing(false);
    },
    onError: toastError,
  });

  if (!editing) {
    return (
      <button className="rounded px-1 text-left hover:bg-amber-50" onClick={() => setEditing(true)} title="Click to edit">
        {display ?? (value === null || value === "" ? "—" : String(value))}
      </button>
    );
  }
  return (
    <form
      className="flex gap-1"
      onSubmit={(e) => {
        e.preventDefault();
        save.mutate(draft);
      }}
    >
      <input
        autoFocus
        type={type}
        className="w-28 rounded border border-slate-300 px-2 py-1 text-[10px]"
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        onKeyDown={(e) => e.key === "Escape" && setEditing(false)}
      />
      <button className="rounded bg-slate-900 px-2 text-[8px] text-white" disabled={save.isPending}>Save</button>
    </form>
  );
}
