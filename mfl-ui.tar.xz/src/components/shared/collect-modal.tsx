"use client";

import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button, Field, Input, Select, Modal } from "@/components/shared/ui";
import { api } from "@/lib/api-client";
import { toastError, toastSuccess } from "@/components/providers";
import { formatDate, formatINR } from "@/lib/formatters";
import type { PaymentMode, PaymentRecord, ScheduleRow } from "@/types/mfl-api";

export const MODES: PaymentMode[] = ["CASH", "UPI", "BANK_TRANSFER", "CHEQUE"];

/** Collect a payment against one installment. One idempotency key per open, so retries cannot double-apply. */
export function CollectModal({ schedule, onClose }: { schedule: ScheduleRow; onClose: () => void }) {
  const qc = useQueryClient();
  const [idempotencyKey] = useState(() => crypto.randomUUID());
  const [manager, setManager] = useState("");
  const [owner, setOwner] = useState("");
  const [mode, setMode] = useState<PaymentMode>("CASH");
  const [ref, setRef] = useState("");
  const [payer, setPayer] = useState(schedule.payer_name ?? "");
  const [error, setError] = useState<string | null>(null);

  const m = Number(manager || 0);
  const o = Number(owner || 0);
  const total = m + o;
  const balance = schedule.balance_due;
  const after = balance - total;

  const save = useMutation({
    mutationFn: () =>
      api<PaymentRecord>("/payments", {
        method: "POST",
        body: {
          idempotency_key: idempotencyKey,
          payment_schedule_id: schedule.payment_schedule_id,
          manager_received_amount: m,
          owner_received_amount: o,
          payment_mode: mode,
          transaction_ref: ref || null,
          payer_name: payer || null,
        },
      }),
    onSuccess: (res) => {
      toastSuccess(`Receipt ${res.data.receipt_no} recorded`);
      ["/payment-schedules", "/payments", "dashboard-summary"].forEach((k) => qc.invalidateQueries({ queryKey: [k] }));
      onClose();
    },
    onError: toastError,
  });

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (total <= 0) return setError("Enter the amount received");
    if (total > balance) return setError(`Total exceeds the balance due of ${formatINR(balance)}`);
    setError(null);
    save.mutate();
  }

  return (
    <Modal open title={`Collect — Loan #${schedule.loan_id}, kist ${schedule.current_kist_no}`} onClose={onClose} wide>
      <form onSubmit={submit} className="grid gap-4 md:grid-cols-2">
        <div className="md:col-span-2 rounded bg-slate-50 p-3 text-[10px]">
          <div>Borrower: <strong>{schedule.customer_name}</strong> · Installment {formatDate(schedule.installment_date)}</div>
          <div className="mt-1 tabular-nums">
            Balance due <strong>{formatINR(balance)}</strong> · After this payment{" "}
            <strong className={after < 0 ? "text-red-700" : ""}>{formatINR(Math.max(after, 0))}</strong>
          </div>
        </div>
        <Field label="Manager received (Rs.)">
          <Input type="number" min={0} step="0.01" value={manager} onChange={(e) => setManager(e.target.value)} autoFocus />
        </Field>
        <Field label="Owner received (Rs.)">
          <Input type="number" min={0} step="0.01" value={owner} onChange={(e) => setOwner(e.target.value)} />
        </Field>
        <Field label="Payment mode">
          <Select value={mode} onChange={(e) => setMode(e.target.value as PaymentMode)}>
            {MODES.map((x) => <option key={x}>{x}</option>)}
          </Select>
        </Field>
        <Field label="Transaction reference" hint="Required for UPI, bank transfer or cheque">
          <Input value={ref} onChange={(e) => setRef(e.target.value)} />
        </Field>
        <Field label="Payer name">
          <Input value={payer} onChange={(e) => setPayer(e.target.value)} />
        </Field>
        <div className="md:col-span-2 text-[10px]">
          Payment amount: <strong className="tabular-nums">{formatINR(total)}</strong>
        </div>
        {error && <p className="md:col-span-2 text-[10px] text-red-600">{error}</p>}
        <div className="md:col-span-2 flex justify-end gap-2">
          <Button onClick={onClose}>Cancel</Button>
          <Button variant="primary" type="submit" disabled={save.isPending}>Confirm & save receipt</Button>
        </div>
      </form>
    </Modal>
  );
}

