"use client";

import Link from "next/link";
import { ReactNode } from "react";
import { TableWrap, th, td, amt, Empty, StatusBadge } from "@/components/shared/ui";
import { formatDate, formatWhole, LOAN_TYPE_LABEL } from "@/lib/formatters";
import type { ScheduleRow } from "@/types/mfl-api";

type Col = { key: keyof ScheduleRow; header: string; money?: boolean; date?: boolean; badge?: boolean; loanType?: boolean; link?: boolean; filterLoan?: boolean };

// Columns in the order the Kist & Monthly Collections table shows them.
const COLUMNS: Col[] = [
  { key: "payment_schedule_id", header: "Schedule ID", link: true },
  { key: "loan_id", header: "Loan ID", filterLoan: true },
  { key: "customer_name", header: "Customer name" },
  { key: "guardian_name", header: "Guardian name" },
  { key: "customer_mobile", header: "Customer mobile" },
  { key: "mohalla", header: "Mohalla" },
  { key: "guarantor_name", header: "Guarantor name" },
  { key: "rem_principal_amt", header: "Principal", money: true },
  { key: "rate_of_interest", header: "Rate" },
  { key: "emi_start_date", header: "EMI start", date: true },
  { key: "emi_first_installment_date", header: "First installment", date: true },
  { key: "emi_last_installment_date", header: "Last installment", date: true },
  { key: "loan_type", header: "Loan type", loanType: true },
  { key: "status", header: "Status", badge: true },
  { key: "total_no_of_kist", header: "Total kists" },
  { key: "current_kist_no", header: "Current kist" },
  { key: "installment_date", header: "Installment date", date: true },
  { key: "installment_amount", header: "Installment amt", money: true },
  { key: "fine_amount", header: "Fine", money: true },
  { key: "other_amount", header: "Other", money: true },
  { key: "partial_principal_amt_return", header: "Partial principal return", money: true },
  { key: "kist_interest_amount", header: "Kist interest", money: true },
  { key: "forgive_amount", header: "Forgive", money: true },
  { key: "payment_date", header: "Payment date", date: true },
  { key: "amount_paid", header: "Amount paid", money: true },
  { key: "remaining_principal_amt", header: "Remaining principal", money: true },
  { key: "balance_due", header: "Balance due", money: true },
  { key: "manager_name", header: "Manager" },
  { key: "manager_received_amount", header: "Manager received", money: true },
  { key: "owner_name", header: "Owner" },
  { key: "owner_received_amount", header: "Owner received", money: true },
  { key: "payer_name", header: "Payer name" },
];

const DASH = "—";

function cell(col: Col, row: ScheduleRow): React.ReactNode {
  const v = row[col.key];
  if (v === null || v === undefined || v === "") return DASH;
  if (col.badge) return <StatusBadge status={String(v)} />;
  if (col.loanType) return LOAN_TYPE_LABEL[v as ScheduleRow["loan_type"]];
  if (col.date) return formatDate(String(v));
  if (col.money) return formatWhole(Number(v));
  return String(v);
}


/**
 * Kist ledger table: the full schedule column set, in order.
 * Schedule ID links to its detail page. Loan ID calls onLoanClick, if given.
 * rowAction adds a trailing cell per row (for example a Collect button).
 */
export function ScheduleLedgerTable({
  rows,
  empty,
  onLoanClick,
  rowAction,
}: {
  rows: ScheduleRow[];
  empty?: string;
  onLoanClick?: (loanId: number) => void;
  rowAction?: (row: ScheduleRow) => ReactNode;
}) {
  if (empty) return <Empty>{empty}</Empty>;
  return (
    <TableWrap>
      <thead>
        <tr>
          {COLUMNS.map((c) => <th key={c.key} className={c.money ? `${th} text-right` : th}>{c.header}</th>)}
          {rowAction && <th className={th}></th>}
        </tr>
      </thead>
      <tbody>
        {rows.map((r) => (
          <tr key={r.payment_schedule_id} className="hover:bg-slate-50">
            {COLUMNS.map((c) => (
              <td key={c.key} className={c.money ? amt : td}>
                {c.link ? (
                  <Link className="underline" href={`/schedules/${r.payment_schedule_id}`}>{cell(c, r)}</Link>
                ) : c.filterLoan && onLoanClick ? (
                  <button className="underline" title="Show only this loan's schedules" onClick={() => onLoanClick(r.loan_id)}>
                    {cell(c, r)}
                  </button>
                ) : cell(c, r)}
              </td>
            ))}
            {rowAction && <td className={td}>{rowAction(r)}</td>}
          </tr>
        ))}
      </tbody>
    </TableWrap>
  );
}
