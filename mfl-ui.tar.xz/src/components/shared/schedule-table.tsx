import Link from "next/link";
import { Empty, StatusBadge, TableWrap, th, td, amt } from "@/components/shared/ui";
import { formatDate, formatINR } from "@/lib/formatters";
import type { ScheduleRow } from "@/types/mfl-api";

export function ScheduleTable({ rows, empty }: { rows: ScheduleRow[]; empty: string }) {
  if (rows.length === 0) return <Empty>{empty}</Empty>;
  return (
    <TableWrap>
      <thead>
        <tr>
          <th className={th}>Loan</th>
          <th className={th}>Customer</th>
          <th className={th}>Kist</th>
          <th className={th}>Installment date</th>
          <th className={th}>Status</th>
          <th className={`${th} text-right`}>Installment</th>
          <th className={`${th} text-right`}>Paid</th>
          <th className={`${th} text-right`}>Balance due</th>
        </tr>
      </thead>
      <tbody>
        {rows.map((r) => (
          <tr key={r.payment_schedule_id} className="hover:bg-slate-50">
            <td className={td}><Link className="underline" href={`/loans/${r.loan_id}`}>#{r.loan_id}</Link></td>
            <td className={td}>{r.customer_name}</td>
            <td className={td}>{r.current_kist_no} / {r.total_no_of_kist}</td>
            <td className={td}>{formatDate(r.installment_date)}</td>
            <td className={td}><StatusBadge status={r.status} /></td>
            <td className={amt}>{formatINR(r.installment_amount)}</td>
            <td className={amt}>{formatINR(r.amount_paid)}</td>
            <td className={amt}>{formatINR(r.balance_due)}</td>
          </tr>
        ))}
      </tbody>
    </TableWrap>
  );
}
