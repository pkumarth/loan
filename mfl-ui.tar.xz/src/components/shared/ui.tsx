"use client";

import { useEffect } from "react";
import { X } from "lucide-react";

export function PageHeader({ title, actions, children }: { title: string; actions?: React.ReactNode; children?: React.ReactNode }) {
  return (
    <div className="mb-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-xl font-semibold">{title}</h1>
        <div className="flex gap-2">{actions}</div>
      </div>
      {children && <div className="mt-3">{children}</div>}
    </div>
  );
}

export function Card({ title, children, className = "" }: { title?: string; children: React.ReactNode; className?: string }) {
  return (
    <section className={`rounded-lg border border-slate-200 bg-white p-4 shadow-sm ${className}`}>
      {title && <h2 className="mb-3 text-[10px] font-semibold text-slate-700">{title}</h2>}
      {children}
    </section>
  );
}

type BtnVariant = "primary" | "secondary" | "danger" | "ghost";
const BTN: Record<BtnVariant, string> = {
  primary: "bg-slate-900 text-white hover:bg-slate-700 disabled:bg-slate-400",
  secondary: "border border-slate-300 bg-white hover:bg-slate-100 disabled:text-slate-400",
  danger: "bg-red-600 text-white hover:bg-red-500 disabled:bg-red-300",
  ghost: "text-slate-700 hover:bg-slate-100",
};

export function Button({
  variant = "secondary",
  className = "",
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: BtnVariant }) {
  return (
    <button
      {...props}
      className={`inline-flex min-h-10 items-center justify-center gap-1 rounded px-3 py-2 text-[10px] font-medium disabled:cursor-not-allowed ${BTN[variant]} ${className}`}
    />
  );
}

export function Field({ label, error, children, hint }: { label: string; error?: string; children: React.ReactNode; hint?: string }) {
  return (
    <label className="flex flex-col gap-1 text-[10px]">
      <span className="font-medium text-slate-700">{label}</span>
      {children}
      {hint && !error && <span className="text-[8px] text-slate-500">{hint}</span>}
      {error && <span className="text-[8px] text-red-600">{error}</span>}
    </label>
  );
}

export const inputCls =
  "min-h-10 rounded border border-slate-300 bg-white px-3 py-2 text-[10px] tabular-nums focus:outline-2 focus:outline-slate-900";

export function Input(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={`${inputCls} ${props.className ?? ""}`} />;
}

export function Select(props: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return <select {...props} className={`${inputCls} ${props.className ?? ""}`} />;
}

const BADGE: Record<string, string> = {
  OPEN: "bg-slate-200 text-slate-800",
  PARTIAL: "bg-amber-100 text-amber-900",
  OVERDUE: "bg-red-600 text-white",
  DEFAULTED: "bg-red-600 text-white",
  CLOSED: "bg-emerald-100 text-emerald-800",
  VERIFIED: "bg-emerald-100 text-emerald-800",
  ACTIVE: "bg-emerald-100 text-emerald-800",
  WAIVED: "bg-slate-100 text-slate-600",
};

export function StatusBadge({ status, label }: { status: string; label?: string }) {
  return (
    <span className={`inline-block rounded-full px-2 py-0.5 text-[8px] font-semibold ${BADGE[status] ?? "bg-slate-100 text-slate-700"}`}>
      {label ?? status}
    </span>
  );
}

export function DryRunBanner({ show = true }: { show?: boolean }) {
  if (!show) return null;
  return (
    <div className="rounded border-2 border-dashed border-indigo-400 bg-indigo-50 px-3 py-2 text-[10px] font-medium text-indigo-800">
      DRY RUN PREVIEW — nothing is saved until you confirm.
    </div>
  );
}

export function Modal({ open, title, onClose, children, wide = false }: { open: boolean; title: string; onClose: () => void; children: React.ReactNode; wide?: boolean }) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-40 flex items-start justify-center overflow-y-auto bg-black/40 p-4" role="dialog" aria-modal="true" aria-label={title}>
      <div className={`mt-10 w-full ${wide ? "max-w-3xl" : "max-w-xl"} rounded-lg bg-white shadow-xl`}>
        <div className="flex items-center justify-between border-b border-slate-200 px-4 py-3">
          <h2 className="font-semibold">{title}</h2>
          <button onClick={onClose} className="rounded p-1 hover:bg-slate-100" aria-label="Close">
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="p-4">{children}</div>
      </div>
    </div>
  );
}

export function Pagination({ page, totalPages, onChange }: { page: number; totalPages: number; onChange: (p: number) => void }) {
  return (
    <div className="mt-3 flex items-center justify-end gap-2 text-[10px]">
      <Button onClick={() => onChange(page - 1)} disabled={page <= 1}>Prev</Button>
      <span className="tabular-nums">
        Page {page} of {Math.max(totalPages, 1)}
      </span>
      <Button onClick={() => onChange(page + 1)} disabled={page >= totalPages}>Next</Button>
    </div>
  );
}

export function Empty({ children }: { children: React.ReactNode }) {
  return <div className="py-10 text-center text-[10px] text-slate-500">{children}</div>;
}

export function TableWrap({ children }: { children: React.ReactNode }) {
  return <div className="overflow-x-auto rounded border border-slate-200 bg-white"><table className="min-w-full text-[10px]">{children}</table></div>;
}

export const th = "sticky top-0 whitespace-nowrap border-b border-amber-300 bg-amber-100 px-3 py-2 text-left text-[8px] font-semibold text-amber-950";
export const td = "whitespace-nowrap border-b border-slate-100 px-3 py-2 tabular-nums";
export const amt = "whitespace-nowrap border-b border-slate-100 px-3 py-2 text-right tabular-nums";
