"use client";

import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster, toast } from "sonner";
import { useState } from "react";
import { ApiError } from "@/lib/api-client";

// Destructive toast for any failed call; field-level messages are shown on the form by each screen.
export function toastError(err: unknown) {
  if (err instanceof ApiError) {
    if (err.httpStatus === 409 && /OPTIMISTIC_LOCK|version/i.test(String(err.cause))) {
      toast.error("This record was changed by someone else.", {
        description: "Refresh the latest data before saving again.",
      });
      return;
    }
    toast.error(err.displayMsg, { description: err.fieldMessages().join("\n") || undefined });
    return;
  }
  toast.error(err instanceof Error ? err.message : "Something went wrong");
}

export function toastSuccess(msg: string) {
  toast.success(msg);
}

export function Providers({ children }: { children: React.ReactNode }) {
  const [client] = useState(
    () =>
      new QueryClient({
        defaultOptions: { queries: { retry: 1, refetchOnWindowFocus: false, staleTime: 15_000 } },
      }),
  );
  return (
    <QueryClientProvider client={client}>
      {children}
      <Toaster richColors position="top-right" />
    </QueryClientProvider>
  );
}
