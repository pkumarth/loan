"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { CalendarClock, CheckCircle2, Home, Landmark, Users, Wallet, Settings, XCircle } from "lucide-react";
import { checkHealth } from "@/lib/api-client";
import { clearSession, getSession, type Session } from "@/lib/auth";

type Tab = {
  label: string;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
  children?: { label: string; href: string }[];
};

// Primary tabs per the UX blueprint (Section 0). Sub-tabs appear when the parent tab is active.
const TABS: Tab[] = [
  { label: "Dashboard", href: "/", icon: Home },
  {
    label: "Customer Details", href: "/customers", icon: Users,
    children: [
      { label: "Customer Dashboard", href: "/customers" },
      { label: "Address Dashboard", href: "/addresses" },
    ],
  },
  { label: "Loan", href: "/loans", icon: Landmark },
  { label: "Payment-Schedules", href: "/schedules", icon: CalendarClock },
  { label: "Current-Payment", href: "/current-payment", icon: Wallet },
  {
    label: "Hisab & Ops", href: "/onetime", icon: Settings,
    children: [
      { label: "Onetime Hisab & Settlement", href: "/onetime" },
      { label: "Overdue Engine & Reports", href: "/operations" },
    ],
  },
];

function matches(pathname: string, href: string): boolean {
  if (href === "/") return pathname === "/";
  return pathname === href || pathname.startsWith(`${href}/`);
}

function activeTab(pathname: string): Tab | undefined {
  return TABS.find((t) => matches(pathname, t.href) || (t.children ?? []).some((c) => matches(pathname, c.href)));
}

function HealthBadge() {
  const { data, isError } = useQuery({
    queryKey: ["health"],
    queryFn: checkHealth,
    refetchInterval: 60_000,
  });
  const online = data === true && !isError;
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full px-3 py-1 text-[8px] font-medium ${
        online ? "bg-emerald-100 text-emerald-800" : "bg-red-100 text-red-800"
      }`}
    >
      {online ? <CheckCircle2 className="h-3.5 w-3.5" /> : <XCircle className="h-3.5 w-3.5" />}
      {online ? "API Online" : "API Offline"}
    </span>
  );
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  // undefined = not yet read from localStorage (avoids SSR mismatch and login flash)
  const [session, setSessionState] = useState<Session | null | undefined>(undefined);

  useEffect(() => {
    const s = getSession();
    setSessionState(s);
    if (!s && pathname !== "/login") router.replace("/login");
  }, [pathname, router]);

  if (pathname === "/login") return <>{children}</>;
  if (!session) return null;

  function logout() {
    clearSession();
    setSessionState(null);
    router.replace("/login");
  }

  const current = activeTab(pathname);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <header className="border-b border-slate-200 bg-white">
        <div className="flex items-center justify-between px-6 py-3">
          <div className="flex items-center gap-4">
            <span className="text-sm font-semibold">MFL CORE</span>
            <HealthBadge />
          </div>
          <div className="flex items-center gap-3 text-[10px] text-slate-600">
            <span>
              {session.role}: <strong>{session.name}</strong>
            </span>
            <button onClick={logout} className="rounded border border-slate-300 px-2 py-1 hover:bg-slate-100">
              Logout
            </button>
          </div>
        </div>
        <nav className="flex gap-1 overflow-x-auto px-4" aria-label="Primary tabs">
          {TABS.map(({ label, href, icon: Icon }) => {
            const active = current?.href === href;
            return (
              <Link
                key={href}
                href={href}
                aria-current={active ? "page" : undefined}
                className={`flex shrink-0 items-center gap-2 border-b-2 px-3 py-2 text-[10px] ${
                  active ? "border-indigo-600 font-semibold text-indigo-700" : "border-transparent text-slate-600 hover:text-slate-900"
                }`}
              >
                <Icon className="h-4 w-4" />
                {label}
              </Link>
            );
          })}
        </nav>
        {current?.children && (
          <div className="flex gap-2 border-t border-slate-100 bg-slate-50 px-6 py-2" aria-label="Sub-tabs">
            {current.children.map((c) => (
              <Link
                key={c.href}
                href={c.href}
                className={`rounded-full px-3 py-1 text-[10px] ${
                  matches(pathname, c.href) ? "bg-slate-900 text-white" : "text-slate-700 hover:bg-slate-200"
                }`}
              >
                {c.label}
              </Link>
            ))}
          </div>
        )}
      </header>
      <main className="min-w-0 p-6">{children}</main>
    </div>
  );
}
