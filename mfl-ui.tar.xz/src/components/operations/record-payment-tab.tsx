"use client";

import { useState } from "react";
import { Button, Card, Empty, Field, Input, StatusBadge, TableWrap, th, td, amt } from "@/components/shared/ui";
import { CollectModal } from "@/components/shared/collect-modal";
import { useList } from "@/lib/use-list";
import { formatDate, formatWhole, LOAN_TYPE_LABEL } from "@/lib/formatters";
import type { ScheduleRow } from "@/types/mfl-api";

/** Record a payment for one loan: pick the loan, then the installment, then the collection amounts. */
export function RecordPaymentTab() {
  const [draftLoan, setDraftLoan] = useState("");
  const [loanId, setLoanId] = useState("");
  const [selected, setSelected] = useState<ScheduleRow | null>(null);
  const list = useList<ScheduleRow>("/payment-schedules", { loan_id: loanId, size: 50 }, loanId !== "");
  const rows = (list.data?.data ?? []).filter((r) => r.balance_due > 0);

  return (
    <Card title="Record payment for a loan">
      <form
        className="mb-4 flex flex-wrap items-end gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          setLoanId(draftLoan.trim());
        }}
      >
        <Field label="Loan ID">
          <Input inputMode="numeric" value={draftLoan} onChange={(e) => setDraftLoan(e.target.value.replace(/\D/g, ""))} className="w-40" />
        </Field>
        <Button variant="primary" type="submit" disabled={draftLoan.trim() === ""}>Show installments</Button>
      </form>

      {loanId === "" && <Empty>Enter a loan ID to see its installments.</Empty>}
      {loanId !== "" && list.data && rows.length === 0 && <Empty>No installments with a balance due for loan #{loanId}.</Empty>}
      {rows.length > 0 && (
        <TableWrap>
          <thead>
            <tr>
              <th className={th}>Schedule ID</th>
              <th className={th}>Customer</th>
              <th className={th}>Type</th>
              <th className={th}>Kist</th>
              <th className={th}>Installment date</th>
              <th className={th}>Status</th>
              <th className={`${th} text-right`}>Installment</th>
              <th className={`${th} text-right`}>Paid</th>
              <th className={`${th} text-right`}>Balance due</th>
              <th className={th}></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.payment_schedule_id} className="hover:bg-slate-50">
                <td className={td}>{r.payment_schedule_id}</td>
                <td className={td}>{r.customer_name}</td>
                <td className={td}>{LOAN_TYPE_LABEL[r.loan_type]}</td>
                <td className={td}>{r.current_kist_no} / {r.total_no_of_kist}</td>
                <td className={td}>{formatDate(r.installment_date)}</td>
                <td className={td}><StatusBadge status={r.status} /></td>
                <td className={amt}>{formatWhole(r.installment_amount)}</td>
                <td className={amt}>{formatWhole(r.amount_paid)}</td>
                <td className={amt}>{formatWhole(r.balance_due)}</td>
                <td className={td}>
                  <Button variant="primary" onClick={() => setSelected(r)}>Record payment</Button>
                </td>
              </tr>
            ))}
          </tbody>
        </TableWrap>
      )}

      {selected && (
        <CollectModal key={selected.payment_schedule_id} schedule={selected} onClose={() => setSelected(null)} />
      )}
    </Card>
  );
}
