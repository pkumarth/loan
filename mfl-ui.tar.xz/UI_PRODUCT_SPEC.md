# MFL Core Web UI — Product Specification

Status: **Draft v1.0**, written from the two source documents (Frontend Product & Usability Specification; UX Screens & Wireframe Blueprints) and the code as it stands in `mfl-ui/`.
Status labels used throughout: **Built** = working in the app, **Partial** = some behaviour in place, **Not built** = specified but not yet implemented, **Stub** = placeholder behaviour.

---

## 1. Purpose and users

MFL Core is an operations workspace for a microfinance lender working in rural and semi-urban areas (default region: Bihar / Madhubani). The UI is used daily by the **Owner** and **Manager** to:

- originate loans (EMI, monthly interest, one-time/Onetime),
- record kist (installment) collections and cash receipts,
- run hisab (settlement) for one-time loans,
- compute overdue fines and produce the monthly portfolio report.

Borrowers and guarantors have **no** portal access. Field collection officers are a secondary audience and need a compact, mobile-friendly collection view (see §9).

## 2. Design principles

1. **Preview before commit.** Every financial batch or calculation runs first as a dry run (`dry_run: true`) and shows an indigo dashed "DRY RUN PREVIEW" banner. Nothing is saved until the operator confirms with `dry_run: false`.
2. **Zero math errors.** Splits and balances are computed live in the UI and checked before submit. Submit stays disabled while a split does not balance.
3. **Inline edits for small changes.** One-field edits (landmark, rate, payer name, guardian name) are click-to-edit cells backed by PATCH. Full forms are for creating records.
4. **Never silently overwrite.** Updates carry `version`; a 409 `OPTIMISTIC_LOCK_CONFLICT` gives the operator a chance to reload.
5. **Indian formatting everywhere.** Money uses `Rs. 1,20,000.00` (en-IN grouping, right-aligned, tabular digits). Dates display as `14 Nov 2026`; the API always receives `YYYY-MM-DD`.
6. **Plain English labels** with the domain terms the business uses ("Kist No", "Hisab Date", "Mohalla", "Onetime Settlement"). Hindi toggle is not planned for v1 (see §12).

## 3. Technology

| Concern | Choice | Notes |
|---|---|---|
| Framework | Next.js 15 (App Router), React 19, TypeScript | Turbopack for `dev` and `build` |
| Styling | Tailwind CSS v4 | shadcn/ui was planned; not adopted, primitives are in `components/shared/ui.tsx` |
| Server state | TanStack Query v5 | Query keys are the resource path, e.g. `["/payments", params]`; prefix invalidation |
| Tables | Plain tables with sticky `th` | TanStack Table not used yet |
| Forms | Plain React state + Zod for split/mobile validation | React Hook Form is installed but unused |
| Feedback | Sonner toasts | |
| Icons | Lucide React | |
| API | `lib/api-client.ts` → `NEXT_PUBLIC_API_BASE_URL` | Default `http://127.0.0.1:8000` |

Routes that exist: `/login`, `/`, `/customers`, `/customers/[id]`, `/addresses`, `/loans`, `/loans/new`, `/loans/[id]`, `/schedules`, `/schedules/generate`, `/current-payment`, `/onetime`, `/operations`.

## 4. Information architecture

### 4.1 Primary tabs (Section 0 of the UX blueprint)

The app uses a top tab bar. The left sidebar from the early build is retired. Each primary tab may have sub-tabs shown in a second row.

| Primary tab | Route(s) | Sub-tabs | Status |
|---|---|---|---|
| Dashboard | `/` | — | Built |
| Customer Details | `/customers`, `/customers/[id]`, `/addresses` | Customer Dashboard (`/customers`) · Address Dashboard (`/addresses`) | Partial (Customer 360° has only the loans tab) |
| Loan | `/loans`, `/loans/new`, `/loans/[id]` | — | Partial |
| Payment-Schedules | `/schedules`, `/schedules/generate` | — | Partial |
| Current-Payment | `/current-payment` | — | Built (print/share missing) |
| Hisab & Ops | `/onetime`, `/operations` | Onetime Hisab & Settlement · Overdue Engine & Reports | Partial |

The blueprint also describes a single `/customer-details?tab=…` route. The build uses separate routes with the same sub-tab labels; this is intentional for deep-linking.

### 4.2 Global header

| Element | Behaviour | Status |
|---|---|---|
| Brand | "MFL CORE" | Built |
| API health badge | Polls `GET /mfl-core/health` every 60 s. Green "API Online" / red "API Offline". | Built |
| Operator | Shows `Owner: praveen` (role and name from the session), with Logout | Built (stub login, §5.1) |
| Quick search (Ctrl+K) | Search by customer name, mobile, `CUST-…` or `LN-…`, grouped results | Not built |
| "+ New" quick-action menu | New Customer, New Loan, New Address, Monthly Kist Generator | Not built |

## 5. Shared behaviour

### 5.1 Authentication (Screen 0)

Intended flow: Mobile + Password → "Send OTP" → 6-digit OTP (60 s resend timer, auto-advancing boxes) → workspace. Only Owner and Manager accounts. The authenticated user ID binds to `X-User-Id` for audit columns.

**Current state — Stub.** The login page accepts a role (Owner `praveen` or Manager `bhikhari_yadav`), any 10-digit mobile, any non-empty password, and the OTP `123456` (overridable with `NEXT_PUBLIC_DEV_OTP`). No SMS is sent. The session is kept in `localStorage`, and a route guard redirects to `/login` when no session exists. This is client-side only and must not be deployed.

Required before real use: backend auth endpoints, an SMS provider, HTTP-only session cookie, and server-side role checks.

### 5.2 API client contract

All calls go through `lib/api-client.ts`.

- Sends `Content-Type: application/json` and `X-User-Id: <logged-in user>`.
- Unwraps `{ status, status_code, display_msg, cause, data, pagination }`.
- Throws `ApiError` on `status === "failure"` or non-2xx, carrying `display_msg` and `cause`.

Feedback rules:

| Situation | Expected UI | Status |
|---|---|---|
| Mutation succeeds (200/201) | Green toast with the backend `display_msg` | Partial — toasts use UI-written messages, not `display_msg` |
| Validation failure (400/422) | Destructive toast with `display_msg`; field-level `cause` messages mapped to the input | Partial — toast only, no field mapping |
| 404 / 409 duplicate / 500 | Destructive toast with `display_msg` | Built |
| 409 `OPTIMISTIC_LOCK_CONFLICT` | Modal: "This record was updated by another user." with **Reload Latest Values** | Not built — generic toast only |

### 5.3 Dry-run pattern

Used by: generate-monthly, onetime-dry-run, onetime-settlement, overdue-compute, report-generate.

1. Preview button calls the endpoint with `dry_run: true`; the result is shown with the dashed indigo banner.
2. Confirm button is enabled only after a successful preview for the same inputs.
3. Confirm calls the endpoint with `dry_run: false`, shows a success toast, and invalidates related queries.

Status: Built on the Generate, Overdue, Report, and Onetime settlement screens. Changing an input after a preview should clear the preview; this is not yet enforced everywhere.

### 5.4 Inline single-field edit

Click the value → inline input with save; Enter saves, Escape cancels; the request is a PATCH with only that field.

Used on: customer guardian name and mobile, loan purpose and status. **Not yet used** on: address landmark and ward (spec requirement), loan rate (popover), schedule payer name, customer KYC status.

### 5.5 Formatting and display

| Item | Rule | Status |
|---|---|---|
| Money | `Rs. 1,20,000.00`, right-aligned, tabular digits | Built |
| Dates (display) | `14 Nov 2026` | Built |
| Dates (API) | `YYYY-MM-DD` | Built |
| Collection cycle | Installment day 8–20 → **12th cycle**; otherwise **25th cycle** | Built (labels on schedules and dues) |
| Pagination | Prev / Next, "Page x of y", server-side, default size 20 | Built |
| Status badges | OPEN slate · PARTIAL amber · OVERDUE/DEFAULTED red · CLOSED/VERIFIED/ACTIVE emerald · WAIVED grey | Built |
| Mobile numbers | Click-to-call / WhatsApp links | Not built |

## 6. Module specifications

### 6.1 Dashboard (`/`) — Built

Purpose: morning command centre. Single request to `GET /dashboard/summary`, refreshed every 60 s. Optional `billing_year` / `billing_month` (default current month).

Content, top to bottom:

1. **Alerts strip** — "monthly kists not yet generated" (from the 6th of the month), "N overdue / partial kists", "N blacklisted customers". Each alert links to its action.
2. **KPI cards** — Total active AUM (with EMI / Interest / Onetime counts), Capital deployed (owner, manager), Collected this month (cash and UPI split), Overdue & fines.
3. **Cycle collection** — 12th and 25th progress bars (collected vs expected, % efficiency, pending, open kists).
4. **Owner vs manager** — deployed capital, collected this month, processing fees, forgiven.
5. **Top villages by pending due** (top 5), **Customers & KYC** counts, **Today's receipts** (latest 5).

Not built from the blueprint: Upcoming Cycle card with one-click navigation; the "Quick Borrower / Loan Lookup" bar; the Daily Operations desk shortcuts; scope selector (All / Manager / Owner).

Known limitation: "Forgiven" is all-time, and "Capital deployed" includes closed loans. Both are labelled as such in the spec and may need a period filter later.

### 6.2 Customer Details (`/customers`, `/customers/[id]`, `/addresses`)

#### 6.2.1 Address Dashboard (`/addresses`) — Partial

Purpose: maintain the village / mohalla directory.

| Requirement | Status |
|---|---|
| Table: ID, village, mohalla, police station, district, state, postal code | Built |
| Filter by village | Built |
| Filters by police station, mohalla, postal code, ward | Not built |
| Create address modal with defaults country India, state BIHAR, district MADHUBANI | Built, but the defaults are editable — the spec asks them to be **locked** with an "Edit Region" toggle |
| Inline PATCH on landmark and ward | Not built |
| Row menu: Edit (PUT), View linked customers, Delete (DELETE, with 409 message when referenced) | Not built |
| Pagination size selector | Not built |

Validation: postal code 4–12 characters (required). Other fields optional.

#### 6.2.2 Customer Dashboard (`/customers`) — Partial

| Requirement | Status |
|---|---|
| Directory with pagination and search by name | Built |
| Columns: ID, name, guardian, mobile, address ID, guarantor ID, status | Built (address and guarantor shown as IDs, not names) |
| Create customer form with guardian relation (FATHER / HUSBAND / MOTHER / OTHER) and 10-digit mobile validation | Built |
| Address combobox with "+ Add New Address" mini-modal | Not built — address is typed as an ID |
| Guarantor combobox (search by name / mobile) with "+ Quick Create Guarantor" | Not built — guarantor is typed as an ID |
| Aadhaar (XXXX-XXXX-XXXX), PAN auto-uppercased, family income, family loan, rating (1–10, default 8), customer status | Not built in form (fields exist in API) |
| Delete (DELETE) with linked-record warning | Not built |

Validation: name and guardian required; mobile must be exactly 10 digits; address required.

#### 6.2.3 Customer 360° (`/customers/[id]`) — Partial

| Requirement | Status |
|---|---|
| Profile card with inline guardian name and mobile | Built |
| Guarantor contact card | Not built |
| KYC status quick-patch (to VERIFIED) | Not built |
| Tab: Active & Past Loans | Built (list only) |
| Tab: Kist Payment History | Not built |
| Tab: KYC & Guarantor Info | Not built |
| "+ Issue New Loan" (pre-fills customer on `/loans/new`) | Not built |

### 6.3 Loan (`/loans`, `/loans/new`, `/loans/[id]`) — Partial

#### 6.3.1 Portfolio (`/loans`)

| Requirement | Status |
|---|---|
| Filter by loan type and status; search by account number | Built |
| Segmented filter tabs (All / EMI / MONTHLY_INTEREST / ONETIME) | Partial — dropdowns, not tabs |
| Click ROI badge → popover to PATCH `rate_of_interest` | Not built |
| Columns: account, type, customer ID, borrowed on, remaining principal, installment, kists, status | Built |

#### 6.3.2 Origination (`/loans/new`)

Loan type control adapts visible fields.

| Type | Shows | Hides | Status |
|---|---|---|---|
| EMI | borrowing date, installment, kist count, rate (monthly), processing fee | — | Built, but the spec's **live preview of first/last kist dates and 12th/25th cycle badge** is not built (only an approximate last-installment date) |
| MONTHLY_INTEREST | borrowing date, start date, rate, installment with helper "principal × ROI" | kist count, end-date fields | Partial — kist field still shown, no helper button, no start date |
| ONETIME | borrowing date, rate (labelled per period) | installment, kist, start-date fields | Partial — installment is sent as 0 (backend acceptance not verified) |

Capital split (applies to all types):

- Manager amount + owner amount must equal principal. Shows a live balance line; Submit is disabled while unbalanced. **Built**, but the spec's "auto-fill the other side as you type" is **not built** (user types both).
- Optional parent loan selector pre-filtered to the customer's loans — **Not built** (parent ID is typed).

Flow: Review → confirmation card with a summary → Confirm & save → redirect to `/loans/[id]`. Built.

#### 6.3.3 Loan detail (`/loans/[id]`) — Partial

Built: header badges, loan facts, capital split, inline edit of purpose and status, installment list (reusing the schedule table).
Not built: rate popover, top-up / renewal section, "Record collection" from this screen.

### 6.4 Payment-Schedules (`/schedules`, `/schedules/generate`) — Partial

#### 6.4.1 Kist ledger (`/schedules`)

| Requirement | Status |
|---|---|
| Filters: status, loan type, installment date, loan ID | Built |
| Filter tabs: All · 12th Cycle · 25th Cycle · OPEN · PARTIAL · OVERDUE · CLOSED | Partial — status and type dropdowns, no cycle tabs |
| Columns with borrower name, mobile, village, guarantor, type badge, kist #, installment date, installment, fine, kist interest, forgive, paid, balance due | Partial — shows loan, customer, kist, date, status, installment, paid, balance |
| Column chooser (`?include=` / `?exclude=`) | Not built |
| "Collect" action on each row | Built on **Current-Payment** (§6.5), not here |
| Totals for the page | Built |
| Print-friendly view | Not built |

#### 6.4.2 Monthly generator (`/schedules/generate`)

| Requirement | Status |
|---|---|
| Billing year and month | Built |
| `cycle_12_start_day` (default 8) and `cycle_12_cutoff_day` (default 20) inputs | Not built — the API defaults are used |
| Preview (dry run) → KPI cards and searchable candidate table | Partial — shows counts only, no candidate table |
| Confirm & Generate enabled only after preview | Built |

Rule: idempotent — a loan/month already generated is skipped and counted.

### 6.5 Current-Payment (`/current-payment`) — Built

Two sections on one page.

**Section A — Calculated current payables.** Installments filtered by status (OPEN, PARTIAL, OVERDUE) with paging. Each row has **Collect Now**.

**Collect modal** (one open = one idempotency key, so retries cannot double-apply):

- Inputs: manager received, owner received, payment mode (CASH / UPI / BANK_TRANSFER / CHEQUE), transaction reference, payer name.
- Live: payment amount = manager + owner; balance due before; balance after.
- Validation: amount > 0; amount ≤ balance due. Submit disabled while saving.
- On success: toast with the receipt number; dues, receipts, and dashboard refresh.

Not built: "Full due to manager / owner" and "50-50" presets; the modal has no forgive, fine or other-amount fields (the spec lists them on the schedule drawer).

**Section B — Receipts ledger.** Immutable list of receipts with receipt no., date, borrower, loan, kist, amount, mode, reference, status. Filters: status, mode. **Reverse** (SUCCESS receipts only, with confirmation) sets the status to REVERSED and takes the amount back off the installment.

Not built: print / share receipt (the spec's "1-click Print / Share Receipt modal"); WhatsApp share; receipt for ONETIME settlement (see §12).

### 6.6 Hisab & Ops

#### 6.6.1 Onetime Hisab & Settlement (`/onetime`) — Partial

| Requirement | Status |
|---|---|
| Hisab date picker (default today) | Built |
| Paged dry-run table of all active ONETIME loans: principal, days, per-day interest, interest, total due | Built |
| Row action "Settle ₹" to open settlement for that loan | Partial — clicking the row loads the loan into the form |
| Single-loan settlement: preview (dry run) then confirm (dry_run false) with a confirmation step | Partial — no confirmation dialog |
| Printable "Borrower Hisab Slip" (principal + elapsed days + interest + forgive − received = net) | Not built |
| Split-screen / two-tab layout | Not built (single page with two cards) |

Interest rule: days × principal × rate / 3000, whole rupees, half-up, from `modified_borrowing_date` to hisab date.

#### 6.6.2 Overdue Engine & Reports (`/operations`) — Partial

Overdue panel:

- Run date (default today), optional single loan ID.
- Dry run → table of open installments with days, fine, interest, due, resulting status.
- Run & save enabled after a dry run.

Rules applied by the engine: fine 1 % of remaining principal, once; interest 2.5/3000 per day on (installment − paid) for EMI only; monthly-interest loans carry no fine and no interest; status OVERDUE when due > 0 and the date has passed; CLOSED when due reaches zero.

Not built: a before/after diff table, a scope toggle (currently a free-text loan ID), the "refresh schedule cache" after apply (the page invalidates queries, which is equivalent).

Report panel:

- Billing year and month; Dry run; Generate report.
- Shows row count, overdue amount, status counts, file path.

Not built: summary cards for total disbursed, collected by manager vs owner, forgiven; CSV and PDF export; the preview table.

## 7. Cross-cutting rules the UI relies on

| Rule | Source | Used in |
|---|---|---|
| Capital split: manager + owner = principal | Backend loan rule | Loan origination, loan edit |
| Installment balance due = installment + fine + other + kist interest − amount paid | `_runtime_balance_due` | Dues, collect modal, schedule table |
| Collection: payment amount = manager received + owner received | Payments API | Collect modal |
| Schedule status: CLOSED when balance ≤ 0; PARTIAL when some paid; OPEN otherwise | Payments API | Dues, ledger |
| Reversal recomputes the installment's paid amount and status | Payments API | Receipts ledger |
| Idempotency key per collection attempt | Payments API | Collect modal |
| One installment per loan per billing month | DB unique key | Generator, schedule create (409 shown) |
| Collection cycle: day 8–20 → 12th; otherwise 25th | Business rule | Dashboard, dues labels |

**Open discrepancy:** the UX blueprint defines balance due with "− forgive", but the backend formula excludes forgiveness (forgiveness is already reflected in amount paid, per the product owner's earlier decision). The UI follows the backend. See §12.

## 8. Dashboard and alert rules

- Auto-refresh: dashboard 60 s; health badge 60 s; other lists refresh on mutation.
- Alert "monthly kists not generated" appears from day 6 of the month when no installment exists for the billing month.
- Alert "overdue / partial kists" appears when any installment is OVERDUE or PARTIAL.
- Alerts do not block any action.

## 9. Field-user mode (tablet and phone)

Spec requirement (not built):

- Below 768 px the sidebar/tab bar collapses to a menu; wide tables turn into compact cards.
- Each card has tap-to-call borrower, tap-to-call guarantor, and a **Collect ₹** button.
- Touch targets at least 40 px.

Current state: tabs wrap and tables scroll horizontally; touch-target sizing is 40 px on buttons and inputs (`min-h-10`). Card layout is not built.

## 10. Non-functional requirements

| Area | Requirement | Current |
|---|---|---|
| Accessibility | Labelled inputs, focus order, Escape closes modals, `aria-current` on active tab | Partly met |
| Keyboard | Tab → Enter submits forms; first field autofocused on modals | Partly met (Enter submits; autofocus on the modal's first field) |
| Performance | Lists paged server-side; no client-side aggregation of large sets | Met — the dashboard uses the summary endpoint |
| Data safety | Destructive actions confirmed (reverse, delete); dry-run before commit | Met for reverse and dry runs; delete not built |
| Audit | `X-User-Id` on every request | Met (stub identity) |
| Browser support | Current Chrome, Edge, Firefox; Android Chrome for field users | Not tested |
| Print | Receipts and hisab slips printable | Not built |
| Security | Real auth, HTTP-only session, server-side role checks | Not built (stub) |

## 11. Acceptance criteria for core flows

**UC-01 Login** — Given an Owner or Manager with a valid mobile, password and OTP, when they verify, then they land on the Dashboard and every request carries their `X-User-Id`. *(Stub only.)*

**UC-02 Onboard borrower** — Given an address exists, when the operator creates a customer with a valid 10-digit mobile, then the customer appears in the directory and opens on Customer 360°. *(Partly met; address and guarantor pickers missing.)*

**UC-03 Originate loan** — Given a customer, when the operator enters principal and a manager/owner split that equals principal, then Submit is enabled, a confirmation is shown, and on save the app opens the loan detail. Submit stays disabled while the split does not balance. *(Met for split, confirmation and redirect; type-specific field hiding partly met.)*

**UC-04 Generate monthly kists** — Given a billing month, when the operator previews, then counts are shown with the dry-run banner and Confirm is enabled; when they confirm, rows are created and a second run creates none. *(Met for counts; candidate table missing.)*

**UC-05 Collect a payment** — Given an installment with balance B, when the operator enters manager + owner = P with P ≤ B and saves, then a receipt is created, the installment's balance drops by P, the receipt appears in the ledger, and retrying the same save does not double-apply. Entering P > B is refused before submit. *(Met.)*

**UC-06 Reverse a receipt** — Given a SUCCESS receipt, when the operator reverses it and confirms, then the receipt shows REVERSED and the installment's paid amount drops by the same amount; a second reverse is refused. *(Met.)*

**UC-07 Onetime hisab** — Given a ONETIME loan and a hisab date, when the operator previews, then days, per-day interest, interest and total due are shown with the dry-run banner; confirming records the settlement with the received split and any forgive amount. *(Met for numbers; slip printing and per-row settle action missing.)*

**UC-08 Overdue compute** — Given a run date, when the operator dry-runs then runs, then fine is applied once per installment, interest accrues per day on the unpaid EMI installment, and monthly-interest loans get neither. *(Met.)*

**UC-09 Monthly report** — Given a billing month, when the operator dry-runs then generates, then one row per open loan is written and the file is produced; closed loans are excluded. *(Met on the backend; export buttons missing.)*

## 12. Open questions

1. **Balance due and forgiveness.** The UX blueprint subtracts forgiveness in balance due; the backend does not. Which is correct?
2. **Onetime settlement receipts.** Should a settlement also write a row to the receipts ledger so it appears in Current-Payment and the day's receipts?
3. **Authentication.** Confirm the target auth method (SMS OTP provider, or an existing identity service) and whether the session should be a server cookie.
4. **Language.** English only for v1, or a Hindi / English toggle?
5. **Print and WhatsApp.** Confirm the print layout for receipts and hisab slips, and whether WhatsApp sharing is required for v1.
6. **Field-user mode.** Is the card layout for phones in scope for v1, or after the desktop flows are verified?
7. **Overdue status after a collection.** A collection on an OVERDUE installment currently sets it to PARTIAL until the next overdue run. Should it stay OVERDUE until the fine is paid?

## 13. Build backlog (priority order)

| # | Item | Module | Why |
|---|---|---|---|
| 1 | Field-level error mapping and `display_msg` toasts | Global | Operators need to see which field is wrong |
| 2 | 409 "Reload Latest Values" modal | Global | Prevents silent overwrite |
| 3 | Address and guarantor pickers with quick-create | Customers | Core onboarding flow |
| 4 | Loan form: type-specific fields, kist date and cycle preview, parent loan picker | Loans | Spec's origination rules |
| 5 | Inline PATCH: address landmark and ward, loan rate popover, schedule payer name, customer KYC | Multiple | Spec's inline-edit rule |
| 6 | Cycle filter tabs and column chooser on the kist ledger | Schedules | Daily collection workflow |
| 7 | Generator: cycle-day inputs and candidate table | Schedules | Preview completeness |
| 8 | Receipt print / share; hisab slip print | Current-Payment, Onetime | Operators hand receipts to borrowers |
| 9 | Ctrl+K search and "+ New" menu | Global | Speed |
| 10 | Field-user mode (cards, click-to-call) | Global | Field collection |
| 11 | Report export (CSV, print) | Operations | Month-end handover |
| 12 | Real authentication | Global | Required before any deployment |
